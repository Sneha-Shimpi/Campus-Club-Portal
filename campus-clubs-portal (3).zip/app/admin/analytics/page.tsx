"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  AreaChart,
  Area,
} from "recharts"
import { Download, TrendingUp, Users, Trophy, Heart, Shield, Calendar, Target } from "lucide-react"

const monthlyPerformance = [
  { month: "Aug", sports: 85, nss: 92, ncc: 78, overall: 85 },
  { month: "Sep", sports: 88, nss: 89, ncc: 82, overall: 86 },
  { month: "Oct", sports: 92, nss: 94, ncc: 85, overall: 90 },
  { month: "Nov", sports: 89, nss: 96, ncc: 88, overall: 91 },
  { month: "Dec", sports: 94, nss: 98, ncc: 91, overall: 94 },
  { month: "Jan", sports: 96, nss: 95, ncc: 93, overall: 95 },
]

const sectionComparison = [
  { section: "Sports Club", students: 456, events: 28, satisfaction: 92, growth: 15 },
  { section: "NSS", students: 342, events: 45, satisfaction: 96, growth: 22 },
  { section: "NCC", students: 189, events: 32, satisfaction: 89, growth: 8 },
]

const impactMetrics = [
  { category: "Environmental", value: 2847, unit: "Trees Planted", color: "#10b981" },
  { category: "Health", value: 156, unit: "Blood Units", color: "#ef4444" },
  { category: "Education", value: 1240, unit: "Students Taught", color: "#3b82f6" },
  { category: "Community", value: 89, unit: "Events Organized", color: "#f59e0b" },
]

const topPerformers = [
  { name: "Rahul Sharma", section: "Sports", score: 98, achievement: "Basketball Champion" },
  { name: "Priya Patel", section: "NSS", score: 96, achievement: "Volunteer Leader" },
  { name: "Amit Kumar", section: "NCC", score: 94, achievement: "Best Cadet" },
  { name: "Sneha Reddy", section: "NSS", score: 93, achievement: "Community Hero" },
  { name: "Vikram Singh", section: "Sports", score: 92, achievement: "Cricket Captain" },
]

const attendanceTrends = [
  { week: "Week 1", sports: 89, nss: 94, ncc: 87 },
  { week: "Week 2", sports: 92, nss: 96, ncc: 89 },
  { week: "Week 3", sports: 88, nss: 93, ncc: 91 },
  { week: "Week 4", sports: 95, nss: 98, ncc: 94 },
]

export default function AnalyticsDashboard() {
  const [timeRange, setTimeRange] = useState("6months")
  const [selectedSection, setSelectedSection] = useState("all")

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Analytics & Reports</h1>
          <p className="text-gray-600 mt-1">Comprehensive performance insights and data analysis</p>
        </div>
        <div className="flex gap-3">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1month">Last Month</SelectItem>
              <SelectItem value="3months">Last 3 Months</SelectItem>
              <SelectItem value="6months">Last 6 Months</SelectItem>
              <SelectItem value="1year">Last Year</SelectItem>
            </SelectContent>
          </Select>
          <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
            <Download className="h-4 w-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Students</p>
                <p className="text-2xl font-bold text-gray-900">1,247</p>
                <p className="text-xs text-green-600 font-medium flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +12% from last month
                </p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Events</p>
                <p className="text-2xl font-bold text-gray-900">105</p>
                <p className="text-xs text-green-600 font-medium flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +8% from last month
                </p>
              </div>
              <Calendar className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Attendance</p>
                <p className="text-2xl font-bold text-gray-900">94%</p>
                <p className="text-xs text-green-600 font-medium flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +3% from last month
                </p>
              </div>
              <Target className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Satisfaction</p>
                <p className="text-2xl font-bold text-gray-900">92%</p>
                <p className="text-xs text-green-600 font-medium flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  +5% from last month
                </p>
              </div>
              <Trophy className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="sports">Sports Analytics</TabsTrigger>
          <TabsTrigger value="nss">NSS Impact</TabsTrigger>
          <TabsTrigger value="ncc">NCC Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Performance Trends */}
            <Card>
              <CardHeader>
                <CardTitle>Performance Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={monthlyPerformance}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="month" />
                    <YAxis />
                    <Tooltip />
                    <Line type="monotone" dataKey="sports" stroke="#f97316" strokeWidth={2} name="Sports" />
                    <Line type="monotone" dataKey="nss" stroke="#ef4444" strokeWidth={2} name="NSS" />
                    <Line type="monotone" dataKey="ncc" stroke="#8b5cf6" strokeWidth={2} name="NCC" />
                    <Line type="monotone" dataKey="overall" stroke="#059669" strokeWidth={3} name="Overall" />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Section Comparison */}
            <Card>
              <CardHeader>
                <CardTitle>Section Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={sectionComparison}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="section" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="students" fill="#3b82f6" name="Students" />
                    <Bar dataKey="events" fill="#10b981" name="Events" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          {/* Impact Metrics */}
          <Card>
            <CardHeader>
              <CardTitle>Community Impact Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {impactMetrics.map((metric, index) => (
                  <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                    <div className="text-3xl font-bold mb-2" style={{ color: metric.color }}>
                      {metric.value.toLocaleString()}
                    </div>
                    <div className="text-sm text-gray-600">{metric.unit}</div>
                    <div className="text-xs text-gray-500 mt-1">{metric.category}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Performers */}
          <Card>
            <CardHeader>
              <CardTitle>Top Performers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {topPerformers.map((performer, index) => (
                  <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-emerald-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                        {index + 1}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-900">{performer.name}</p>
                        <p className="text-sm text-gray-600">{performer.achievement}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge
                        variant="outline"
                        className={
                          performer.section === "Sports"
                            ? "border-orange-200 text-orange-800"
                            : performer.section === "NSS"
                              ? "border-red-200 text-red-800"
                              : "border-purple-200 text-purple-800"
                        }
                      >
                        {performer.section}
                      </Badge>
                      <div className="text-right">
                        <p className="font-bold text-emerald-600">{performer.score}%</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sports" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-orange-600" />
                  Sports Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold text-orange-600">45</p>
                      <p className="text-sm text-gray-600">Matches Played</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-green-600">32</p>
                      <p className="text-sm text-gray-600">Matches Won</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-blue-600">71%</p>
                      <p className="text-sm text-gray-600">Win Rate</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Attendance Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart data={attendanceTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="week" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="sports" stroke="#f97316" fill="#f97316" fillOpacity={0.3} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="nss" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Heart className="h-5 w-5 text-red-600" />
                  NSS Impact Summary
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold text-green-600">2,847</p>
                      <p className="text-sm text-gray-600">Trees Planted</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-red-600">156</p>
                      <p className="text-sm text-gray-600">Blood Units</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-blue-600">1,240</p>
                      <p className="text-sm text-gray-600">Students Taught</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-purple-600">15,420</p>
                      <p className="text-sm text-gray-600">Volunteer Hours</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Volunteer Participation</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart data={attendanceTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="week" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="nss" stroke="#ef4444" fill="#ef4444" fillOpacity={0.3} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="ncc" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-purple-600" />
                  NCC Performance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <p className="text-2xl font-bold text-purple-600">189</p>
                      <p className="text-sm text-gray-600">Active Cadets</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-green-600">94%</p>
                      <p className="text-sm text-gray-600">Attendance</p>
                    </div>
                    <div>
                      <p className="text-2xl font-bold text-blue-600">23</p>
                      <p className="text-sm text-gray-600">Promotions</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Training Attendance</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <AreaChart data={attendanceTrends}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="week" />
                    <YAxis />
                    <Tooltip />
                    <Area type="monotone" dataKey="ncc" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.3} />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
