const mongoose = require("mongoose")

const profileSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
    unique: true,
  },
  name: String,
  email: String,
  rollNo: String,
  phone: String,
  department: String,
  year: String,
  bio: String,
  profilePhoto: String,
  privacyCode: {
    type: String,
    unique: true,
    sparse: true,
  },
  activityStats: {
    sports: { events: Number, hours: Number },
    nss: { events: Number, hours: Number },
    ncc: { events: Number, hours: Number },
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

module.exports = mongoose.model("Profile", profileSchema)
