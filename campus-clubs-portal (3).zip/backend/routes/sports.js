const express = require("express")
const { validationResult } = require("express-validator")
const SportsMatch = require("../models/SportsMatch")
const Booking = require("../models/Booking")
const User = require("../models/User")
const Event = require("../models/Event")
const { authenticateToken, requireAdmin, requireStudentOrAdmin } = require("../middleware/auth")
const { validationRules } = require("../middleware/validation")
const { sendSuccess, sendError, sendValidationError, sendNotFound } = require("../utils/responseHelper")

const router = express.Router()

// @route   GET /api/sports/dashboard
// @desc    Get sports dashboard data
// @access  Private
router.get("/dashboard", authenticateToken, async (req, res) => {
  try {
    const userId = req.user._id

    // Get user's sports statistics
    const user = await User.findById(userId)
    const sportsStats = user.sportsStats

    // Get upcoming matches
    const upcomingMatches = await SportsMatch.find({
      status: "scheduled",
      scheduledDate: { $gte: new Date() },
      $or: [{ "team1.players": userId }, { "team2.players": userId }],
    })
      .populate("team1.players team2.players", "name rollNo")
      .sort({ scheduledDate: 1 })
      .limit(5)

    // Get recent match results
    const recentResults = await SportsMatch.find({
      status: "completed",
      $or: [{ "team1.players": userId }, { "team2.players": userId }],
    })
      .populate("team1.players team2.players", "name rollNo")
      .sort({ scheduledDate: -1 })
      .limit(5)

    // Get user's active bookings
    const activeBookings = await Booking.find({
      bookedBy: userId,
      status: { $in: ["pending", "approved"] },
      startTime: { $gte: new Date() },
    })
      .sort({ startTime: 1 })
      .limit(3)

    // Get leaderboard position
    const allUsers = await User.find({ role: "student" }).sort({
      "sportsStats.matchesWon": -1,
      "sportsStats.totalScore": -1,
    })

    const userPosition = allUsers.findIndex((u) => u._id.toString() === userId.toString()) + 1

    sendSuccess(
      res,
      {
        statistics: sportsStats,
        upcomingMatches,
        recentResults,
        activeBookings,
        leaderboardPosition: userPosition,
        totalPlayers: allUsers.length,
      },
      "Sports dashboard data retrieved successfully",
    )
  } catch (error) {
    console.error("Sports dashboard error:", error)
    sendError(res, "Failed to retrieve sports dashboard data", 500)
  }
})

// @route   GET /api/sports/matches
// @desc    Get all sports matches with filters
// @access  Private
router.get("/matches", authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, sport, status, matchType, startDate, endDate } = req.query

    // Build filter object
    const filter = {}
    if (sport) filter.sport = sport
    if (status) filter.status = status
    if (matchType) filter.matchType = matchType

    if (startDate || endDate) {
      filter.scheduledDate = {}
      if (startDate) filter.scheduledDate.$gte = new Date(startDate)
      if (endDate) filter.scheduledDate.$lte = new Date(endDate)
    }

    const skip = (page - 1) * limit

    const matches = await SportsMatch.find(filter)
      .populate("team1.players team2.players", "name rollNo department")
      .populate("team1.captain team2.captain", "name rollNo")
      .populate("organizer", "name email")
      .sort({ scheduledDate: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await SportsMatch.countDocuments(filter)

    sendSuccess(
      res,
      {
        matches,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalMatches: total,
          hasNext: page * limit < total,
          hasPrev: page > 1,
        },
      },
      "Matches retrieved successfully",
    )
  } catch (error) {
    console.error("Get matches error:", error)
    sendError(res, "Failed to retrieve matches", 500)
  }
})

// @route   POST /api/sports/matches
// @desc    Create a new sports match
// @access  Private (Admin only)
router.post("/matches", [authenticateToken, requireAdmin], async (req, res) => {
  try {
    const { title, sport, matchType, team1, team2, scheduledDate, venue, duration } = req.body

    // Validate required fields
    if (!title || !sport || !team1 || !team2 || !scheduledDate || !venue) {
      return sendError(res, "Missing required fields", 400)
    }

    // Validate team players exist
    const team1Players = await User.find({ _id: { $in: team1.players } })
    const team2Players = await User.find({ _id: { $in: team2.players } })

    if (team1Players.length !== team1.players.length || team2Players.length !== team2.players.length) {
      return sendError(res, "Some players not found", 400)
    }

    const match = new SportsMatch({
      title,
      sport,
      matchType,
      team1: {
        name: team1.name,
        players: team1.players,
        captain: team1.captain,
      },
      team2: {
        name: team2.name,
        players: team2.players,
        captain: team2.captain,
      },
      scheduledDate: new Date(scheduledDate),
      venue,
      duration,
      organizer: req.user._id,
    })

    await match.save()

    const populatedMatch = await SportsMatch.findById(match._id)
      .populate("team1.players team2.players", "name rollNo")
      .populate("organizer", "name email")

    sendSuccess(res, populatedMatch, "Match created successfully", 201)
  } catch (error) {
    console.error("Create match error:", error)
    sendError(res, "Failed to create match", 500)
  }
})

// @route   PUT /api/sports/matches/:id/result
// @desc    Update match result
// @access  Private (Admin only)
router.put("/matches/:id/result", [authenticateToken, requireAdmin], async (req, res) => {
  try {
    const { id } = req.params
    const { team1Score, team2Score, winner, matchSummary, statistics } = req.body

    const match = await SportsMatch.findById(id)
    if (!match) {
      return sendNotFound(res, "Match")
    }

    // Update match result
    match.team1.score = team1Score
    match.team2.score = team2Score
    match.winner = winner
    match.matchSummary = matchSummary
    match.status = "completed"

    if (statistics) {
      match.statistics = statistics
    }

    await match.save()

    // Update player statistics
    const allPlayers = [...match.team1.players, ...match.team2.players]

    for (const playerId of allPlayers) {
      const user = await User.findById(playerId)
      if (user) {
        user.sportsStats.matchesPlayed += 1

        // Determine if player won
        const isTeam1Player = match.team1.players.includes(playerId)
        const playerWon = (isTeam1Player && winner === "team1") || (!isTeam1Player && winner === "team2")

        if (playerWon) {
          user.sportsStats.matchesWon += 1
        }

        // Add score based on team
        const playerScore = isTeam1Player ? team1Score : team2Score
        user.sportsStats.totalScore += playerScore

        await user.save()
      }
    }

    const updatedMatch = await SportsMatch.findById(id).populate("team1.players team2.players", "name rollNo")

    sendSuccess(res, updatedMatch, "Match result updated successfully")
  } catch (error) {
    console.error("Update match result error:", error)
    sendError(res, "Failed to update match result", 500)
  }
})

// @route   GET /api/sports/leaderboard
// @desc    Get sports leaderboard
// @access  Private
router.get("/leaderboard", authenticateToken, async (req, res) => {
  try {
    const { sport, limit = 20 } = req.query

    // Build aggregation pipeline
    const pipeline = [
      { $match: { role: "student" } },
      {
        $addFields: {
          winRate: {
            $cond: {
              if: { $eq: ["$sportsStats.matchesPlayed", 0] },
              then: 0,
              else: {
                $multiply: [{ $divide: ["$sportsStats.matchesWon", "$sportsStats.matchesPlayed"] }, 100],
              },
            },
          },
        },
      },
      {
        $sort: {
          "sportsStats.matchesWon": -1,
          winRate: -1,
          "sportsStats.totalScore": -1,
        },
      },
      { $limit: Number.parseInt(limit) },
      {
        $project: {
          name: 1,
          rollNo: 1,
          department: 1,
          year: 1,
          profilePhoto: 1,
          "sportsStats.matchesPlayed": 1,
          "sportsStats.matchesWon": 1,
          "sportsStats.totalScore": 1,
          winRate: 1,
        },
      },
    ]

    const leaderboard = await User.aggregate(pipeline)

    // Add rank to each player
    const rankedLeaderboard = leaderboard.map((player, index) => ({
      ...player,
      rank: index + 1,
    }))

    sendSuccess(res, rankedLeaderboard, "Leaderboard retrieved successfully")
  } catch (error) {
    console.error("Get leaderboard error:", error)
    sendError(res, "Failed to retrieve leaderboard", 500)
  }
})

// @route   GET /api/sports/bookings
// @desc    Get user's bookings
// @access  Private
router.get("/bookings", authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, status, type } = req.query
    const userId = req.user._id

    const filter = { bookedBy: userId }
    if (status) filter.status = status
    if (type) filter.type = type

    const skip = (page - 1) * limit

    const bookings = await Booking.find(filter)
      .populate("bookedBy", "name rollNo")
      .populate("approvedBy", "name")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await Booking.countDocuments(filter)

    sendSuccess(
      res,
      {
        bookings,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalBookings: total,
        },
      },
      "Bookings retrieved successfully",
    )
  } catch (error) {
    console.error("Get bookings error:", error)
    sendError(res, "Failed to retrieve bookings", 500)
  }
})

// @route   POST /api/sports/bookings
// @desc    Create a new booking
// @access  Private
router.post("/bookings", authenticateToken, async (req, res) => {
  try {
    const { type, facility, equipment, startTime, endTime, purpose, participants, specialRequirements, contactNumber } =
      req.body

    // Validate required fields
    if (!type || !startTime || !endTime || !purpose || !contactNumber) {
      return sendError(res, "Missing required fields", 400)
    }

    // Validate booking time
    const start = new Date(startTime)
    const end = new Date(endTime)
    const now = new Date()

    if (start <= now) {
      return sendError(res, "Booking start time must be in the future", 400)
    }

    if (end <= start) {
      return sendError(res, "End time must be after start time", 400)
    }

    // Check for conflicting bookings
    const conflictingBooking = await Booking.findOne({
      type,
      "facility.name": facility?.name,
      status: { $in: ["approved", "pending"] },
      $or: [
        {
          startTime: { $lt: end },
          endTime: { $gt: start },
        },
      ],
    })

    if (conflictingBooking) {
      return sendError(res, "Time slot is already booked", 400)
    }

    const booking = new Booking({
      type,
      facility,
      equipment,
      startTime: start,
      endTime: end,
      bookedBy: req.user._id,
      purpose,
      participants,
      specialRequirements,
      contactNumber,
    })

    await booking.save()

    const populatedBooking = await Booking.findById(booking._id).populate("bookedBy", "name rollNo email")

    sendSuccess(res, populatedBooking, "Booking created successfully", 201)
  } catch (error) {
    console.error("Create booking error:", error)
    sendError(res, "Failed to create booking", 500)
  }
})

// @route   PUT /api/sports/bookings/:id/status
// @desc    Update booking status (Admin only)
// @access  Private (Admin only)
router.put("/bookings/:id/status", [authenticateToken, requireAdmin], async (req, res) => {
  try {
    const { id } = req.params
    const { status, rejectionReason } = req.body

    if (!["approved", "rejected"].includes(status)) {
      return sendError(res, "Invalid status", 400)
    }

    const booking = await Booking.findById(id)
    if (!booking) {
      return sendNotFound(res, "Booking")
    }

    booking.status = status
    booking.approvedBy = req.user._id
    booking.approvalDate = new Date()

    if (status === "rejected" && rejectionReason) {
      booking.rejectionReason = rejectionReason
    }

    await booking.save()

    const updatedBooking = await Booking.findById(id)
      .populate("bookedBy", "name rollNo email")
      .populate("approvedBy", "name")

    sendSuccess(res, updatedBooking, `Booking ${status} successfully`)
  } catch (error) {
    console.error("Update booking status error:", error)
    sendError(res, "Failed to update booking status", 500)
  }
})

// @route   GET /api/sports/facilities
// @desc    Get available facilities
// @access  Private
router.get("/facilities", authenticateToken, async (req, res) => {
  try {
    const facilities = [
      {
        id: "cricket-ground",
        name: "Cricket Ground",
        type: "cricket-ground",
        capacity: 22,
        location: "Sports Complex A",
        amenities: ["Pavilion", "Scoreboard", "Floodlights"],
        bookingDuration: { min: 2, max: 8 }, // hours
        availableHours: { start: "06:00", end: "20:00" },
      },
      {
        id: "football-field",
        name: "Football Field",
        type: "football-field",
        capacity: 22,
        location: "Sports Complex B",
        amenities: ["Goal Posts", "Changing Rooms", "Floodlights"],
        bookingDuration: { min: 1, max: 4 },
        availableHours: { start: "06:00", end: "22:00" },
      },
      {
        id: "basketball-court-1",
        name: "Basketball Court 1",
        type: "basketball-court",
        capacity: 10,
        location: "Indoor Sports Complex",
        amenities: ["Scoreboard", "Air Conditioning"],
        bookingDuration: { min: 1, max: 3 },
        availableHours: { start: "06:00", end: "22:00" },
      },
      {
        id: "basketball-court-2",
        name: "Basketball Court 2",
        type: "basketball-court",
        capacity: 10,
        location: "Indoor Sports Complex",
        amenities: ["Scoreboard", "Air Conditioning"],
        bookingDuration: { min: 1, max: 3 },
        availableHours: { start: "06:00", end: "22:00" },
      },
      {
        id: "volleyball-court",
        name: "Volleyball Court",
        type: "volleyball-court",
        capacity: 12,
        location: "Outdoor Courts",
        amenities: ["Net", "Sand Court"],
        bookingDuration: { min: 1, max: 3 },
        availableHours: { start: "06:00", end: "20:00" },
      },
      {
        id: "tennis-court-1",
        name: "Tennis Court 1",
        type: "tennis-court",
        capacity: 4,
        location: "Tennis Complex",
        amenities: ["Floodlights", "Hard Court"],
        bookingDuration: { min: 1, max: 2 },
        availableHours: { start: "06:00", end: "22:00" },
      },
      {
        id: "tennis-court-2",
        name: "Tennis Court 2",
        type: "tennis-court",
        capacity: 4,
        location: "Tennis Complex",
        amenities: ["Floodlights", "Hard Court"],
        bookingDuration: { min: 1, max: 2 },
        availableHours: { start: "06:00", end: "22:00" },
      },
      {
        id: "badminton-court-1",
        name: "Badminton Court 1",
        type: "badminton-court",
        capacity: 4,
        location: "Indoor Sports Complex",
        amenities: ["Wooden Floor", "Air Conditioning"],
        bookingDuration: { min: 1, max: 2 },
        availableHours: { start: "06:00", end: "22:00" },
      },
      {
        id: "badminton-court-2",
        name: "Badminton Court 2",
        type: "badminton-court",
        capacity: 4,
        location: "Indoor Sports Complex",
        amenities: ["Wooden Floor", "Air Conditioning"],
        bookingDuration: { min: 1, max: 2 },
        availableHours: { start: "06:00", end: "22:00" },
      },
      {
        id: "gymnasium",
        name: "Gymnasium",
        type: "gymnasium",
        capacity: 50,
        location: "Main Building",
        amenities: ["Equipment", "Mirrors", "Air Conditioning", "Sound System"],
        bookingDuration: { min: 1, max: 4 },
        availableHours: { start: "05:00", end: "23:00" },
      },
    ]

    sendSuccess(res, facilities, "Facilities retrieved successfully")
  } catch (error) {
    console.error("Get facilities error:", error)
    sendError(res, "Failed to retrieve facilities", 500)
  }
})

// @route   GET /api/sports/equipment
// @desc    Get available equipment
// @access  Private
router.get("/equipment", authenticateToken, async (req, res) => {
  try {
    const equipment = [
      {
        category: "Cricket",
        items: [
          { name: "Cricket Bat", available: 15, condition: "good" },
          { name: "Cricket Ball", available: 25, condition: "excellent" },
          { name: "Wicket Set", available: 3, condition: "good" },
          { name: "Protective Gear Set", available: 8, condition: "fair" },
        ],
      },
      {
        category: "Football",
        items: [
          { name: "Football", available: 20, condition: "excellent" },
          { name: "Goal Net", available: 4, condition: "good" },
          { name: "Cones", available: 50, condition: "good" },
        ],
      },
      {
        category: "Basketball",
        items: [
          { name: "Basketball", available: 15, condition: "excellent" },
          { name: "Basketball Hoop", available: 4, condition: "good" },
        ],
      },
      {
        category: "Volleyball",
        items: [
          { name: "Volleyball", available: 12, condition: "excellent" },
          { name: "Volleyball Net", available: 2, condition: "good" },
        ],
      },
      {
        category: "Tennis",
        items: [
          { name: "Tennis Racket", available: 20, condition: "good" },
          { name: "Tennis Ball", available: 100, condition: "excellent" },
          { name: "Tennis Net", available: 4, condition: "good" },
        ],
      },
      {
        category: "Badminton",
        items: [
          { name: "Badminton Racket", available: 25, condition: "good" },
          { name: "Shuttlecock", available: 200, condition: "excellent" },
          { name: "Badminton Net", available: 4, condition: "good" },
        ],
      },
      {
        category: "General",
        items: [
          { name: "Stopwatch", available: 10, condition: "excellent" },
          { name: "Whistle", available: 15, condition: "good" },
          { name: "First Aid Kit", available: 5, condition: "excellent" },
          { name: "Water Bottles", available: 30, condition: "good" },
        ],
      },
    ]

    sendSuccess(res, equipment, "Equipment list retrieved successfully")
  } catch (error) {
    console.error("Get equipment error:", error)
    sendError(res, "Failed to retrieve equipment list", 500)
  }
})

module.exports = router
