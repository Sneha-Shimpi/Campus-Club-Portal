const jwt = require("jsonwebtoken")
const crypto = require("crypto")

// Generate JWT access token
const generateAccessToken = (payload) => {
  return jwt.sign(payload, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE || "7d",
  })
}

// Generate JWT refresh token
const generateRefreshToken = (payload) => {
  return jwt.sign(payload, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRE || "30d",
  })
}

// Generate both access and refresh tokens
const generateTokenPair = (userId) => {
  const payload = { userId }

  return {
    accessToken: generateAccessToken(payload),
    refreshToken: generateRefreshToken(payload),
  }
}

// Verify JWT token
const verifyToken = (token, secret) => {
  try {
    return jwt.verify(token, secret)
  } catch (error) {
    throw error
  }
}

// Generate random token for password reset, email verification, etc.
const generateRandomToken = () => {
  return crypto.randomBytes(32).toString("hex")
}

// Hash token for storage
const hashToken = (token) => {
  return crypto.createHash("sha256").update(token).digest("hex")
}

// Extract token from Authorization header
const extractTokenFromHeader = (authHeader) => {
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return null
  }
  return authHeader.substring(7) // Remove 'Bearer ' prefix
}

// Check if token is expired
const isTokenExpired = (token) => {
  try {
    const decoded = jwt.decode(token)
    if (!decoded || !decoded.exp) return true

    const currentTime = Math.floor(Date.now() / 1000)
    return decoded.exp < currentTime
  } catch (error) {
    return true
  }
}

// Get token expiration time
const getTokenExpiration = (token) => {
  try {
    const decoded = jwt.decode(token)
    return decoded?.exp ? new Date(decoded.exp * 1000) : null
  } catch (error) {
    return null
  }
}

module.exports = {
  generateAccessToken,
  generateRefreshToken,
  generateTokenPair,
  verifyToken,
  generateRandomToken,
  hashToken,
  extractTokenFromHeader,
  isTokenExpired,
  getTokenExpiration,
}
