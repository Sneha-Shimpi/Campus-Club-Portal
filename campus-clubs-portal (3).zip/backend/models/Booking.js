const mongoose = require("mongoose")

const bookingSchema = new mongoose.Schema({
  // Booking Details
  type: {
    type: String,
    enum: ["ground", "equipment"],
    required: [true, "Booking type is required"],
  },

  // Ground Booking
  facility: {
    name: {
      type: String,
      required: [true, "Facility name is required"],
    },
    type: {
      type: String,
      enum: [
        "cricket-ground",
        "football-field",
        "basketball-court",
        "volleyball-court",
        "tennis-court",
        "badminton-court",
        "gymnasium",
        "swimming-pool",
      ],
    },
    capacity: Number,
    location: String,
  },

  // Equipment Booking
  equipment: [
    {
      name: String,
      quantity: Number,
      condition: {
        type: String,
        enum: ["excellent", "good", "fair", "needs-repair"],
        default: "good",
      },
    },
  ],

  // Booking Time
  startTime: {
    type: Date,
    required: [true, "Start time is required"],
  },
  endTime: {
    type: Date,
    required: [true, "End time is required"],
  },

  // User Information
  bookedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: [true, "Booking user is required"],
  },
  purpose: {
    type: String,
    required: [true, "Booking purpose is required"],
    maxlength: [200, "Purpose cannot exceed 200 characters"],
  },

  // Status
  status: {
    type: String,
    enum: ["pending", "approved", "rejected", "completed", "cancelled"],
    default: "pending",
  },

  // Approval
  approvedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  approvalDate: Date,
  rejectionReason: String,

  // Additional Information
  participants: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  ],
  specialRequirements: String,
  contactNumber: {
    type: String,
    required: [true, "Contact number is required"],
  },

  // Timestamps
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

// Indexes
bookingSchema.index({ bookedBy: 1 })
bookingSchema.index({ startTime: 1, endTime: 1 })
bookingSchema.index({ status: 1 })
bookingSchema.index({ "facility.type": 1 })

// Validation to ensure end time is after start time
bookingSchema.pre("save", function (next) {
  if (this.endTime <= this.startTime) {
    next(new Error("End time must be after start time"))
  }
  this.updatedAt = Date.now()
  next()
})

module.exports = mongoose.model("Booking", bookingSchema)
