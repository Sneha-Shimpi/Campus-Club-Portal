const mongoose = require("mongoose")

const mediaAccessSchema = new mongoose.Schema({
  studentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  privacyCode: {
    type: String,
    required: true,
    match: [/^\d{6}$/, "Privacy code must be 6 digits"],
  },
  accessGrantedAt: {
    type: Date,
    default: Date.now,
  },
  lastAccessedAt: Date,
  isActive: {
    type: Boolean,
    default: true,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

module.exports = mongoose.model("MediaAccess", mediaAccessSchema)
