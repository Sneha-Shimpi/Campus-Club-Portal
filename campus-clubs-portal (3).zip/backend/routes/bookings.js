const express = require("express")
const router = express.Router()
const Booking = require("../models/Booking")
const auth = require("../middleware/auth")
const { generateResponse, generateError } = require("../utils/responseHelper")

// Create new booking
router.post("/", auth, async (req, res) => {
  try {
    const { facility, date, time, purpose, participants, contactPerson, phone, additionalNotes } = req.body

    const bookingDate = new Date(date)
    const [startHour, startMin] = time.split(" - ")[0].split(":").map(Number)
    const [endHour, endMin] = time.split(" - ")[1].split(":").map(Number)

    const startTime = new Date(bookingDate)
    startTime.setHours(startHour, startMin, 0)

    const endTime = new Date(bookingDate)
    endTime.setHours(endHour, endMin, 0)

    const booking = new Booking({
      type: "ground",
      facility: {
        name: facility,
        type: facility,
        capacity: participants,
      },
      startTime,
      endTime,
      bookedBy: req.user.id,
      purpose,
      contactNumber: phone,
      specialRequirements: additionalNotes,
      status: "pending",
    })

    await booking.save()

    res.status(201).json(
      generateResponse({
        message: "Booking created successfully",
        booking,
      }),
    )
  } catch (error) {
    res.status(500).json(generateError(error.message))
  }
})

// Get user bookings
router.get("/user/:userId", auth, async (req, res) => {
  try {
    const bookings = await Booking.find({ bookedBy: req.params.userId })
      .populate("bookedBy", "name email")
      .populate("approvedBy", "name")

    res.status(200).json(generateResponse({ bookings }))
  } catch (error) {
    res.status(500).json(generateError(error.message))
  }
})

// Get all bookings (admin only)
router.get("/", auth, async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate("bookedBy", "name email rollNo")
      .populate("approvedBy", "name")
      .sort({ createdAt: -1 })

    res.status(200).json(generateResponse({ bookings }))
  } catch (error) {
    res.status(500).json(generateError(error.message))
  }
})

// Update booking status (admin)
router.put("/:bookingId/status", auth, async (req, res) => {
  try {
    const { status, rejectionReason } = req.body

    const booking = await Booking.findByIdAndUpdate(
      req.params.bookingId,
      {
        status,
        rejectionReason: status === "rejected" ? rejectionReason : undefined,
        approvedBy: req.user.id,
        approvalDate: new Date(),
      },
      { new: true },
    )

    if (!booking) {
      return res.status(404).json(generateError("Booking not found", 404))
    }

    res.status(200).json(
      generateResponse({
        message: "Booking status updated",
        booking,
      }),
    )
  } catch (error) {
    res.status(500).json(generateError(error.message))
  }
})

module.exports = router
