const mongoose = require("mongoose")

const nssActivitySchema = new mongoose.Schema({
  // Activity Details
  title: {
    type: String,
    required: [true, "Activity title is required"],
    trim: true,
  },
  description: {
    type: String,
    required: [true, "Activity description is required"],
  },
  category: {
    type: String,
    enum: ["environment", "education", "health", "community-service", "disaster-relief", "awareness", "other"],
    required: [true, "Activity category is required"],
  },

  // Volunteer Information
  volunteer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: [true, "Volunteer is required"],
  },

  // Time Tracking
  date: {
    type: Date,
    required: [true, "Activity date is required"],
  },
  hoursContributed: {
    type: Number,
    required: [true, "Hours contributed is required"],
    min: [0.5, "Minimum 0.5 hours required"],
    max: [24, "Maximum 24 hours per day"],
  },

  // Location
  location: {
    type: String,
    required: [true, "Activity location is required"],
  },

  // Impact Metrics
  impact: {
    treesPlanted: {
      type: Number,
      default: 0,
    },
    wasteCollected: {
      type: Number, // in kg
      default: 0,
    },
    peopleHelped: {
      type: Number,
      default: 0,
    },
    bloodDonated: {
      type: Number, // in units
      default: 0,
    },
    fundsRaised: {
      type: Number, // in rupees
      default: 0,
    },
    awarenessReached: {
      type: Number, // number of people
      default: 0,
    },
  },

  // Verification
  status: {
    type: String,
    enum: ["pending", "verified", "rejected"],
    default: "pending",
  },
  verifiedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  verificationDate: Date,
  verificationNotes: String,

  // Evidence
  photos: [String],
  documents: [String],

  // Collaboration
  collaborators: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  ],
  organizingBody: {
    type: String,
    maxlength: [100, "Organizing body name cannot exceed 100 characters"],
  },

  // Feedback
  reflection: {
    type: String,
    maxlength: [500, "Reflection cannot exceed 500 characters"],
  },
  challenges: {
    type: String,
    maxlength: [300, "Challenges cannot exceed 300 characters"],
  },
  learnings: {
    type: String,
    maxlength: [300, "Learnings cannot exceed 300 characters"],
  },

  // Timestamps
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

// Indexes
nssActivitySchema.index({ volunteer: 1, date: -1 })
nssActivitySchema.index({ category: 1, status: 1 })
nssActivitySchema.index({ verifiedBy: 1 })

// Pre-save middleware
nssActivitySchema.pre("save", function (next) {
  this.updatedAt = Date.now()
  next()
})

module.exports = mongoose.model("NSSActivity", nssActivitySchema)
