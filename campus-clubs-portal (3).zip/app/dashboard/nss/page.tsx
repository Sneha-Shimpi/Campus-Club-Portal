"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Heart, Calendar, Users, TreePine, Droplets, Clock, Award, Plus, MapPin, Target } from "lucide-react"
import Link from "next/link"

// Mock data - in real app, this would come from API
const nssStats = {
  totalHours: 45,
  targetHours: 60,
  eventsAttended: 8,
  treesPlanted: 25,
  bloodDonated: 2,
  peopleHelped: 150,
  currentRank: "Active Volunteer",
  impactScore: 85,
}

const upcomingEvents = [
  {
    id: 1,
    title: "Tree Plantation Drive",
    date: "2024-01-18",
    time: "8:00 AM",
    duration: "4 hours",
    location: "Campus Garden",
    volunteers: 25,
    maxVolunteers: 50,
    category: "Environment",
    description: "Join us in planting native trees around the campus",
  },
  {
    id: 2,
    title: "Blood Donation Camp",
    date: "2024-01-22",
    time: "9:00 AM",
    duration: "6 hours",
    location: "Main Auditorium",
    volunteers: 40,
    maxVolunteers: 100,
    category: "Health",
    description: "Help save lives by donating blood",
  },
  {
    id: 3,
    title: "Community Clean-up",
    date: "2024-01-25",
    time: "7:00 AM",
    duration: "3 hours",
    location: "Local Park",
    volunteers: 15,
    maxVolunteers: 30,
    category: "Environment",
    description: "Clean and beautify the local community park",
  },
]

const recentActivities = [
  {
    id: 1,
    title: "Literacy Program",
    date: "2024-01-10",
    hours: 4,
    category: "Education",
    impact: "Taught 20 children",
    status: "completed",
  },
  {
    id: 2,
    title: "Food Distribution",
    date: "2024-01-08",
    hours: 3,
    category: "Social Service",
    impact: "Fed 50 families",
    status: "completed",
  },
  {
    id: 3,
    title: "Health Awareness Camp",
    date: "2024-01-05",
    hours: 5,
    category: "Health",
    impact: "Reached 100 people",
    status: "completed",
  },
]

const impactMetrics = [
  { label: "Trees Planted", value: nssStats.treesPlanted, icon: TreePine, color: "text-green-600", target: 50 },
  { label: "Blood Units Donated", value: nssStats.bloodDonated, icon: Droplets, color: "text-red-600", target: 4 },
  { label: "People Helped", value: nssStats.peopleHelped, icon: Users, color: "text-blue-600", target: 200 },
  { label: "Events Attended", value: nssStats.eventsAttended, icon: Calendar, color: "text-purple-600", target: 12 },
]

export default function NSSPage() {
  const [selectedCategory, setSelectedCategory] = useState("all")

  const handleEventSignup = (eventId: number) => {
    // TODO: Implement event signup API call
    console.log("Signing up for event:", eventId)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-heading flex items-center gap-2">
            <Heart className="h-8 w-8 text-primary" />
            NSS Volunteer
          </h1>
          <p className="text-muted-foreground">Track your volunteer hours and community impact</p>
        </div>
        <div className="flex gap-2">
          <Link href="/dashboard/nss/log-hours">
            <Button variant="outline" className="flex items-center gap-2 bg-transparent">
              <Clock className="h-4 w-4" />
              Log Hours
            </Button>
          </Link>
          <Link href="/dashboard/nss/events">
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Join Event
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Volunteer Hours</p>
                <p className="text-2xl font-bold">{nssStats.totalHours}</p>
                <p className="text-xs text-muted-foreground">of {nssStats.targetHours} target</p>
              </div>
              <Clock className="h-8 w-8 text-muted-foreground" />
            </div>
            <Progress value={(nssStats.totalHours / nssStats.targetHours) * 100} className="mt-3 h-2" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Impact Score</p>
                <p className="text-2xl font-bold">{nssStats.impactScore}</p>
                <p className="text-xs text-muted-foreground">Community impact</p>
              </div>
              <Target className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Events Joined</p>
                <p className="text-2xl font-bold">{nssStats.eventsAttended}</p>
                <p className="text-xs text-muted-foreground">This semester</p>
              </div>
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Current Rank</p>
                <p className="text-lg font-bold">{nssStats.currentRank}</p>
              </div>
              <Award className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="events" className="space-y-4">
        <TabsList>
          <TabsTrigger value="events">Upcoming Events</TabsTrigger>
          <TabsTrigger value="impact">Impact Dashboard</TabsTrigger>
          <TabsTrigger value="history">My Activities</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
        </TabsList>

        {/* Events Tab */}
        <TabsContent value="events" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Volunteer Opportunities
              </CardTitle>
              <CardDescription>Join upcoming community service events</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingEvents.map((event) => (
                  <div key={event.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-lg">{event.title}</h3>
                          <Badge variant="outline">{event.category}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground mb-3">{event.description}</p>
                        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3 text-muted-foreground" />
                            <span>{event.date}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3 text-muted-foreground" />
                            <span>
                              {event.time} ({event.duration})
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="h-3 w-3 text-muted-foreground" />
                            <span>{event.location}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="h-3 w-3 text-muted-foreground" />
                            <span>
                              {event.volunteers}/{event.maxVolunteers} volunteers
                            </span>
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col gap-2 ml-4">
                        <Button
                          size="sm"
                          onClick={() => handleEventSignup(event.id)}
                          disabled={event.volunteers >= event.maxVolunteers}
                        >
                          {event.volunteers >= event.maxVolunteers ? "Full" : "Join Event"}
                        </Button>
                        <Progress value={(event.volunteers / event.maxVolunteers) * 100} className="w-20 h-2" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Impact Dashboard Tab */}
        <TabsContent value="impact" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Impact Metrics */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Community Impact
                </CardTitle>
                <CardDescription>Your contribution to society</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {impactMetrics.map((metric, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <metric.icon className={`h-4 w-4 ${metric.color}`} />
                          <span className="font-medium">{metric.label}</span>
                        </div>
                        <span className="font-bold">
                          {metric.value}/{metric.target}
                        </span>
                      </div>
                      <Progress value={(metric.value / metric.target) * 100} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Impact Visualization */}
            <Card>
              <CardHeader>
                <CardTitle>Monthly Progress</CardTitle>
                <CardDescription>Your volunteer activity this month</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-primary mb-2">{nssStats.totalHours}</div>
                    <p className="text-sm text-muted-foreground">Hours volunteered this month</p>
                  </div>
                  <div className="grid grid-cols-3 gap-4 text-center">
                    <div>
                      <div className="text-xl font-bold text-green-600">{nssStats.treesPlanted}</div>
                      <p className="text-xs text-muted-foreground">Trees Planted</p>
                    </div>
                    <div>
                      <div className="text-xl font-bold text-red-600">{nssStats.bloodDonated}</div>
                      <p className="text-xs text-muted-foreground">Blood Units</p>
                    </div>
                    <div>
                      <div className="text-xl font-bold text-blue-600">{nssStats.peopleHelped}</div>
                      <p className="text-xs text-muted-foreground">People Helped</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Environmental Impact */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TreePine className="h-5 w-5 text-green-600" />
                Environmental Impact
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <TreePine className="h-8 w-8 text-green-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-green-600">{nssStats.treesPlanted}</div>
                  <p className="text-sm text-green-700">Trees Planted</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    ≈ {nssStats.treesPlanted * 22} kg CO₂ absorbed/year
                  </p>
                </div>
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <Droplets className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-blue-600">5</div>
                  <p className="text-sm text-blue-700">Clean-up Events</p>
                  <p className="text-xs text-muted-foreground mt-1">≈ 200 kg waste collected</p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <Award className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-purple-600">3</div>
                  <p className="text-sm text-purple-700">Awareness Campaigns</p>
                  <p className="text-xs text-muted-foreground mt-1">≈ 500 people reached</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* History Tab */}
        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Recent Activities
              </CardTitle>
              <CardDescription>Your volunteer history and contributions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-center gap-4 p-4 border rounded-lg">
                    <div
                      className={`p-2 rounded-lg ${
                        activity.category === "Education"
                          ? "bg-blue-100 text-blue-700"
                          : activity.category === "Health"
                            ? "bg-red-100 text-red-700"
                            : activity.category === "Environment"
                              ? "bg-green-100 text-green-700"
                              : "bg-purple-100 text-purple-700"
                      }`}
                    >
                      {activity.category === "Education" ? (
                        <Users className="h-4 w-4" />
                      ) : activity.category === "Health" ? (
                        <Heart className="h-4 w-4" />
                      ) : activity.category === "Environment" ? (
                        <TreePine className="h-4 w-4" />
                      ) : (
                        <Award className="h-4 w-4" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold">{activity.title}</h4>
                        <Badge variant="outline">{activity.category}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{activity.impact}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold">{activity.hours}h</p>
                      <p className="text-sm text-muted-foreground">{activity.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Achievements Tab */}
        <TabsContent value="achievements" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Volunteer Badges
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 border rounded-lg">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <TreePine className="h-6 w-6 text-green-600" />
                    </div>
                    <h4 className="font-semibold text-sm">Eco Warrior</h4>
                    <p className="text-xs text-muted-foreground">Planted 25+ trees</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Heart className="h-6 w-6 text-red-600" />
                    </div>
                    <h4 className="font-semibold text-sm">Life Saver</h4>
                    <p className="text-xs text-muted-foreground">Donated blood 2+ times</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Users className="h-6 w-6 text-blue-600" />
                    </div>
                    <h4 className="font-semibold text-sm">Community Helper</h4>
                    <p className="text-xs text-muted-foreground">Helped 100+ people</p>
                  </div>
                  <div className="text-center p-4 border rounded-lg opacity-50">
                    <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Clock className="h-6 w-6 text-gray-400" />
                    </div>
                    <h4 className="font-semibold text-sm">Time Master</h4>
                    <p className="text-xs text-muted-foreground">Complete 60 hours</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Volunteer Certificate</CardTitle>
                <CardDescription>Download your volunteer service certificate</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center p-6 border-2 border-dashed rounded-lg">
                  <Award className="h-12 w-12 text-primary mx-auto mb-3" />
                  <h3 className="font-semibold mb-2">NSS Volunteer Certificate</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {nssStats.totalHours} hours of community service completed
                  </p>
                  <Button>Download Certificate</Button>
                </div>
                <div className="text-xs text-muted-foreground text-center">
                  Certificate will be available after completing 60 volunteer hours
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
