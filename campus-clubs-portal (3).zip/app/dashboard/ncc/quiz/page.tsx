"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { useToast } from "@/hooks/use-toast"
import { BookOpen, Clock, CheckCircle, X, ArrowLeft, ArrowRight } from "lucide-react"

// Mock quiz data
const quizData = {
  title: "Drill Commands & Procedures",
  description: "Test your knowledge of basic NCC drill commands and parade procedures",
  timeLimit: 30, // minutes
  totalQuestions: 10,
  passingScore: 70,
  questions: [
    {
      id: 1,
      question: "What is the command to bring the squad to attention?",
      options: ["Squad Halt", "Squad Attention", "Squad Ready", "Squad Stand"],
      correct: 1,
    },
    {
      id: 2,
      question: "How many steps are there in a standard right turn?",
      options: ["1 step", "2 steps", "3 steps", "4 steps"],
      correct: 0,
    },
    {
      id: 3,
      question: "What is the correct position for 'Present Arms'?",
      options: [
        "Rifle held horizontally",
        "Rifle held vertically at shoulder",
        "Rifle held at waist level",
        "Rifle held above head",
      ],
      correct: 1,
    },
    {
      id: 4,
      question: "Which foot do you start with when marching?",
      options: ["Right foot", "Left foot", "Either foot", "Both feet together"],
      correct: 1,
    },
    {
      id: 5,
      question: "What is the standard pace for quick march?",
      options: ["100 steps/min", "116 steps/min", "120 steps/min", "140 steps/min"],
      correct: 2,
    },
  ],
}

export default function QuizPage() {
  const { toast } = useToast()
  const [quizStarted, setQuizStarted] = useState(false)
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [answers, setAnswers] = useState<number[]>([])
  const [timeRemaining, setTimeRemaining] = useState(quizData.timeLimit * 60) // in seconds
  const [quizCompleted, setQuizCompleted] = useState(false)
  const [score, setScore] = useState(0)

  const startQuiz = () => {
    setQuizStarted(true)
    setAnswers(new Array(quizData.questions.length).fill(-1))
    // Start timer
    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer)
          submitQuiz()
          return 0
        }
        return prev - 1
      })
    }, 1000)
  }

  const handleAnswerSelect = (questionIndex: number, answerIndex: number) => {
    const newAnswers = [...answers]
    newAnswers[questionIndex] = answerIndex
    setAnswers(newAnswers)
  }

  const nextQuestion = () => {
    if (currentQuestion < quizData.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1)
    }
  }

  const prevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1)
    }
  }

  const submitQuiz = () => {
    let correctAnswers = 0
    quizData.questions.forEach((question, index) => {
      if (answers[index] === question.correct) {
        correctAnswers++
      }
    })

    const finalScore = Math.round((correctAnswers / quizData.questions.length) * 100)
    setScore(finalScore)
    setQuizCompleted(true)

    toast({
      title: finalScore >= quizData.passingScore ? "Quiz Passed!" : "Quiz Failed",
      description: `You scored ${finalScore}%. ${
        finalScore >= quizData.passingScore ? "Congratulations!" : "Better luck next time!"
      }`,
      variant: finalScore >= quizData.passingScore ? "default" : "destructive",
    })
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, "0")}`
  }

  if (!quizStarted) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold font-heading">NCC Knowledge Quiz</h1>
          <p className="text-muted-foreground">Test your understanding of NCC concepts and procedures</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  {quizData.title}
                </CardTitle>
                <CardDescription>{quizData.description}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid sm:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-primary">{quizData.totalQuestions}</div>
                    <p className="text-sm text-muted-foreground">Questions</p>
                  </div>
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-primary">{quizData.timeLimit}</div>
                    <p className="text-sm text-muted-foreground">Minutes</p>
                  </div>
                  <div className="text-center p-4 bg-muted rounded-lg">
                    <div className="text-2xl font-bold text-primary">{quizData.passingScore}%</div>
                    <p className="text-sm text-muted-foreground">Pass Mark</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold">Instructions:</h3>
                  <ul className="space-y-2 text-sm text-muted-foreground">
                    <li>• Read each question carefully before selecting your answer</li>
                    <li>• You can navigate between questions using the Previous/Next buttons</li>
                    <li>• You must score at least {quizData.passingScore}% to pass</li>
                    <li>• The quiz will auto-submit when time runs out</li>
                    <li>• Make sure you have a stable internet connection</li>
                  </ul>
                </div>

                <Button onClick={startQuiz} className="w-full" size="lg">
                  Start Quiz
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Recent Quiz Results</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <p className="font-semibold text-sm">Weapon Training</p>
                      <p className="text-xs text-muted-foreground">Jan 10, 2024</p>
                    </div>
                    <Badge variant="secondary">92%</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <p className="font-semibold text-sm">Military History</p>
                      <p className="text-xs text-muted-foreground">Jan 8, 2024</p>
                    </div>
                    <Badge variant="secondary">88%</Badge>
                  </div>
                  <div className="flex justify-between items-center p-3 border rounded-lg">
                    <div>
                      <p className="font-semibold text-sm">Leadership</p>
                      <p className="text-xs text-muted-foreground">Jan 5, 2024</p>
                    </div>
                    <Badge variant="destructive">65%</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quiz Tips</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2 text-sm">
                <p>• Review your training materials before starting</p>
                <p>• Take your time to read each question carefully</p>
                <p>• If unsure, eliminate obviously wrong answers first</p>
                <p>• Don't spend too much time on one question</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  if (quizCompleted) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold font-heading">Quiz Results</h1>
          <p className="text-muted-foreground">Your performance on {quizData.title}</p>
        </div>

        <div className="grid lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                {score >= quizData.passingScore ? (
                  <CheckCircle className="h-5 w-5 text-green-600" />
                ) : (
                  <X className="h-5 w-5 text-red-600" />
                )}
                Quiz {score >= quizData.passingScore ? "Passed" : "Failed"}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center">
                <div
                  className={`text-6xl font-bold ${score >= quizData.passingScore ? "text-green-600" : "text-red-600"}`}
                >
                  {score}%
                </div>
                <p className="text-muted-foreground">Your Score</p>
              </div>

              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Correct Answers</span>
                  <span className="font-semibold">
                    {Math.round((score / 100) * quizData.questions.length)}/{quizData.questions.length}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Passing Score</span>
                  <span className="font-semibold">{quizData.passingScore}%</span>
                </div>
                <div className="flex justify-between">
                  <span>Time Taken</span>
                  <span className="font-semibold">{formatTime(quizData.timeLimit * 60 - timeRemaining)}</span>
                </div>
              </div>

              <div className="flex gap-2">
                <Button onClick={() => window.location.reload()} className="flex-1">
                  Retake Quiz
                </Button>
                <Button variant="outline" onClick={() => window.history.back()} className="flex-1">
                  Back to NCC
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Answer Review</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {quizData.questions.map((question, index) => (
                  <div key={question.id} className="p-3 border rounded-lg">
                    <div className="flex items-start gap-2">
                      {answers[index] === question.correct ? (
                        <CheckCircle className="h-4 w-4 text-green-600 mt-1" />
                      ) : (
                        <X className="h-4 w-4 text-red-600 mt-1" />
                      )}
                      <div className="flex-1">
                        <p className="font-semibold text-sm">
                          Q{index + 1}: {question.question}
                        </p>
                        <p className="text-xs text-muted-foreground mt-1">
                          Correct: {question.options[question.correct]}
                        </p>
                        {answers[index] !== question.correct && (
                          <p className="text-xs text-red-600">Your answer: {question.options[answers[index]]}</p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  const currentQ = quizData.questions[currentQuestion]

  return (
    <div className="space-y-6">
      {/* Header with Timer */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-heading">{quizData.title}</h1>
          <p className="text-muted-foreground">
            Question {currentQuestion + 1} of {quizData.questions.length}
          </p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            <span className="font-mono text-lg">{formatTime(timeRemaining)}</span>
          </div>
          <Badge variant="outline">
            {Math.round(((currentQuestion + 1) / quizData.questions.length) * 100)}% Complete
          </Badge>
        </div>
      </div>

      {/* Progress Bar */}
      <Progress value={((currentQuestion + 1) / quizData.questions.length) * 100} className="h-2" />

      <div className="grid lg:grid-cols-4 gap-6">
        {/* Question */}
        <div className="lg:col-span-3">
          <Card>
            <CardHeader>
              <CardTitle>Question {currentQuestion + 1}</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <h2 className="text-xl font-semibold">{currentQ.question}</h2>

              <RadioGroup
                value={answers[currentQuestion]?.toString()}
                onValueChange={(value) => handleAnswerSelect(currentQuestion, Number.parseInt(value))}
              >
                {currentQ.options.map((option, index) => (
                  <div key={index} className="flex items-center space-x-2 p-3 border rounded-lg hover:bg-muted">
                    <RadioGroupItem value={index.toString()} id={`option-${index}`} />
                    <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                      {option}
                    </Label>
                  </div>
                ))}
              </RadioGroup>

              <div className="flex justify-between">
                <Button variant="outline" onClick={prevQuestion} disabled={currentQuestion === 0}>
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Previous
                </Button>
                {currentQuestion === quizData.questions.length - 1 ? (
                  <Button onClick={submitQuiz} disabled={answers.includes(-1)}>
                    Submit Quiz
                  </Button>
                ) : (
                  <Button onClick={nextQuestion}>
                    Next
                    <ArrowRight className="h-4 w-4 ml-2" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Question Navigator */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Question Navigator</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-5 gap-2">
                {quizData.questions.map((_, index) => (
                  <Button
                    key={index}
                    variant={currentQuestion === index ? "default" : answers[index] !== -1 ? "secondary" : "outline"}
                    size="sm"
                    onClick={() => setCurrentQuestion(index)}
                    className="aspect-square"
                  >
                    {index + 1}
                  </Button>
                ))}
              </div>
              <div className="mt-4 space-y-2 text-xs">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-primary rounded"></div>
                  <span>Current</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-secondary rounded"></div>
                  <span>Answered</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 border rounded"></div>
                  <span>Not Answered</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
