const mongoose = require("mongoose")

const sportsMatchSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Match title is required"],
    trim: true,
  },
  sport: {
    type: String,
    required: [true, "Sport type is required"],
    enum: [
      "cricket",
      "football",
      "basketball",
      "volleyball",
      "tennis",
      "badminton",
      "table-tennis",
      "athletics",
      "other",
    ],
  },
  matchType: {
    type: String,
    enum: ["friendly", "tournament", "inter-college", "intra-college"],
    default: "friendly",
  },

  // Teams
  team1: {
    name: {
      type: String,
      required: [true, "Team 1 name is required"],
    },
    players: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    captain: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    score: {
      type: Number,
      default: 0,
    },
  },
  team2: {
    name: {
      type: String,
      required: [true, "Team 2 name is required"],
    },
    players: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    captain: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
    score: {
      type: Number,
      default: 0,
    },
  },

  // Match Details
  scheduledDate: {
    type: Date,
    required: [true, "Match date is required"],
  },
  venue: {
    type: String,
    required: [true, "Venue is required"],
  },
  duration: {
    type: Number, // in minutes
    default: 90,
  },

  // Match Status
  status: {
    type: String,
    enum: ["scheduled", "ongoing", "completed", "cancelled", "postponed"],
    default: "scheduled",
  },

  // Results
  winner: {
    type: String,
    enum: ["team1", "team2", "draw"],
  },
  matchSummary: {
    type: String,
    maxlength: [500, "Match summary cannot exceed 500 characters"],
  },

  // Statistics
  statistics: {
    attendance: Number,
    highlights: [String],
    playerStats: [
      {
        player: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        goals: Number,
        assists: Number,
        yellowCards: Number,
        redCards: Number,
        minutesPlayed: Number,
      },
    ],
  },

  // Media
  photos: [String],
  videos: [String],

  // Officials
  referee: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
  },
  organizer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: [true, "Organizer is required"],
  },

  // Timestamps
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

// Indexes
sportsMatchSchema.index({ sport: 1, status: 1 })
sportsMatchSchema.index({ scheduledDate: 1 })
sportsMatchSchema.index({ "team1.players": 1 })
sportsMatchSchema.index({ "team2.players": 1 })

module.exports = mongoose.model("SportsMatch", sportsMatchSchema)
