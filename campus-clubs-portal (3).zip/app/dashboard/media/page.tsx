"use client"

import type React from "react"

import { useState } from "react"
import { useAuth } from "@/components/auth/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/hooks/use-toast"
import { Upload, Lock, Play, Grid, List } from "lucide-react"
import Image from "next/image"

interface MediaItem {
  id: string
  url: string
  title: string
  type: "photo" | "video"
  eventName: string
  uploadedDate: string
  uploadedBy: string
}

export default function MediaGalleryPage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [mediaItems, setMediaItems] = useState<MediaItem[]>([])
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [privacyCode, setPrivacyCode] = useState("")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [isLoading, setIsLoading] = useState(false)

  const handlePrivacyCodeSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (privacyCode.length !== 6 || !/^\d+$/.test(privacyCode)) {
      toast({
        title: "Invalid Code",
        description: "Privacy code must be 6 digits",
        variant: "destructive",
      })
      return
    }

    setIsLoading(true)
    try {
      const response = await fetch("/api/media/verify-access", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          privacyCode,
          studentId: user?.id,
        }),
      })

      if (response.ok) {
        setIsAuthenticated(true)
        fetchMediaGallery()
        toast({
          title: "Success",
          description: "Access granted to media gallery",
        })
      } else {
        toast({
          title: "Error",
          description: "Invalid privacy code",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to verify access",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const fetchMediaGallery = async () => {
    try {
      const response = await fetch("/api/media/gallery")
      if (response.ok) {
        const data = await response.json()
        setMediaItems(data)
      }
    } catch (error) {
      console.error("Error fetching media:", error)
    }
  }

  if (!isAuthenticated) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold font-heading">Media Gallery</h1>
          <p className="text-muted-foreground">View event photos and videos from campus activities</p>
        </div>

        <div className="flex items-center justify-center min-h-[400px]">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Lock className="h-5 w-5" />
                Privacy Protected Gallery
              </CardTitle>
              <CardDescription>Enter your 6-digit privacy code to access the media gallery</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handlePrivacyCodeSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="privacy-code">Privacy Code</Label>
                  <Input
                    id="privacy-code"
                    type="password"
                    inputMode="numeric"
                    maxLength={6}
                    placeholder="Enter 6-digit code"
                    value={privacyCode}
                    onChange={(e) => setPrivacyCode(e.target.value.slice(0, 6))}
                  />
                  <p className="text-xs text-muted-foreground">You received this code when you logged in</p>
                </div>
                <Button type="submit" className="w-full" disabled={isLoading || privacyCode.length !== 6}>
                  {isLoading ? "Verifying..." : "Access Gallery"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-heading">Media Gallery</h1>
          <p className="text-muted-foreground">Photos and videos from campus club events</p>
        </div>
        <div className="flex gap-2">
          <Button variant={viewMode === "grid" ? "default" : "outline"} size="sm" onClick={() => setViewMode("grid")}>
            <Grid className="h-4 w-4" />
          </Button>
          <Button variant={viewMode === "list" ? "default" : "outline"} size="sm" onClick={() => setViewMode("list")}>
            <List className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {mediaItems.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Upload className="h-12 w-12 text-muted-foreground mb-4" />
            <h3 className="font-semibold mb-1">No media yet</h3>
            <p className="text-sm text-muted-foreground">Media from events will appear here soon</p>
          </CardContent>
        </Card>
      ) : viewMode === "grid" ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
          {mediaItems.map((item) => (
            <Card key={item.id} className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer">
              <div className="relative aspect-square bg-muted">
                {item.type === "photo" ? (
                  <Image
                    src={item.url || "/placeholder.svg"}
                    alt={item.title}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  />
                ) : (
                  <div className="absolute inset-0 bg-black/20 flex items-center justify-center">
                    <Play className="h-12 w-12 text-white" />
                  </div>
                )}
              </div>
              <CardContent className="pt-4 pb-2">
                <p className="font-semibold text-sm truncate">{item.title}</p>
                <p className="text-xs text-muted-foreground">{item.eventName}</p>
                <Badge variant="secondary" className="mt-2 text-xs">
                  {item.type}
                </Badge>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="space-y-2">
          {mediaItems.map((item) => (
            <Card key={item.id} className="hover:bg-muted transition-colors cursor-pointer">
              <CardContent className="flex items-center gap-4 py-4">
                <div className="h-16 w-16 bg-muted rounded-lg flex-shrink-0 flex items-center justify-center">
                  {item.type === "video" ? <Play className="h-8 w-8 text-muted-foreground" /> : "📷"}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold">{item.title}</p>
                  <p className="text-sm text-muted-foreground">{item.eventName}</p>
                  <div className="flex gap-2 mt-2">
                    <Badge variant="secondary" className="text-xs">
                      {item.type}
                    </Badge>
                    <span className="text-xs text-muted-foreground">{item.uploadedDate}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
