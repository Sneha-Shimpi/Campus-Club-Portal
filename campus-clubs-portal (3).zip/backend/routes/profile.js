const express = require("express")
const router = express.Router()
const User = require("../models/User")
const Profile = require("../models/Profile")
const auth = require("../middleware/auth")
const { generateResponse, generateError } = require("../utils/responseHelper")

// Get user profile
router.get("/:userId", auth, async (req, res) => {
  try {
    const user = await User.findById(req.params.userId).select("-password")
    if (!user) {
      return res.status(404).json(generateError("User not found", 404))
    }

    const profile = await Profile.findOne({ userId: req.params.userId })

    res.status(200).json(
      generateResponse({
        user,
        profile,
      }),
    )
  } catch (error) {
    res.status(500).json(generateError(error.message))
  }
})

// Update user profile
router.put("/:userId", auth, async (req, res) => {
  try {
    const { name, phone, department, year, bio } = req.body

    const user = await User.findByIdAndUpdate(
      req.params.userId,
      {
        name,
        phone,
        department,
        year,
      },
      { new: true, runValidators: true },
    )

    if (!user) {
      return res.status(404).json(generateError("User not found", 404))
    }

    let profile = await Profile.findOne({ userId: req.params.userId })
    if (!profile) {
      profile = new Profile({
        userId: req.params.userId,
        name,
        phone,
        department,
        year,
        bio,
        email: user.email,
        rollNo: user.rollNo,
      })
    } else {
      profile.name = name
      profile.phone = phone
      profile.department = department
      profile.year = year
      profile.bio = bio
      profile.updatedAt = new Date()
    }

    await profile.save()

    res.status(200).json(
      generateResponse({
        message: "Profile updated successfully",
        user: user.getPublicProfile(),
        profile,
      }),
    )
  } catch (error) {
    res.status(500).json(generateError(error.message))
  }
})

// Get activity transcript
router.get("/:userId/transcript", auth, async (req, res) => {
  try {
    const user = await User.findById(req.params.userId)
    if (!user) {
      return res.status(404).json(generateError("User not found", 404))
    }

    const transcriptData = {
      name: user.name,
      rollNo: user.rollNo,
      email: user.email,
      department: user.department,
      year: user.year,
      sports: user.sportsStats,
      nss: user.nssStats,
      ncc: user.nccStats,
      badges: user.badges,
      generatedAt: new Date(),
    }

    res.status(200).json(
      generateResponse({
        message: "Transcript generated",
        transcript: transcriptData,
      }),
    )
  } catch (error) {
    res.status(500).json(generateError(error.message))
  }
})

module.exports = router
