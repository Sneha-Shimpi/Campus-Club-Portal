const express = require("express")
const { validationResult, body } = require("express-validator")
const NCCTraining = require("../models/NCCTraining")
const Quiz = require("../models/Quiz")
const User = require("../models/User")
const { authenticateToken, requireAdmin, requireStudentOrAdmin } = require("../middleware/auth")
const { sendSuccess, sendError, sendValidationError, sendNotFound } = require("../utils/responseHelper")

const router = express.Router()

// @route   GET /api/ncc/dashboard
// @desc    Get NCC dashboard data
// @access  Private
router.get("/dashboard", authenticateToken, async (req, res) => {
  try {
    const userId = req.user._id

    // Get user's NCC statistics
    const user = await User.findById(userId)
    const nccStats = user.nccStats

    // Get upcoming training sessions
    const upcomingTraining = await NCCTraining.find({
      status: "scheduled",
      date: { $gte: new Date() },
    })
      .sort({ date: 1 })
      .limit(5)
      .populate("instructor", "name")

    // Get recent training attendance
    const recentTraining = await NCCTraining.find({
      "attendees.cadet": userId,
      status: "completed",
    })
      .sort({ date: -1 })
      .limit(5)
      .populate("instructor", "name")

    // Get available quizzes
    const availableQuizzes = await Quiz.find({
      isActive: true,
      startDate: { $lte: new Date() },
      endDate: { $gte: new Date() },
    })
      .sort({ createdAt: -1 })
      .limit(3)

    // Calculate monthly progress
    const currentMonth = new Date()
    currentMonth.setDate(1)
    currentMonth.setHours(0, 0, 0, 0)

    const monthlyTraining = await NCCTraining.find({
      "attendees.cadet": userId,
      date: { $gte: currentMonth },
      status: "completed",
    })

    const monthlyHours = monthlyTraining.reduce((total, training) => total + training.duration, 0)
    const monthlyAttendance = monthlyTraining.filter((training) => {
      const attendance = training.attendees.find((a) => a.cadet.toString() === userId.toString())
      return attendance && attendance.status === "present"
    }).length

    // Get rank progression info
    const ranks = ["Cadet", "Lance Corporal", "Corporal", "Sergeant", "Under Officer", "Cadet Captain"]
    const currentRankIndex = ranks.indexOf(nccStats.currentRank)
    const nextRank = currentRankIndex < ranks.length - 1 ? ranks[currentRankIndex + 1] : null

    // Calculate requirements for next rank
    const rankRequirements = {
      "Lance Corporal": { drills: 20, hours: 40, discipline: 85 },
      Corporal: { drills: 40, hours: 80, discipline: 88 },
      Sergeant: { drills: 60, hours: 120, discipline: 90 },
      "Under Officer": { drills: 80, hours: 160, discipline: 92 },
      "Cadet Captain": { drills: 100, hours: 200, discipline: 95 },
    }

    const nextRankRequirements = nextRank ? rankRequirements[nextRank] : null

    sendSuccess(
      res,
      {
        statistics: nccStats,
        upcomingTraining,
        recentTraining,
        availableQuizzes,
        monthlyProgress: {
          hours: monthlyHours,
          attendance: monthlyAttendance,
        },
        rankProgression: {
          currentRank: nccStats.currentRank,
          nextRank,
          requirements: nextRankRequirements,
          progress: nextRankRequirements
            ? {
                drills: Math.min((nccStats.drillsAttended / nextRankRequirements.drills) * 100, 100),
                hours: Math.min((nccStats.trainingHours / nextRankRequirements.hours) * 100, 100),
                discipline: Math.min((nccStats.disciplineScore / nextRankRequirements.discipline) * 100, 100),
              }
            : null,
        },
      },
      "NCC dashboard data retrieved successfully",
    )
  } catch (error) {
    console.error("NCC dashboard error:", error)
    sendError(res, "Failed to retrieve NCC dashboard data", 500)
  }
})

// @route   GET /api/ncc/training
// @desc    Get training sessions with filters
// @access  Private
router.get("/training", authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, type, status, startDate, endDate, instructor } = req.query

    // Build filter object
    const filter = {}
    if (type) filter.type = type
    if (status) filter.status = status
    if (instructor) filter.instructor = instructor

    if (startDate || endDate) {
      filter.date = {}
      if (startDate) filter.date.$gte = new Date(startDate)
      if (endDate) filter.date.$lte = new Date(endDate)
    }

    const skip = (page - 1) * limit

    const trainingSessions = await NCCTraining.find(filter)
      .populate("instructor", "name email")
      .populate("attendees.cadet", "name rollNo department")
      .sort({ date: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await NCCTraining.countDocuments(filter)

    sendSuccess(
      res,
      {
        trainingSessions,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalSessions: total,
          hasNext: page * limit < total,
          hasPrev: page > 1,
        },
      },
      "Training sessions retrieved successfully",
    )
  } catch (error) {
    console.error("Get training sessions error:", error)
    sendError(res, "Failed to retrieve training sessions", 500)
  }
})

// @route   POST /api/ncc/training
// @desc    Create a new training session (Admin only)
// @access  Private (Admin only)
router.post(
  "/training",
  [
    authenticateToken,
    requireAdmin,
    body("title").trim().isLength({ min: 3, max: 200 }).withMessage("Title must be between 3 and 200 characters"),
    body("type")
      .isIn(["drill", "theory", "practical", "camp", "parade", "shooting", "adventure", "social-service"])
      .withMessage("Invalid training type"),
    body("description")
      .trim()
      .isLength({ min: 10, max: 1000 })
      .withMessage("Description must be between 10 and 1000 characters"),
    body("date").isISO8601().withMessage("Please provide a valid date"),
    body("startTime")
      .matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/)
      .withMessage("Invalid start time format (HH:MM)"),
    body("endTime")
      .matches(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/)
      .withMessage("Invalid end time format (HH:MM)"),
    body("duration").isFloat({ min: 0.5, max: 12 }).withMessage("Duration must be between 0.5 and 12 hours"),
    body("venue").trim().isLength({ min: 3, max: 200 }).withMessage("Venue must be between 3 and 200 characters"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return sendValidationError(res, errors.array())
      }

      const {
        title,
        type,
        description,
        date,
        startTime,
        endTime,
        duration,
        venue,
        topics,
        objectives,
        resources,
        hasAssessment,
        assessmentType,
        maxMarks,
      } = req.body

      // Validate instructor exists
      const instructor = await User.findById(req.user._id)
      if (!instructor) {
        return sendError(res, "Instructor not found", 404)
      }

      const training = new NCCTraining({
        title,
        type,
        description,
        date: new Date(date),
        startTime,
        endTime,
        duration,
        venue,
        instructor: req.user._id,
        topics: topics || [],
        objectives: objectives || [],
        resources: resources || [],
        hasAssessment: hasAssessment || false,
        assessmentType,
        maxMarks,
      })

      await training.save()

      const populatedTraining = await NCCTraining.findById(training._id).populate("instructor", "name email")

      sendSuccess(res, populatedTraining, "Training session created successfully", 201)
    } catch (error) {
      console.error("Create training session error:", error)
      sendError(res, "Failed to create training session", 500)
    }
  },
)

// @route   PUT /api/ncc/training/:id/attendance
// @desc    Mark attendance for training session (Admin only)
// @access  Private (Admin only)
router.put("/training/:id/attendance", [authenticateToken, requireAdmin], async (req, res) => {
  try {
    const { id } = req.params
    const { attendees } = req.body

    if (!attendees || !Array.isArray(attendees)) {
      return sendError(res, "Attendees array is required", 400)
    }

    const training = await NCCTraining.findById(id)
    if (!training) {
      return sendNotFound(res, "Training session")
    }

    // Validate all cadets exist
    const cadetIds = attendees.map((a) => a.cadet)
    const cadets = await User.find({ _id: { $in: cadetIds } })
    if (cadets.length !== cadetIds.length) {
      return sendError(res, "Some cadets not found", 400)
    }

    // Update attendance
    training.attendees = attendees.map((attendee) => ({
      cadet: attendee.cadet,
      status: attendee.status || "present",
      arrivalTime: attendee.arrivalTime,
      performance: attendee.performance || "satisfactory",
      disciplineScore: attendee.disciplineScore || 8,
      notes: attendee.notes,
    }))

    training.status = "completed"
    await training.save()

    // Update cadet statistics
    for (const attendee of attendees) {
      const cadet = await User.findById(attendee.cadet)
      if (cadet && attendee.status === "present") {
        cadet.nccStats.drillsAttended += 1
        cadet.nccStats.trainingHours += training.duration

        // Update discipline score (weighted average)
        const currentScore = cadet.nccStats.disciplineScore
        const newScore = attendee.disciplineScore || 8
        cadet.nccStats.disciplineScore = Math.round((currentScore * 0.9 + newScore * 0.1) * 10) / 10

        await cadet.save()
      }
    }

    const updatedTraining = await NCCTraining.findById(id)
      .populate("instructor", "name")
      .populate("attendees.cadet", "name rollNo")

    sendSuccess(res, updatedTraining, "Attendance marked successfully")
  } catch (error) {
    console.error("Mark attendance error:", error)
    sendError(res, "Failed to mark attendance", 500)
  }
})

// @route   GET /api/ncc/quizzes
// @desc    Get available quizzes
// @access  Private
router.get("/quizzes", authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, category, active = true } = req.query
    const userId = req.user._id

    const filter = {}
    if (category) filter.category = category
    if (active === "true") {
      filter.isActive = true
      filter.startDate = { $lte: new Date() }
      filter.endDate = { $gte: new Date() }
    }

    const skip = (page - 1) * limit

    const quizzes = await Quiz.find(filter)
      .populate("createdBy", "name")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    // Add user's attempt information
    const quizzesWithAttempts = quizzes.map((quiz) => {
      const userAttempts = quiz.attempts.filter((attempt) => attempt.user.toString() === userId.toString())
      const quizObj = quiz.toObject()

      return {
        ...quizObj,
        questions: undefined, // Don't send questions in list view
        userAttempts: userAttempts.length,
        maxAttempts: quiz.maxAttempts,
        canAttempt: userAttempts.length < quiz.maxAttempts,
        bestScore: userAttempts.length > 0 ? Math.max(...userAttempts.map((a) => a.score || 0)) : null,
      }
    })

    const total = await Quiz.countDocuments(filter)

    sendSuccess(
      res,
      {
        quizzes: quizzesWithAttempts,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalQuizzes: total,
        },
      },
      "Quizzes retrieved successfully",
    )
  } catch (error) {
    console.error("Get quizzes error:", error)
    sendError(res, "Failed to retrieve quizzes", 500)
  }
})

// @route   GET /api/ncc/quizzes/:id
// @desc    Get quiz details for taking
// @access  Private
router.get("/quizzes/:id", authenticateToken, async (req, res) => {
  try {
    const { id } = req.params
    const userId = req.user._id

    const quiz = await Quiz.findById(id).populate("createdBy", "name")
    if (!quiz) {
      return sendNotFound(res, "Quiz")
    }

    if (!quiz.isActive) {
      return sendError(res, "Quiz is not active", 400)
    }

    const now = new Date()
    if (now < quiz.startDate || now > quiz.endDate) {
      return sendError(res, "Quiz is not available at this time", 400)
    }

    // Check user's attempts
    const userAttempts = quiz.attempts.filter((attempt) => attempt.user.toString() === userId.toString())

    if (userAttempts.length >= quiz.maxAttempts) {
      return sendError(res, "Maximum attempts reached", 400)
    }

    // Return quiz without correct answers
    const quizForAttempt = {
      _id: quiz._id,
      title: quiz.title,
      description: quiz.description,
      category: quiz.category,
      timeLimit: quiz.timeLimit,
      passingScore: quiz.passingScore,
      questions: quiz.questions.map((q, index) => ({
        index,
        question: q.question,
        type: q.type,
        options: q.options,
        points: q.points,
      })),
      totalQuestions: quiz.questions.length,
      maxPossiblePoints: quiz.maxPossiblePoints,
      userAttempts: userAttempts.length,
      maxAttempts: quiz.maxAttempts,
    }

    sendSuccess(res, quizForAttempt, "Quiz details retrieved successfully")
  } catch (error) {
    console.error("Get quiz details error:", error)
    sendError(res, "Failed to retrieve quiz details", 500)
  }
})

// @route   POST /api/ncc/quizzes/:id/attempt
// @desc    Submit quiz attempt
// @access  Private
router.post("/quizzes/:id/attempt", authenticateToken, async (req, res) => {
  try {
    const { id } = req.params
    const { answers, timeSpent } = req.body
    const userId = req.user._id

    if (!answers || !Array.isArray(answers)) {
      return sendError(res, "Answers array is required", 400)
    }

    const quiz = await Quiz.findById(id)
    if (!quiz) {
      return sendNotFound(res, "Quiz")
    }

    // Validate quiz availability
    if (!quiz.isActive) {
      return sendError(res, "Quiz is not active", 400)
    }

    const now = new Date()
    if (now < quiz.startDate || now > quiz.endDate) {
      return sendError(res, "Quiz is not available at this time", 400)
    }

    // Check attempts limit
    const userAttempts = quiz.attempts.filter((attempt) => attempt.user.toString() === userId.toString())
    if (userAttempts.length >= quiz.maxAttempts) {
      return sendError(res, "Maximum attempts reached", 400)
    }

    // Grade the quiz
    let totalPoints = 0
    let maxPoints = 0
    const gradedAnswers = []

    for (let i = 0; i < quiz.questions.length; i++) {
      const question = quiz.questions[i]
      const userAnswer = answers.find((a) => a.questionIndex === i)

      maxPoints += question.points

      const isCorrect = userAnswer && userAnswer.selectedAnswer === question.correctAnswer
      const pointsEarned = isCorrect ? question.points : 0
      totalPoints += pointsEarned

      gradedAnswers.push({
        questionIndex: i,
        selectedAnswer: userAnswer?.selectedAnswer || "",
        isCorrect,
        pointsEarned,
      })
    }

    const score = maxPoints > 0 ? Math.round((totalPoints / maxPoints) * 100) : 0
    const passed = score >= quiz.passingScore

    // Create attempt record
    const attempt = {
      user: userId,
      startedAt: new Date(Date.now() - (timeSpent || 0) * 1000),
      completedAt: new Date(),
      answers: gradedAnswers,
      score,
      totalPoints,
      maxPoints,
      passed,
      timeSpent: timeSpent || 0,
      status: "completed",
    }

    quiz.attempts.push(attempt)

    // Update statistics
    quiz.statistics.totalAttempts += 1
    const allScores = quiz.attempts.map((a) => a.score || 0)
    quiz.statistics.averageScore = Math.round(allScores.reduce((sum, s) => sum + s, 0) / allScores.length)
    quiz.statistics.passRate = Math.round((quiz.attempts.filter((a) => a.passed).length / quiz.attempts.length) * 100)

    await quiz.save()

    sendSuccess(
      res,
      {
        score,
        totalPoints,
        maxPoints,
        passed,
        passingScore: quiz.passingScore,
        timeSpent,
        answers: gradedAnswers,
        attemptNumber: userAttempts.length + 1,
        maxAttempts: quiz.maxAttempts,
      },
      "Quiz submitted successfully",
    )
  } catch (error) {
    console.error("Submit quiz attempt error:", error)
    sendError(res, "Failed to submit quiz", 500)
  }
})

// @route   PUT /api/ncc/cadets/:id/rank
// @desc    Update cadet rank (Admin only)
// @access  Private (Admin only)
router.put("/cadets/:id/rank", [authenticateToken, requireAdmin], async (req, res) => {
  try {
    const { id } = req.params
    const { newRank, reason } = req.body

    const validRanks = ["Cadet", "Lance Corporal", "Corporal", "Sergeant", "Under Officer", "Cadet Captain"]
    if (!validRanks.includes(newRank)) {
      return sendError(res, "Invalid rank", 400)
    }

    const cadet = await User.findById(id)
    if (!cadet) {
      return sendNotFound(res, "Cadet")
    }

    if (cadet.role !== "student") {
      return sendError(res, "User is not a student", 400)
    }

    const oldRank = cadet.nccStats.currentRank
    cadet.nccStats.currentRank = newRank

    // Add badge for promotion
    if (newRank !== oldRank) {
      cadet.badges.push({
        name: `${newRank} Promotion`,
        description: `Promoted to ${newRank}${reason ? `: ${reason}` : ""}`,
        category: "ncc",
        earnedAt: new Date(),
      })
    }

    await cadet.save()

    sendSuccess(
      res,
      {
        cadet: cadet.getPublicProfile(),
        oldRank,
        newRank,
        reason,
      },
      "Cadet rank updated successfully",
    )
  } catch (error) {
    console.error("Update cadet rank error:", error)
    sendError(res, "Failed to update cadet rank", 500)
  }
})

// @route   GET /api/ncc/leaderboard
// @desc    Get NCC cadet leaderboard
// @access  Private
router.get("/leaderboard", authenticateToken, async (req, res) => {
  try {
    const { limit = 20, sortBy = "rank" } = req.query

    let sortCriteria = {}
    switch (sortBy) {
      case "rank":
        // Custom sort by rank hierarchy
        sortCriteria = { "nccStats.currentRank": 1, "nccStats.disciplineScore": -1 }
        break
      case "discipline":
        sortCriteria = { "nccStats.disciplineScore": -1, "nccStats.drillsAttended": -1 }
        break
      case "attendance":
        sortCriteria = { "nccStats.drillsAttended": -1, "nccStats.trainingHours": -1 }
        break
      default:
        sortCriteria = { "nccStats.disciplineScore": -1 }
    }

    const pipeline = [
      { $match: { role: "student" } },
      {
        $addFields: {
          rankOrder: {
            $switch: {
              branches: [
                { case: { $eq: ["$nccStats.currentRank", "Cadet Captain"] }, then: 6 },
                { case: { $eq: ["$nccStats.currentRank", "Under Officer"] }, then: 5 },
                { case: { $eq: ["$nccStats.currentRank", "Sergeant"] }, then: 4 },
                { case: { $eq: ["$nccStats.currentRank", "Corporal"] }, then: 3 },
                { case: { $eq: ["$nccStats.currentRank", "Lance Corporal"] }, then: 2 },
              ],
              default: 1,
            },
          },
        },
      },
      {
        $sort:
          sortBy === "rank"
            ? { rankOrder: -1, "nccStats.disciplineScore": -1, "nccStats.drillsAttended": -1 }
            : sortCriteria,
      },
      { $limit: Number.parseInt(limit) },
      {
        $project: {
          name: 1,
          rollNo: 1,
          department: 1,
          year: 1,
          profilePhoto: 1,
          "nccStats.currentRank": 1,
          "nccStats.drillsAttended": 1,
          "nccStats.trainingHours": 1,
          "nccStats.disciplineScore": 1,
          rankOrder: 1,
        },
      },
    ]

    const leaderboard = await User.aggregate(pipeline)

    // Add position to each cadet
    const rankedLeaderboard = leaderboard.map((cadet, index) => ({
      ...cadet,
      position: index + 1,
    }))

    sendSuccess(res, rankedLeaderboard, "NCC leaderboard retrieved successfully")
  } catch (error) {
    console.error("Get NCC leaderboard error:", error)
    sendError(res, "Failed to retrieve NCC leaderboard", 500)
  }
})

module.exports = router
