const express = require("express")
const router = express.Router()
const Media = require("../models/Media")
const MediaAccess = require("../models/MediaAccess")
const User = require("../models/User")
const auth = require("../middleware/auth")
const { generateResponse, generateError } = require("../utils/responseHelper")

// Generate 6-digit privacy code on login
const generatePrivacyCode = () => {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

// Verify privacy code access
router.post("/verify-access", auth, async (req, res) => {
  try {
    const { privacyCode, studentId } = req.body

    const accessRecord = await MediaAccess.findOne({
      studentId,
      privacyCode,
      isActive: true,
    })

    if (!accessRecord) {
      return res.status(401).json(generateError("Invalid privacy code", 401))
    }

    accessRecord.lastAccessedAt = new Date()
    await accessRecord.save()

    res.status(200).json(
      generateResponse({
        message: "Access granted",
        access: true,
      }),
    )
  } catch (error) {
    res.status(500).json(generateError(error.message))
  }
})

// Get media gallery
router.get("/gallery", auth, async (req, res) => {
  try {
    const media = await Media.find({ isPublic: true })
      .populate("uploadedBy", "name rollNo")
      .populate("eventId", "title")
      .sort({ uploadedDate: -1 })

    res.status(200).json(generateResponse({ media }))
  } catch (error) {
    res.status(500).json(generateError(error.message))
  }
})

// Upload media (admin only)
router.post("/upload", auth, async (req, res) => {
  try {
    const { title, url, type, eventName, category, description } = req.body

    const media = new Media({
      title,
      url,
      type,
      eventName,
      category,
      description,
      uploadedBy: req.user.id,
      isPublic: true,
    })

    await media.save()

    res.status(201).json(
      generateResponse({
        message: "Media uploaded successfully",
        media,
      }),
    )
  } catch (error) {
    res.status(500).json(generateError(error.message))
  }
})

// Get media by category
router.get("/category/:category", auth, async (req, res) => {
  try {
    const media = await Media.find({ category: req.params.category, isPublic: true })
      .populate("uploadedBy", "name")
      .sort({ uploadedDate: -1 })

    res.status(200).json(generateResponse({ media }))
  } catch (error) {
    res.status(500).json(generateError(error.message))
  }
})

module.exports = router
