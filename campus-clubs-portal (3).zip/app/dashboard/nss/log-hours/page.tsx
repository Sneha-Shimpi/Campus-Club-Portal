"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { useToast } from "@/hooks/use-toast"
import { CalendarIcon, Upload, X } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

const activityCategories = [
  "Education & Literacy",
  "Health & Hygiene",
  "Environment & Sustainability",
  "Social Service",
  "Community Development",
  "Disaster Relief",
  "Blood Donation",
  "Awareness Campaigns",
  "Other",
]

export default function LogHoursPage() {
  const { toast } = useToast()
  const [selectedDate, setSelectedDate] = useState<Date>()
  const [logData, setLogData] = useState({
    activity: "",
    category: "",
    hours: "",
    location: "",
    description: "",
    supervisor: "",
    contactNumber: "",
  })
  const [attachments, setAttachments] = useState<File[]>([])

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedDate || !logData.activity || !logData.category || !logData.hours) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      })
      return
    }

    // TODO: Implement actual hours logging API call
    console.log("Logging hours:", {
      date: selectedDate,
      ...logData,
      attachments,
    })

    toast({
      title: "Hours Logged Successfully!",
      description: "Your volunteer hours have been submitted for verification.",
    })

    // Reset form
    setSelectedDate(undefined)
    setLogData({
      activity: "",
      category: "",
      hours: "",
      location: "",
      description: "",
      supervisor: "",
      contactNumber: "",
    })
    setAttachments([])
  }

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || [])
    setAttachments([...attachments, ...files])
  }

  const removeAttachment = (index: number) => {
    setAttachments(attachments.filter((_, i) => i !== index))
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold font-heading">Log Volunteer Hours</h1>
        <p className="text-muted-foreground">Record your community service activities and hours</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Form */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Activity Details</CardTitle>
              <CardDescription>Provide information about your volunteer activity</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Basic Information */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="activity">Activity Name *</Label>
                    <Input
                      id="activity"
                      placeholder="e.g., Teaching at Local School"
                      value={logData.activity}
                      onChange={(e) => setLogData({ ...logData, activity: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>Category *</Label>
                    <Select
                      value={logData.category}
                      onValueChange={(value) => setLogData({ ...logData, category: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        {activityCategories.map((category) => (
                          <SelectItem key={category} value={category}>
                            {category}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Date of Activity *</Label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !selectedDate && "text-muted-foreground",
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={setSelectedDate}
                          disabled={(date) => date > new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="hours">Hours Worked *</Label>
                    <Input
                      id="hours"
                      type="number"
                      step="0.5"
                      min="0.5"
                      max="12"
                      placeholder="e.g., 4"
                      value={logData.hours}
                      onChange={(e) => setLogData({ ...logData, hours: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    placeholder="e.g., Local Primary School, Community Center"
                    value={logData.location}
                    onChange={(e) => setLogData({ ...logData, location: e.target.value })}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Activity Description *</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe what you did, who you helped, and the impact of your work..."
                    value={logData.description}
                    onChange={(e) => setLogData({ ...logData, description: e.target.value })}
                    required
                  />
                </div>

                {/* Supervisor Information */}
                <div className="space-y-4">
                  <h3 className="font-semibold">Supervisor/Contact Information</h3>
                  <div className="grid sm:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="supervisor">Supervisor Name</Label>
                      <Input
                        id="supervisor"
                        placeholder="Name of supervising person/organization"
                        value={logData.supervisor}
                        onChange={(e) => setLogData({ ...logData, supervisor: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="contact">Contact Number</Label>
                      <Input
                        id="contact"
                        placeholder="Supervisor's contact number"
                        value={logData.contactNumber}
                        onChange={(e) => setLogData({ ...logData, contactNumber: e.target.value })}
                      />
                    </div>
                  </div>
                </div>

                {/* File Attachments */}
                <div className="space-y-4">
                  <h3 className="font-semibold">Supporting Documents (Optional)</h3>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2">
                      <input
                        type="file"
                        id="file-upload"
                        multiple
                        accept="image/*,.pdf,.doc,.docx"
                        onChange={handleFileUpload}
                        className="hidden"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => document.getElementById("file-upload")?.click()}
                      >
                        <Upload className="h-4 w-4 mr-2" />
                        Upload Files
                      </Button>
                      <span className="text-sm text-muted-foreground">Photos, certificates, or other proof</span>
                    </div>

                    {attachments.length > 0 && (
                      <div className="space-y-2">
                        {attachments.map((file, index) => (
                          <div key={index} className="flex items-center justify-between p-2 border rounded">
                            <span className="text-sm truncate">{file.name}</span>
                            <Button type="button" variant="ghost" size="sm" onClick={() => removeAttachment(index)}>
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <Button type="submit" className="w-full">
                  Submit Hours for Verification
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Guidelines */}
          <Card>
            <CardHeader>
              <CardTitle>Logging Guidelines</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="space-y-2">
                <h4 className="font-semibold">Important Notes:</h4>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• Log hours within 7 days of activity</li>
                  <li>• Minimum 0.5 hours per entry</li>
                  <li>• Provide detailed activity description</li>
                  <li>• Include supervisor contact for verification</li>
                  <li>• Upload supporting documents when possible</li>
                </ul>
              </div>
              <div className="pt-2 border-t">
                <p className="text-xs text-muted-foreground">
                  All logged hours are subject to verification by NSS coordinators.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Recent Submissions */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Submissions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-sm">Teaching Session</p>
                      <p className="text-xs text-muted-foreground">4 hours • Jan 10, 2024</p>
                    </div>
                    <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-1 rounded">Pending</span>
                  </div>
                </div>
                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-sm">Food Distribution</p>
                      <p className="text-xs text-muted-foreground">3 hours • Jan 8, 2024</p>
                    </div>
                    <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Approved</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Stats */}
          <Card>
            <CardHeader>
              <CardTitle>Your Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-sm">Total Hours</span>
                  <span className="font-semibold">45/60</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">This Month</span>
                  <span className="font-semibold">12 hours</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm">Activities</span>
                  <span className="font-semibold">8 events</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
