const express = require("express")
const jwt = require("jsonwebtoken")
const bcrypt = require("bcryptjs")
const { body, validationResult } = require("express-validator")
const User = require("../models/User")
const { authenticateToken } = require("../middleware/auth")
const { sendSuccess, sendError, sendValidationError } = require("../utils/responseHelper")

const router = express.Router()

// Generate JWT tokens
const generateTokens = (userId) => {
  const accessToken = jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE || "7d" })

  const refreshToken = jwt.sign({ userId }, process.env.JWT_REFRESH_SECRET, {
    expiresIn: process.env.JWT_REFRESH_EXPIRE || "30d",
  })

  return { accessToken, refreshToken }
}

const generatePrivacyCode = () => {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

// @route   POST /api/auth/register
// @desc    Register a new user
// @access  Public
router.post(
  "/register",
  [
    body("name").trim().isLength({ min: 2, max: 100 }).withMessage("Name must be between 2 and 100 characters"),
    body("email").isEmail().normalizeEmail().withMessage("Please provide a valid email"),
    body("password")
      .isLength({ min: 6 })
      .withMessage("Password must be at least 6 characters long")
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
      .withMessage("Password must contain at least one uppercase letter, one lowercase letter, and one number"),
    body("rollNo")
      .trim()
      .toUpperCase()
      .matches(/^[A-Z0-9]{6,12}$/)
      .withMessage("Roll number must be 6-12 characters long and contain only letters and numbers"),
    body("department")
      .isIn(["CSE", "ECE", "EEE", "MECH", "CIVIL", "IT", "OTHER"])
      .withMessage("Please select a valid department"),
    body("year").isInt({ min: 1, max: 4 }).withMessage("Year must be between 1 and 4"),
    body("phone")
      .optional()
      .matches(/^[0-9]{10}$/)
      .withMessage("Phone number must be 10 digits"),
  ],
  async (req, res) => {
    try {
      // Check validation errors
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return sendValidationError(res, errors.array())
      }

      const { name, email, password, rollNo, department, year, phone } = req.body

      // Check if user already exists
      const existingUser = await User.findOne({
        $or: [{ email }, { rollNo }],
      })

      if (existingUser) {
        if (existingUser.email === email) {
          return sendError(res, "User with this email already exists", 400)
        }
        if (existingUser.rollNo === rollNo) {
          return sendError(res, "User with this roll number already exists", 400)
        }
      }

      // Create new user
      const user = new User({
        name,
        email,
        password,
        rollNo,
        department,
        year,
        phone,
      })

      await user.save()

      const privacyCode = generatePrivacyCode()
      const MediaAccess = require("../models/MediaAccess")

      await MediaAccess.create({
        studentId: user._id,
        privacyCode,
        isActive: true,
      })

      // Generate tokens
      const { accessToken, refreshToken } = generateTokens(user._id)

      // Return user data without password
      const userData = user.getPublicProfile()

      sendSuccess(
        res,
        {
          user: userData,
          accessToken,
          refreshToken,
          privacyCode, // Include privacy code in registration response
        },
        "User registered successfully",
        201,
      )
    } catch (error) {
      console.error("Registration error:", error)
      sendError(res, "Registration failed", 500)
    }
  },
)

// @route   POST /api/auth/login
// @desc    Login user
// @access  Public
router.post(
  "/login",
  [
    body("email").isEmail().normalizeEmail().withMessage("Please provide a valid email"),
    body("password").notEmpty().withMessage("Password is required"),
  ],
  async (req, res) => {
    try {
      // Check validation errors
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return sendValidationError(res, errors.array())
      }

      const { email, password } = req.body

      // Find user and include password for comparison
      const user = await User.findOne({ email }).select("+password")
      if (!user) {
        return sendError(res, "Invalid email or password", 401)
      }

      // Check if user is active
      if (!user.isActive) {
        return sendError(res, "Account is deactivated. Please contact administrator", 401)
      }

      // Verify password
      const isPasswordValid = await user.comparePassword(password)
      if (!isPasswordValid) {
        return sendError(res, "Invalid email or password", 401)
      }

      // Update last login
      user.lastLogin = new Date()
      await user.save()

      const MediaAccess = require("../models/MediaAccess")
      const privacyCode = generatePrivacyCode()

      await MediaAccess.updateOne(
        { studentId: user._id },
        { privacyCode, lastAccessedAt: new Date() },
        { upsert: true },
      )

      // Generate tokens
      const { accessToken, refreshToken } = generateTokens(user._id)

      // Return user data without password
      const userData = user.getPublicProfile()

      sendSuccess(
        res,
        {
          user: userData,
          accessToken,
          refreshToken,
          privacyCode, // Include new privacy code in login response
        },
        "Login successful",
      )
    } catch (error) {
      console.error("Login error:", error)
      sendError(res, "Login failed", 500)
    }
  },
)

// @route   POST /api/auth/refresh
// @desc    Refresh access token
// @access  Public
router.post(
  "/refresh",
  [body("refreshToken").notEmpty().withMessage("Refresh token is required")],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return sendValidationError(res, errors.array())
      }

      const { refreshToken } = req.body

      // Verify refresh token
      const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET)

      // Find user
      const user = await User.findById(decoded.userId)
      if (!user || !user.isActive) {
        return sendError(res, "Invalid refresh token", 401)
      }

      // Generate new tokens
      const tokens = generateTokens(user._id)

      sendSuccess(res, tokens, "Token refreshed successfully")
    } catch (error) {
      if (error.name === "TokenExpiredError") {
        return sendError(res, "Refresh token expired", 401)
      }
      console.error("Token refresh error:", error)
      sendError(res, "Token refresh failed", 401)
    }
  },
)

// @route   GET /api/auth/me
// @desc    Get current user profile
// @access  Private
router.get("/me", authenticateToken, async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
    if (!user) {
      return sendError(res, "User not found", 404)
    }

    sendSuccess(res, user.getPublicProfile(), "Profile retrieved successfully")
  } catch (error) {
    console.error("Get profile error:", error)
    sendError(res, "Failed to retrieve profile", 500)
  }
})

// @route   PUT /api/auth/profile
// @desc    Update user profile
// @access  Private
router.put(
  "/profile",
  authenticateToken,
  [
    body("name")
      .optional()
      .trim()
      .isLength({ min: 2, max: 100 })
      .withMessage("Name must be between 2 and 100 characters"),
    body("phone")
      .optional()
      .matches(/^[0-9]{10}$/)
      .withMessage("Phone number must be 10 digits"),
    body("department")
      .optional()
      .isIn(["CSE", "ECE", "EEE", "MECH", "CIVIL", "IT", "OTHER"])
      .withMessage("Please select a valid department"),
    body("year").optional().isInt({ min: 1, max: 4 }).withMessage("Year must be between 1 and 4"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return sendValidationError(res, errors.array())
      }

      const { name, phone, department, year } = req.body

      const user = await User.findById(req.user._id)
      if (!user) {
        return sendError(res, "User not found", 404)
      }

      // Update fields if provided
      if (name) user.name = name
      if (phone) user.phone = phone
      if (department) user.department = department
      if (year) user.year = year

      await user.save()

      sendSuccess(res, user.getPublicProfile(), "Profile updated successfully")
    } catch (error) {
      console.error("Profile update error:", error)
      sendError(res, "Failed to update profile", 500)
    }
  },
)

// @route   PUT /api/auth/change-password
// @desc    Change user password
// @access  Private
router.put(
  "/change-password",
  authenticateToken,
  [
    body("currentPassword").notEmpty().withMessage("Current password is required"),
    body("newPassword")
      .isLength({ min: 6 })
      .withMessage("New password must be at least 6 characters long")
      .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
      .withMessage("New password must contain at least one uppercase letter, one lowercase letter, and one number"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return sendValidationError(res, errors.array())
      }

      const { currentPassword, newPassword } = req.body

      // Get user with password
      const user = await User.findById(req.user._id).select("+password")
      if (!user) {
        return sendError(res, "User not found", 404)
      }

      // Verify current password
      const isCurrentPasswordValid = await user.comparePassword(currentPassword)
      if (!isCurrentPasswordValid) {
        return sendError(res, "Current password is incorrect", 400)
      }

      // Update password
      user.password = newPassword
      await user.save()

      sendSuccess(res, null, "Password changed successfully")
    } catch (error) {
      console.error("Password change error:", error)
      sendError(res, "Failed to change password", 500)
    }
  },
)

// @route   POST /api/auth/logout
// @desc    Logout user (client-side token removal)
// @access  Private
router.post("/logout", authenticateToken, (req, res) => {
  // In a stateless JWT system, logout is handled client-side
  // This endpoint can be used for logging purposes
  sendSuccess(res, null, "Logged out successfully")
})

// @route   GET /api/auth/verify-token
// @desc    Verify if token is valid
// @access  Private
router.get("/verify-token", authenticateToken, (req, res) => {
  sendSuccess(res, { valid: true, user: req.user.getPublicProfile() }, "Token is valid")
})

module.exports = router
