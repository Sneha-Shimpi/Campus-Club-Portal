const express = require("express")
const router = express.Router()
const { authenticateToken } = require("../middleware/auth")

// Import route modules
const profileRoutes = require("./profile")
const bookingRoutes = require("./bookings")
const mediaRoutes = require("./media")

// Mount routes
router.use("/profile", authenticateToken, profileRoutes)
router.use("/bookings", authenticateToken, bookingRoutes)
router.use("/media", mediaRoutes)

module.exports = router
