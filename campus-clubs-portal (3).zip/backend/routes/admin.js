const express = require("express")
const { validationResult, body } = require("express-validator")
const User = require("../models/User")
const Event = require("../models/Event")
const SportsMatch = require("../models/SportsMatch")
const NSSActivity = require("../models/NSSActivity")
const NCCTraining = require("../models/NCCTraining")
const Booking = require("../models/Booking")
const Quiz = require("../models/Quiz")
const { authenticateToken, requireAdmin } = require("../middleware/auth")
const { sendSuccess, sendError, sendValidationError, sendNotFound } = require("../utils/responseHelper")

const router = express.Router()

// All admin routes require authentication and admin role
router.use(authenticateToken, requireAdmin)

// @route   GET /api/admin/dashboard
// @desc    Get admin dashboard analytics
// @access  Private (Admin only)
router.get("/dashboard", async (req, res) => {
  try {
    // Get overall statistics
    const totalUsers = await User.countDocuments({ role: "student" })
    const totalAdmins = await User.countDocuments({ role: "admin" })
    const totalEvents = await Event.countDocuments()
    const activeEvents = await Event.countDocuments({ status: "published" })

    // Sports statistics
    const sportsStats = {
      totalMatches: await SportsMatch.countDocuments(),
      completedMatches: await SportsMatch.countDocuments({ status: "completed" }),
      upcomingMatches: await SportsMatch.countDocuments({
        status: "scheduled",
        scheduledDate: { $gte: new Date() },
      }),
      totalBookings: await Booking.countDocuments(),
      pendingBookings: await Booking.countDocuments({ status: "pending" }),
    }

    // NSS statistics
    const nssStats = {
      totalActivities: await NSSActivity.countDocuments(),
      verifiedActivities: await NSSActivity.countDocuments({ status: "verified" }),
      pendingActivities: await NSSActivity.countDocuments({ status: "pending" }),
      totalVolunteerHours: await NSSActivity.aggregate([
        { $match: { status: "verified" } },
        { $group: { _id: null, total: { $sum: "$hoursContributed" } } },
      ]).then((result) => result[0]?.total || 0),
    }

    // NCC statistics
    const nccStats = {
      totalTrainingSessions: await NCCTraining.countDocuments(),
      completedSessions: await NCCTraining.countDocuments({ status: "completed" }),
      totalQuizzes: await Quiz.countDocuments(),
      activeQuizzes: await Quiz.countDocuments({ isActive: true }),
    }

    // Recent activity
    const recentUsers = await User.find({ role: "student" })
      .sort({ createdAt: -1 })
      .limit(5)
      .select("name rollNo department createdAt")

    const recentEvents = await Event.find()
      .sort({ createdAt: -1 })
      .limit(5)
      .populate("organizer", "name")
      .select("title category status startDate organizer")

    // Monthly trends
    const currentYear = new Date().getFullYear()
    const monthlyData = await Promise.all([
      // User registrations by month
      User.aggregate([
        {
          $match: {
            createdAt: { $gte: new Date(`${currentYear}-01-01`) },
            role: "student",
          },
        },
        {
          $group: {
            _id: { $month: "$createdAt" },
            count: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),
      // Events by month
      Event.aggregate([
        {
          $match: {
            createdAt: { $gte: new Date(`${currentYear}-01-01`) },
          },
        },
        {
          $group: {
            _id: { $month: "$createdAt" },
            count: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),
    ])

    // Department-wise distribution
    const departmentStats = await User.aggregate([
      { $match: { role: "student" } },
      {
        $group: {
          _id: "$department",
          count: { $sum: 1 },
        },
      },
      { $sort: { count: -1 } },
    ])

    sendSuccess(
      res,
      {
        overview: {
          totalUsers,
          totalAdmins,
          totalEvents,
          activeEvents,
        },
        sportsStats,
        nssStats,
        nccStats,
        recentActivity: {
          users: recentUsers,
          events: recentEvents,
        },
        trends: {
          userRegistrations: monthlyData[0],
          eventCreations: monthlyData[1],
        },
        departmentStats,
      },
      "Admin dashboard data retrieved successfully",
    )
  } catch (error) {
    console.error("Admin dashboard error:", error)
    sendError(res, "Failed to retrieve admin dashboard data", 500)
  }
})

// @route   GET /api/admin/users
// @desc    Get all users with filters and pagination
// @access  Private (Admin only)
router.get("/users", async (req, res) => {
  try {
    const { page = 1, limit = 20, role, department, year, search, sortBy = "createdAt", sortOrder = "desc" } = req.query

    // Build filter object
    const filter = {}
    if (role) filter.role = role
    if (department) filter.department = department
    if (year) filter.year = Number.parseInt(year)

    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: "i" } },
        { email: { $regex: search, $options: "i" } },
        { rollNo: { $regex: search, $options: "i" } },
      ]
    }

    const skip = (page - 1) * limit
    const sort = { [sortBy]: sortOrder === "desc" ? -1 : 1 }

    const users = await User.find(filter).select("-password").sort(sort).skip(skip).limit(Number.parseInt(limit))

    const total = await User.countDocuments(filter)

    sendSuccess(
      res,
      {
        users,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalUsers: total,
          hasNext: page * limit < total,
          hasPrev: page > 1,
        },
      },
      "Users retrieved successfully",
    )
  } catch (error) {
    console.error("Get users error:", error)
    sendError(res, "Failed to retrieve users", 500)
  }
})

// @route   PUT /api/admin/users/:id
// @desc    Update user details
// @access  Private (Admin only)
router.put("/users/:id", async (req, res) => {
  try {
    const { id } = req.params
    const { name, email, department, year, role, isActive, adminSections } = req.body

    const user = await User.findById(id)
    if (!user) {
      return sendNotFound(res, "User")
    }

    // Update fields if provided
    if (name) user.name = name
    if (email) user.email = email
    if (department) user.department = department
    if (year) user.year = year
    if (role) user.role = role
    if (typeof isActive === "boolean") user.isActive = isActive
    if (adminSections) user.adminSections = adminSections

    await user.save()

    sendSuccess(res, user.getPublicProfile(), "User updated successfully")
  } catch (error) {
    console.error("Update user error:", error)
    sendError(res, "Failed to update user", 500)
  }
})

// @route   DELETE /api/admin/users/:id
// @desc    Delete user
// @access  Private (Admin only)
router.delete("/users/:id", async (req, res) => {
  try {
    const { id } = req.params

    const user = await User.findById(id)
    if (!user) {
      return sendNotFound(res, "User")
    }

    // Prevent deleting other admins
    if (user.role === "admin" && user._id.toString() !== req.user._id.toString()) {
      return sendError(res, "Cannot delete other admin users", 403)
    }

    await User.findByIdAndDelete(id)

    sendSuccess(res, null, "User deleted successfully")
  } catch (error) {
    console.error("Delete user error:", error)
    sendError(res, "Failed to delete user", 500)
  }
})

// @route   GET /api/admin/events
// @desc    Get all events with filters
// @access  Private (Admin only)
router.get("/events", async (req, res) => {
  try {
    const { page = 1, limit = 20, category, status, startDate, endDate, organizer } = req.query

    const filter = {}
    if (category) filter.category = category
    if (status) filter.status = status
    if (organizer) filter.organizer = organizer

    if (startDate || endDate) {
      filter.startDate = {}
      if (startDate) filter.startDate.$gte = new Date(startDate)
      if (endDate) filter.startDate.$lte = new Date(endDate)
    }

    const skip = (page - 1) * limit

    const events = await Event.find(filter)
      .populate("organizer", "name email")
      .populate("coordinators", "name")
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await Event.countDocuments(filter)

    sendSuccess(
      res,
      {
        events,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalEvents: total,
        },
      },
      "Events retrieved successfully",
    )
  } catch (error) {
    console.error("Get events error:", error)
    sendError(res, "Failed to retrieve events", 500)
  }
})

// @route   POST /api/admin/events
// @desc    Create new event
// @access  Private (Admin only)
router.post(
  "/events",
  [
    body("title").trim().isLength({ min: 3, max: 200 }).withMessage("Title must be between 3 and 200 characters"),
    body("description")
      .trim()
      .isLength({ min: 10, max: 1000 })
      .withMessage("Description must be between 10 and 1000 characters"),
    body("category").isIn(["sports", "nss", "ncc", "general"]).withMessage("Invalid category"),
    body("type")
      .isIn(["match", "tournament", "volunteer", "training", "workshop", "meeting", "other"])
      .withMessage("Invalid event type"),
    body("startDate").isISO8601().withMessage("Invalid start date"),
    body("endDate").isISO8601().withMessage("Invalid end date"),
    body("registrationDeadline").isISO8601().withMessage("Invalid registration deadline"),
    body("venue").trim().isLength({ min: 3, max: 200 }).withMessage("Venue must be between 3 and 200 characters"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return sendValidationError(res, errors.array())
      }

      const {
        title,
        description,
        category,
        type,
        startDate,
        endDate,
        registrationDeadline,
        venue,
        maxParticipants,
        coordinators,
        requirements,
        resources,
      } = req.body

      const event = new Event({
        title,
        description,
        category,
        type,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        registrationDeadline: new Date(registrationDeadline),
        venue,
        organizer: req.user._id,
        maxParticipants,
        coordinators: coordinators || [],
        requirements: requirements || [],
        resources: resources || [],
        status: "published",
      })

      await event.save()

      const populatedEvent = await Event.findById(event._id)
        .populate("organizer", "name email")
        .populate("coordinators", "name")

      sendSuccess(res, populatedEvent, "Event created successfully", 201)
    } catch (error) {
      console.error("Create event error:", error)
      sendError(res, "Failed to create event", 500)
    }
  },
)

// @route   PUT /api/admin/events/:id
// @desc    Update event
// @access  Private (Admin only)
router.put("/events/:id", async (req, res) => {
  try {
    const { id } = req.params
    const updateData = req.body

    const event = await Event.findById(id)
    if (!event) {
      return sendNotFound(res, "Event")
    }

    // Update event fields
    Object.keys(updateData).forEach((key) => {
      if (updateData[key] !== undefined && key !== "_id") {
        event[key] = updateData[key]
      }
    })

    await event.save()

    const updatedEvent = await Event.findById(id).populate("organizer", "name email").populate("coordinators", "name")

    sendSuccess(res, updatedEvent, "Event updated successfully")
  } catch (error) {
    console.error("Update event error:", error)
    sendError(res, "Failed to update event", 500)
  }
})

// @route   DELETE /api/admin/events/:id
// @desc    Delete event
// @access  Private (Admin only)
router.delete("/events/:id", async (req, res) => {
  try {
    const { id } = req.params

    const event = await Event.findById(id)
    if (!event) {
      return sendNotFound(res, "Event")
    }

    await Event.findByIdAndDelete(id)

    sendSuccess(res, null, "Event deleted successfully")
  } catch (error) {
    console.error("Delete event error:", error)
    sendError(res, "Failed to delete event", 500)
  }
})

// @route   GET /api/admin/analytics
// @desc    Get comprehensive analytics data
// @access  Private (Admin only)
router.get("/analytics", async (req, res) => {
  try {
    const { startDate, endDate, category } = req.query

    // Build date filter
    const dateFilter = {}
    if (startDate || endDate) {
      dateFilter.createdAt = {}
      if (startDate) dateFilter.createdAt.$gte = new Date(startDate)
      if (endDate) dateFilter.createdAt.$lte = new Date(endDate)
    }

    // User analytics
    const userAnalytics = await User.aggregate([
      { $match: { role: "student", ...dateFilter } },
      {
        $group: {
          _id: {
            year: { $year: "$createdAt" },
            month: { $month: "$createdAt" },
            department: "$department",
          },
          count: { $sum: 1 },
        },
      },
    ])

    // Event analytics
    const eventFilter = { ...dateFilter }
    if (category) eventFilter.category = category

    const eventAnalytics = await Event.aggregate([
      { $match: eventFilter },
      {
        $group: {
          _id: {
            category: "$category",
            status: "$status",
            month: { $month: "$createdAt" },
          },
          count: { $sum: 1 },
          avgParticipants: { $avg: { $size: "$participants" } },
        },
      },
    ])

    // Sports analytics
    const sportsAnalytics = await SportsMatch.aggregate([
      { $match: dateFilter },
      {
        $group: {
          _id: {
            sport: "$sport",
            status: "$status",
          },
          count: { $sum: 1 },
          avgScore: { $avg: { $add: ["$team1.score", "$team2.score"] } },
        },
      },
    ])

    // NSS analytics
    const nssAnalytics = await NSSActivity.aggregate([
      { $match: { status: "verified", ...dateFilter } },
      {
        $group: {
          _id: {
            category: "$category",
            month: { $month: "$date" },
          },
          totalHours: { $sum: "$hoursContributed" },
          totalActivities: { $sum: 1 },
          impact: {
            $push: {
              treesPlanted: "$impact.treesPlanted",
              peopleHelped: "$impact.peopleHelped",
              wasteCollected: "$impact.wasteCollected",
            },
          },
        },
      },
    ])

    // NCC analytics
    const nccAnalytics = await NCCTraining.aggregate([
      { $match: { status: "completed", ...dateFilter } },
      {
        $group: {
          _id: {
            type: "$type",
            month: { $month: "$date" },
          },
          totalSessions: { $sum: 1 },
          totalHours: { $sum: "$duration" },
          avgAttendance: { $avg: { $size: "$attendees" } },
        },
      },
    ])

    // Performance metrics
    const performanceMetrics = {
      userGrowthRate: await calculateGrowthRate(User, "student"),
      eventCompletionRate: await calculateEventCompletionRate(),
      averageEventParticipation: await calculateAverageParticipation(),
    }

    sendSuccess(
      res,
      {
        userAnalytics,
        eventAnalytics,
        sportsAnalytics,
        nssAnalytics,
        nccAnalytics,
        performanceMetrics,
        generatedAt: new Date(),
        filters: { startDate, endDate, category },
      },
      "Analytics data retrieved successfully",
    )
  } catch (error) {
    console.error("Analytics error:", error)
    sendError(res, "Failed to retrieve analytics data", 500)
  }
})

// @route   GET /api/admin/reports/export
// @desc    Export data for reports
// @access  Private (Admin only)
router.get("/reports/export", async (req, res) => {
  try {
    const { type, format = "json", startDate, endDate } = req.query

    if (!type) {
      return sendError(res, "Report type is required", 400)
    }

    const dateFilter = {}
    if (startDate || endDate) {
      dateFilter.createdAt = {}
      if (startDate) dateFilter.createdAt.$gte = new Date(startDate)
      if (endDate) dateFilter.createdAt.$lte = new Date(endDate)
    }

    let data = []

    switch (type) {
      case "users":
        data = await User.find({ role: "student", ...dateFilter }).select("-password")
        break
      case "events":
        data = await Event.find(dateFilter).populate("organizer", "name email")
        break
      case "sports":
        data = await SportsMatch.find(dateFilter).populate("team1.players team2.players", "name rollNo")
        break
      case "nss":
        data = await NSSActivity.find({ status: "verified", ...dateFilter }).populate("volunteer", "name rollNo")
        break
      case "ncc":
        data = await NCCTraining.find({ status: "completed", ...dateFilter }).populate("instructor", "name")
        break
      default:
        return sendError(res, "Invalid report type", 400)
    }

    // Set appropriate headers for download
    if (format === "csv") {
      res.setHeader("Content-Type", "text/csv")
      res.setHeader("Content-Disposition", `attachment; filename="${type}-report.csv"`)
      // Convert to CSV format (simplified)
      const csv = convertToCSV(data)
      res.send(csv)
    } else {
      res.setHeader("Content-Type", "application/json")
      res.setHeader("Content-Disposition", `attachment; filename="${type}-report.json"`)
      sendSuccess(res, data, `${type} report exported successfully`)
    }
  } catch (error) {
    console.error("Export report error:", error)
    sendError(res, "Failed to export report", 500)
  }
})

// @route   POST /api/admin/bulk-actions
// @desc    Perform bulk actions on users/events
// @access  Private (Admin only)
router.post("/bulk-actions", async (req, res) => {
  try {
    const { action, type, ids, data } = req.body

    if (!action || !type || !ids || !Array.isArray(ids)) {
      return sendError(res, "Invalid bulk action parameters", 400)
    }

    let result = {}

    switch (type) {
      case "users":
        result = await performBulkUserAction(action, ids, data)
        break
      case "events":
        result = await performBulkEventAction(action, ids, data)
        break
      default:
        return sendError(res, "Invalid bulk action type", 400)
    }

    sendSuccess(res, result, `Bulk ${action} completed successfully`)
  } catch (error) {
    console.error("Bulk action error:", error)
    sendError(res, "Failed to perform bulk action", 500)
  }
})

// Helper functions
async function calculateGrowthRate(Model, role = null) {
  const now = new Date()
  const lastMonth = new Date(now.getFullYear(), now.getMonth() - 1, 1)
  const twoMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 2, 1)

  const filter = role ? { role } : {}

  const currentCount = await Model.countDocuments({
    ...filter,
    createdAt: { $gte: lastMonth },
  })

  const previousCount = await Model.countDocuments({
    ...filter,
    createdAt: { $gte: twoMonthsAgo, $lt: lastMonth },
  })

  return previousCount > 0 ? ((currentCount - previousCount) / previousCount) * 100 : 0
}

async function calculateEventCompletionRate() {
  const totalEvents = await Event.countDocuments()
  const completedEvents = await Event.countDocuments({ status: "completed" })
  return totalEvents > 0 ? (completedEvents / totalEvents) * 100 : 0
}

async function calculateAverageParticipation() {
  const events = await Event.find({ status: { $in: ["completed", "ongoing"] } })
  const totalParticipants = events.reduce((sum, event) => sum + event.participants.length, 0)
  return events.length > 0 ? totalParticipants / events.length : 0
}

async function performBulkUserAction(action, ids, data) {
  switch (action) {
    case "activate":
      return await User.updateMany({ _id: { $in: ids } }, { isActive: true })
    case "deactivate":
      return await User.updateMany({ _id: { $in: ids } }, { isActive: false })
    case "update":
      return await User.updateMany({ _id: { $in: ids } }, data)
    case "delete":
      return await User.deleteMany({ _id: { $in: ids }, role: "student" })
    default:
      throw new Error("Invalid user action")
  }
}

async function performBulkEventAction(action, ids, data) {
  switch (action) {
    case "publish":
      return await Event.updateMany({ _id: { $in: ids } }, { status: "published" })
    case "cancel":
      return await Event.updateMany({ _id: { $in: ids } }, { status: "cancelled" })
    case "update":
      return await Event.updateMany({ _id: { $in: ids } }, data)
    case "delete":
      return await Event.deleteMany({ _id: { $in: ids } })
    default:
      throw new Error("Invalid event action")
  }
}

function convertToCSV(data) {
  if (!data.length) return ""

  const headers = Object.keys(data[0])
  const csvContent = [
    headers.join(","),
    ...data.map((row) =>
      headers
        .map((header) => {
          const value = row[header]
          return typeof value === "string" ? `"${value.replace(/"/g, '""')}"` : value
        })
        .join(","),
    ),
  ].join("\n")

  return csvContent
}

module.exports = router
