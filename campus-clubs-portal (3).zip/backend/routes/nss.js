const express = require("express")
const { validationResult, body } = require("express-validator")
const NSSActivity = require("../models/NSSActivity")
const Event = require("../models/Event")
const User = require("../models/User")
const { authenticateToken, requireAdmin, requireStudentOrAdmin } = require("../middleware/auth")
const { sendSuccess, sendError, sendValidationError, sendNotFound } = require("../utils/responseHelper")

const router = express.Router()

// @route   GET /api/nss/dashboard
// @desc    Get NSS dashboard data
// @access  Private
router.get("/dashboard", authenticateToken, async (req, res) => {
  try {
    const userId = req.user._id

    // Get user's NSS statistics
    const user = await User.findById(userId)
    const nssStats = user.nssStats

    // Get recent activities
    const recentActivities = await NSSActivity.find({ volunteer: userId })
      .sort({ date: -1 })
      .limit(5)
      .populate("verifiedBy", "name")

    // Get upcoming NSS events
    const upcomingEvents = await Event.find({
      category: "nss",
      status: "published",
      startDate: { $gte: new Date() },
    })
      .sort({ startDate: 1 })
      .limit(5)
      .populate("organizer", "name")

    // Calculate monthly progress
    const currentMonth = new Date()
    currentMonth.setDate(1)
    currentMonth.setHours(0, 0, 0, 0)

    const monthlyActivities = await NSSActivity.find({
      volunteer: userId,
      date: { $gte: currentMonth },
      status: "verified",
    })

    const monthlyHours = monthlyActivities.reduce((total, activity) => total + activity.hoursContributed, 0)
    const monthlyImpact = monthlyActivities.reduce(
      (total, activity) => {
        return {
          treesPlanted: total.treesPlanted + activity.impact.treesPlanted,
          peopleHelped: total.peopleHelped + activity.impact.peopleHelped,
          wasteCollected: total.wasteCollected + activity.impact.wasteCollected,
          fundsRaised: total.fundsRaised + activity.impact.fundsRaised,
        }
      },
      { treesPlanted: 0, peopleHelped: 0, wasteCollected: 0, fundsRaised: 0 },
    )

    // Get volunteer ranking
    const allVolunteers = await User.find({ role: "student" }).sort({ "nssStats.totalHours": -1 })

    const userRank = allVolunteers.findIndex((u) => u._id.toString() === userId.toString()) + 1

    // Calculate achievements
    const achievements = []
    if (nssStats.totalHours >= 100)
      achievements.push({ name: "Century Volunteer", description: "100+ volunteer hours" })
    if (nssStats.impactMetrics.treesPlanted >= 50)
      achievements.push({ name: "Green Warrior", description: "50+ trees planted" })
    if (nssStats.impactMetrics.peopleHelped >= 100)
      achievements.push({ name: "Community Hero", description: "100+ people helped" })
    if (nssStats.eventsAttended >= 20) achievements.push({ name: "Event Champion", description: "20+ events attended" })

    sendSuccess(
      res,
      {
        statistics: nssStats,
        recentActivities,
        upcomingEvents,
        monthlyProgress: {
          hours: monthlyHours,
          impact: monthlyImpact,
        },
        ranking: {
          position: userRank,
          totalVolunteers: allVolunteers.length,
        },
        achievements,
      },
      "NSS dashboard data retrieved successfully",
    )
  } catch (error) {
    console.error("NSS dashboard error:", error)
    sendError(res, "Failed to retrieve NSS dashboard data", 500)
  }
})

// @route   GET /api/nss/activities
// @desc    Get volunteer activities with filters
// @access  Private
router.get("/activities", authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, category, status, startDate, endDate, volunteer } = req.query
    const userId = req.user._id

    // Build filter object
    const filter = {}

    // If not admin, only show user's activities
    if (req.user.role !== "admin") {
      filter.volunteer = userId
    } else if (volunteer) {
      filter.volunteer = volunteer
    }

    if (category) filter.category = category
    if (status) filter.status = status

    if (startDate || endDate) {
      filter.date = {}
      if (startDate) filter.date.$gte = new Date(startDate)
      if (endDate) filter.date.$lte = new Date(endDate)
    }

    const skip = (page - 1) * limit

    const activities = await NSSActivity.find(filter)
      .populate("volunteer", "name rollNo department")
      .populate("verifiedBy", "name")
      .populate("collaborators", "name rollNo")
      .sort({ date: -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await NSSActivity.countDocuments(filter)

    sendSuccess(
      res,
      {
        activities,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalActivities: total,
          hasNext: page * limit < total,
          hasPrev: page > 1,
        },
      },
      "Activities retrieved successfully",
    )
  } catch (error) {
    console.error("Get activities error:", error)
    sendError(res, "Failed to retrieve activities", 500)
  }
})

// @route   POST /api/nss/activities
// @desc    Log a new volunteer activity
// @access  Private
router.post(
  "/activities",
  [
    authenticateToken,
    body("title").trim().isLength({ min: 3, max: 200 }).withMessage("Title must be between 3 and 200 characters"),
    body("description")
      .trim()
      .isLength({ min: 10, max: 1000 })
      .withMessage("Description must be between 10 and 1000 characters"),
    body("category")
      .isIn(["environment", "education", "health", "community-service", "disaster-relief", "awareness", "other"])
      .withMessage("Invalid category"),
    body("date").isISO8601().withMessage("Please provide a valid date"),
    body("hoursContributed").isFloat({ min: 0.5, max: 24 }).withMessage("Hours must be between 0.5 and 24"),
    body("location").trim().isLength({ min: 3, max: 200 }).withMessage("Location must be between 3 and 200 characters"),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return sendValidationError(res, errors.array())
      }

      const {
        title,
        description,
        category,
        date,
        hoursContributed,
        location,
        impact,
        collaborators,
        organizingBody,
        reflection,
        challenges,
        learnings,
        photos,
        documents,
      } = req.body

      // Validate date is not in future
      const activityDate = new Date(date)
      if (activityDate > new Date()) {
        return sendError(res, "Activity date cannot be in the future", 400)
      }

      // Validate collaborators exist
      if (collaborators && collaborators.length > 0) {
        const collaboratorUsers = await User.find({ _id: { $in: collaborators } })
        if (collaboratorUsers.length !== collaborators.length) {
          return sendError(res, "Some collaborators not found", 400)
        }
      }

      const activity = new NSSActivity({
        title,
        description,
        category,
        volunteer: req.user._id,
        date: activityDate,
        hoursContributed,
        location,
        impact: impact || {},
        collaborators: collaborators || [],
        organizingBody,
        reflection,
        challenges,
        learnings,
        photos: photos || [],
        documents: documents || [],
      })

      await activity.save()

      const populatedActivity = await NSSActivity.findById(activity._id)
        .populate("volunteer", "name rollNo")
        .populate("collaborators", "name rollNo")

      sendSuccess(res, populatedActivity, "Activity logged successfully", 201)
    } catch (error) {
      console.error("Log activity error:", error)
      sendError(res, "Failed to log activity", 500)
    }
  },
)

// @route   PUT /api/nss/activities/:id/verify
// @desc    Verify volunteer activity (Admin only)
// @access  Private (Admin only)
router.put("/activities/:id/verify", [authenticateToken, requireAdmin], async (req, res) => {
  try {
    const { id } = req.params
    const { status, verificationNotes } = req.body

    if (!["verified", "rejected"].includes(status)) {
      return sendError(res, "Invalid verification status", 400)
    }

    const activity = await NSSActivity.findById(id).populate("volunteer")
    if (!activity) {
      return sendNotFound(res, "Activity")
    }

    activity.status = status
    activity.verifiedBy = req.user._id
    activity.verificationDate = new Date()
    activity.verificationNotes = verificationNotes

    await activity.save()

    // Update user statistics if verified
    if (status === "verified") {
      const user = activity.volunteer
      user.nssStats.totalHours += activity.hoursContributed
      user.nssStats.eventsAttended += 1

      // Update impact metrics
      user.nssStats.impactMetrics.treesPlanted += activity.impact.treesPlanted || 0
      user.nssStats.impactMetrics.peopleHelped += activity.impact.peopleHelped || 0
      user.nssStats.impactMetrics.bloodDonated += activity.impact.bloodDonated || 0

      await user.save()
    }

    const updatedActivity = await NSSActivity.findById(id)
      .populate("volunteer", "name rollNo")
      .populate("verifiedBy", "name")

    sendSuccess(res, updatedActivity, `Activity ${status} successfully`)
  } catch (error) {
    console.error("Verify activity error:", error)
    sendError(res, "Failed to verify activity", 500)
  }
})

// @route   GET /api/nss/events
// @desc    Get NSS volunteer events
// @access  Private
router.get("/events", authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 10, status = "published", upcoming = false } = req.query

    const filter = { category: "nss" }
    if (status) filter.status = status
    if (upcoming === "true") {
      filter.startDate = { $gte: new Date() }
    }

    const skip = (page - 1) * limit

    const events = await Event.find(filter)
      .populate("organizer", "name email")
      .populate("coordinators", "name")
      .sort({ startDate: upcoming === "true" ? 1 : -1 })
      .skip(skip)
      .limit(Number.parseInt(limit))

    const total = await Event.countDocuments(filter)

    sendSuccess(
      res,
      {
        events,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(total / limit),
          totalEvents: total,
        },
      },
      "NSS events retrieved successfully",
    )
  } catch (error) {
    console.error("Get NSS events error:", error)
    sendError(res, "Failed to retrieve NSS events", 500)
  }
})

// @route   POST /api/nss/events/:id/register
// @desc    Register for NSS event
// @access  Private
router.post("/events/:id/register", authenticateToken, async (req, res) => {
  try {
    const { id } = req.params
    const userId = req.user._id

    const event = await Event.findById(id)
    if (!event) {
      return sendNotFound(res, "Event")
    }

    if (event.category !== "nss") {
      return sendError(res, "This is not an NSS event", 400)
    }

    if (event.status !== "published") {
      return sendError(res, "Event is not open for registration", 400)
    }

    if (new Date() > event.registrationDeadline) {
      return sendError(res, "Registration deadline has passed", 400)
    }

    // Check if already registered
    const existingParticipant = event.participants.find((p) => p.user.toString() === userId.toString())
    if (existingParticipant) {
      return sendError(res, "Already registered for this event", 400)
    }

    // Check capacity
    if (event.maxParticipants && event.participants.length >= event.maxParticipants) {
      return sendError(res, "Event is full", 400)
    }

    event.participants.push({
      user: userId,
      registeredAt: new Date(),
      status: "registered",
    })

    await event.save()

    const updatedEvent = await Event.findById(id)
      .populate("participants.user", "name rollNo")
      .populate("organizer", "name")

    sendSuccess(res, updatedEvent, "Successfully registered for event")
  } catch (error) {
    console.error("Event registration error:", error)
    sendError(res, "Failed to register for event", 500)
  }
})

// @route   GET /api/nss/impact-report
// @desc    Get NSS impact report
// @access  Private
router.get("/impact-report", authenticateToken, async (req, res) => {
  try {
    const { startDate, endDate, category } = req.query
    const userId = req.user._id

    // Build filter
    const filter = { status: "verified" }

    if (req.user.role !== "admin") {
      filter.volunteer = userId
    }

    if (category) filter.category = category

    if (startDate || endDate) {
      filter.date = {}
      if (startDate) filter.date.$gte = new Date(startDate)
      if (endDate) filter.date.$lte = new Date(endDate)
    }

    // Aggregate impact data
    const impactData = await NSSActivity.aggregate([
      { $match: filter },
      {
        $group: {
          _id: null,
          totalHours: { $sum: "$hoursContributed" },
          totalActivities: { $sum: 1 },
          treesPlanted: { $sum: "$impact.treesPlanted" },
          wasteCollected: { $sum: "$impact.wasteCollected" },
          peopleHelped: { $sum: "$impact.peopleHelped" },
          bloodDonated: { $sum: "$impact.bloodDonated" },
          fundsRaised: { $sum: "$impact.fundsRaised" },
          awarenessReached: { $sum: "$impact.awarenessReached" },
        },
      },
    ])

    // Category-wise breakdown
    const categoryBreakdown = await NSSActivity.aggregate([
      { $match: filter },
      {
        $group: {
          _id: "$category",
          hours: { $sum: "$hoursContributed" },
          activities: { $sum: 1 },
          impact: {
            $push: {
              treesPlanted: "$impact.treesPlanted",
              peopleHelped: "$impact.peopleHelped",
              wasteCollected: "$impact.wasteCollected",
            },
          },
        },
      },
    ])

    // Monthly trend
    const monthlyTrend = await NSSActivity.aggregate([
      { $match: filter },
      {
        $group: {
          _id: {
            year: { $year: "$date" },
            month: { $month: "$date" },
          },
          hours: { $sum: "$hoursContributed" },
          activities: { $sum: 1 },
        },
      },
      { $sort: { "_id.year": 1, "_id.month": 1 } },
    ])

    const report = {
      summary: impactData[0] || {
        totalHours: 0,
        totalActivities: 0,
        treesPlanted: 0,
        wasteCollected: 0,
        peopleHelped: 0,
        bloodDonated: 0,
        fundsRaised: 0,
        awarenessReached: 0,
      },
      categoryBreakdown,
      monthlyTrend,
      generatedAt: new Date(),
      period: {
        startDate: startDate || "All time",
        endDate: endDate || "Present",
      },
    }

    sendSuccess(res, report, "Impact report generated successfully")
  } catch (error) {
    console.error("Impact report error:", error)
    sendError(res, "Failed to generate impact report", 500)
  }
})

// @route   GET /api/nss/leaderboard
// @desc    Get NSS volunteer leaderboard
// @access  Private
router.get("/leaderboard", authenticateToken, async (req, res) => {
  try {
    const { limit = 20, category } = req.query

    // Build aggregation pipeline
    const pipeline = [
      { $match: { role: "student" } },
      {
        $lookup: {
          from: "nssactivities",
          localField: "_id",
          foreignField: "volunteer",
          as: "activities",
        },
      },
      {
        $addFields: {
          verifiedActivities: {
            $filter: {
              input: "$activities",
              cond: { $eq: ["$$this.status", "verified"] },
            },
          },
        },
      },
      {
        $addFields: {
          totalVerifiedHours: { $sum: "$verifiedActivities.hoursContributed" },
          totalVerifiedActivities: { $size: "$verifiedActivities" },
        },
      },
      {
        $sort: {
          totalVerifiedHours: -1,
          totalVerifiedActivities: -1,
          "nssStats.eventsAttended": -1,
        },
      },
      { $limit: Number.parseInt(limit) },
      {
        $project: {
          name: 1,
          rollNo: 1,
          department: 1,
          year: 1,
          profilePhoto: 1,
          "nssStats.totalHours": 1,
          "nssStats.eventsAttended": 1,
          "nssStats.impactMetrics": 1,
          totalVerifiedHours: 1,
          totalVerifiedActivities: 1,
        },
      },
    ]

    const leaderboard = await User.aggregate(pipeline)

    // Add rank to each volunteer
    const rankedLeaderboard = leaderboard.map((volunteer, index) => ({
      ...volunteer,
      rank: index + 1,
    }))

    sendSuccess(res, rankedLeaderboard, "NSS leaderboard retrieved successfully")
  } catch (error) {
    console.error("Get NSS leaderboard error:", error)
    sendError(res, "Failed to retrieve NSS leaderboard", 500)
  }
})

// @route   GET /api/nss/certificates/:id
// @desc    Generate volunteer certificate
// @access  Private
router.get("/certificates/:id", authenticateToken, async (req, res) => {
  try {
    const { id } = req.params
    const userId = req.user._id

    const activity = await NSSActivity.findById(id)
      .populate("volunteer", "name rollNo department")
      .populate("verifiedBy", "name")

    if (!activity) {
      return sendNotFound(res, "Activity")
    }

    // Check if user owns this activity or is admin
    if (activity.volunteer._id.toString() !== userId.toString() && req.user.role !== "admin") {
      return sendError(res, "Access denied", 403)
    }

    if (activity.status !== "verified") {
      return sendError(res, "Certificate can only be generated for verified activities", 400)
    }

    // Generate certificate data
    const certificate = {
      certificateId: `NSS-${activity._id.toString().slice(-8).toUpperCase()}`,
      volunteer: activity.volunteer,
      activity: {
        title: activity.title,
        category: activity.category,
        date: activity.date,
        hours: activity.hoursContributed,
        location: activity.location,
      },
      impact: activity.impact,
      verifiedBy: activity.verifiedBy,
      verificationDate: activity.verificationDate,
      generatedAt: new Date(),
    }

    sendSuccess(res, certificate, "Certificate generated successfully")
  } catch (error) {
    console.error("Generate certificate error:", error)
    sendError(res, "Failed to generate certificate", 500)
  }
})

module.exports = router
