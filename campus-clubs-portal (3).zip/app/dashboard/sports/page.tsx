"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Trophy, Calendar, Users, MapPin, Clock, Target, Award, Plus, Filter } from "lucide-react"
import Link from "next/link"

// Mock data - in real app, this would come from API
const sportsStats = {
  totalMatches: 12,
  matchesWon: 8,
  matchesLost: 3,
  matchesDraw: 1,
  goalsScored: 24,
  goalsAgainst: 12,
  winRate: 67,
  currentRank: 2,
}

const upcomingMatches = [
  {
    id: 1,
    opponent: "Engineering College",
    sport: "Football",
    date: "2024-01-15",
    time: "4:00 PM",
    venue: "Main Ground",
    type: "League Match",
  },
  {
    id: 2,
    opponent: "Medical College",
    sport: "Basketball",
    date: "2024-01-18",
    time: "3:00 PM",
    venue: "Indoor Court",
    type: "Friendly",
  },
  {
    id: 3,
    opponent: "Arts College",
    sport: "Cricket",
    date: "2024-01-22",
    time: "10:00 AM",
    venue: "Cricket Ground",
    type: "Tournament",
  },
]

const recentResults = [
  {
    id: 1,
    opponent: "Tech Institute",
    sport: "Football",
    date: "2024-01-10",
    result: "Won",
    score: "3-1",
    venue: "Main Ground",
  },
  {
    id: 2,
    opponent: "Commerce College",
    sport: "Basketball",
    date: "2024-01-08",
    result: "Won",
    score: "78-65",
    venue: "Indoor Court",
  },
  {
    id: 3,
    opponent: "Science College",
    sport: "Cricket",
    date: "2024-01-05",
    result: "Lost",
    score: "145-167",
    venue: "Away",
  },
]

const leaderboard = [
  { rank: 1, name: "Alex Johnson", sport: "Football", points: 95, matches: 12, goals: 8 },
  { rank: 2, name: "Sarah Wilson", sport: "Basketball", points: 88, matches: 10, goals: 156 },
  { rank: 3, name: "Mike Chen", sport: "Cricket", points: 82, matches: 8, goals: 45 },
  { rank: 4, name: "Emma Davis", sport: "Football", points: 78, matches: 11, goals: 6 },
  { rank: 5, name: "John Smith", sport: "Basketball", points: 75, matches: 9, goals: 134 },
]

export default function SportsPage() {
  const [selectedSport, setSelectedSport] = useState("all")

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-heading flex items-center gap-2">
            <Trophy className="h-8 w-8 text-primary" />
            Sports Club
          </h1>
          <p className="text-muted-foreground">Track matches, view results, and manage bookings</p>
        </div>
        <div className="flex gap-2">
          <Link href="/dashboard/sports/booking">
            <Button className="flex items-center gap-2">
              <Plus className="h-4 w-4" />
              Book Ground
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Matches</p>
                <p className="text-2xl font-bold">{sportsStats.totalMatches}</p>
              </div>
              <Trophy className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Win Rate</p>
                <p className="text-2xl font-bold">{sportsStats.winRate}%</p>
              </div>
              <Target className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Goals Scored</p>
                <p className="text-2xl font-bold">{sportsStats.goalsScored}</p>
              </div>
              <Award className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Current Rank</p>
                <p className="text-2xl font-bold">#{sportsStats.currentRank}</p>
              </div>
              <Users className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="matches" className="space-y-4">
        <TabsList>
          <TabsTrigger value="matches">Matches</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
          <TabsTrigger value="leaderboard">Leaderboard</TabsTrigger>
          <TabsTrigger value="booking">Booking</TabsTrigger>
        </TabsList>

        {/* Matches Tab */}
        <TabsContent value="matches" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Upcoming Matches
              </CardTitle>
              <CardDescription>Your scheduled games and tournaments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingMatches.map((match) => (
                  <div key={match.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className="text-center">
                        <p className="font-semibold">{match.date.split("-")[2]}</p>
                        <p className="text-sm text-muted-foreground">
                          {new Date(match.date).toLocaleDateString("en", { month: "short" })}
                        </p>
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold">vs {match.opponent}</h3>
                          <Badge variant="outline">{match.sport}</Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Clock className="h-3 w-3" />
                            {match.time}
                          </span>
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {match.venue}
                          </span>
                          <Badge variant="secondary" className="text-xs">
                            {match.type}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Results Tab */}
        <TabsContent value="results" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Trophy className="h-5 w-5" />
                Recent Results
              </CardTitle>
              <CardDescription>Latest match outcomes and scores</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentResults.map((result) => (
                  <div key={result.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <div
                        className={`px-3 py-1 rounded-full text-sm font-medium ${
                          result.result === "Won"
                            ? "bg-green-100 text-green-700"
                            : result.result === "Lost"
                              ? "bg-red-100 text-red-700"
                              : "bg-yellow-100 text-yellow-700"
                        }`}
                      >
                        {result.result}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold">vs {result.opponent}</h3>
                          <Badge variant="outline">{result.sport}</Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <span>{result.date}</span>
                          <span className="flex items-center gap-1">
                            <MapPin className="h-3 w-3" />
                            {result.venue}
                          </span>
                        </div>
                      </div>
                      <div className="text-right">
                        <p className="text-lg font-bold">{result.score}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Performance Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Performance Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Matches Won</span>
                  <span className="font-semibold">
                    {sportsStats.matchesWon}/{sportsStats.totalMatches}
                  </span>
                </div>
                <Progress value={(sportsStats.matchesWon / sportsStats.totalMatches) * 100} className="h-2" />

                <div className="grid grid-cols-3 gap-4 pt-4">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">{sportsStats.matchesWon}</p>
                    <p className="text-sm text-muted-foreground">Won</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-yellow-600">{sportsStats.matchesDraw}</p>
                    <p className="text-sm text-muted-foreground">Draw</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-red-600">{sportsStats.matchesLost}</p>
                    <p className="text-sm text-muted-foreground">Lost</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Leaderboard Tab */}
        <TabsContent value="leaderboard" className="space-y-4">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <Award className="h-5 w-5" />
                    Player Leaderboard
                  </CardTitle>
                  <CardDescription>Top performing players across all sports</CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <Filter className="h-4 w-4 mr-2" />
                  Filter Sport
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {leaderboard.map((player) => (
                  <div key={player.rank} className="flex items-center gap-4 p-3 border rounded-lg">
                    <div
                      className={`flex items-center justify-center w-8 h-8 rounded-full font-bold text-sm ${
                        player.rank === 1
                          ? "bg-yellow-100 text-yellow-700"
                          : player.rank === 2
                            ? "bg-gray-100 text-gray-700"
                            : player.rank === 3
                              ? "bg-orange-100 text-orange-700"
                              : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {player.rank}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2">
                        <h3 className="font-semibold">{player.name}</h3>
                        <Badge variant="outline">{player.sport}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {player.matches} matches • {player.goals} {player.sport === "Basketball" ? "points" : "goals"}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold">{player.points}</p>
                      <p className="text-sm text-muted-foreground">points</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Booking Tab */}
        <TabsContent value="booking" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Ground Booking</CardTitle>
                <CardDescription>Reserve sports facilities for practice or matches</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 border rounded-lg text-center hover:bg-muted cursor-pointer">
                    <Trophy className="h-8 w-8 mx-auto mb-2 text-primary" />
                    <h3 className="font-semibold">Football Ground</h3>
                    <p className="text-sm text-muted-foreground">Main Ground</p>
                  </div>
                  <div className="p-4 border rounded-lg text-center hover:bg-muted cursor-pointer">
                    <Target className="h-8 w-8 mx-auto mb-2 text-primary" />
                    <h3 className="font-semibold">Basketball Court</h3>
                    <p className="text-sm text-muted-foreground">Indoor Court</p>
                  </div>
                  <div className="p-4 border rounded-lg text-center hover:bg-muted cursor-pointer">
                    <Award className="h-8 w-8 mx-auto mb-2 text-primary" />
                    <h3 className="font-semibold">Cricket Ground</h3>
                    <p className="text-sm text-muted-foreground">Cricket Field</p>
                  </div>
                  <div className="p-4 border rounded-lg text-center hover:bg-muted cursor-pointer">
                    <Users className="h-8 w-8 mx-auto mb-2 text-primary" />
                    <h3 className="font-semibold">Tennis Court</h3>
                    <p className="text-sm text-muted-foreground">Outdoor Court</p>
                  </div>
                </div>
                <Link href="/dashboard/sports/booking">
                  <Button className="w-full">Book Now</Button>
                </Link>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Equipment Booking</CardTitle>
                <CardDescription>Borrow sports equipment for training</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-semibold">Football Kit</h4>
                      <p className="text-sm text-muted-foreground">Balls, cones, bibs</p>
                    </div>
                    <Badge variant="secondary">Available</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-semibold">Basketball Set</h4>
                      <p className="text-sm text-muted-foreground">Balls, scoreboard</p>
                    </div>
                    <Badge variant="secondary">Available</Badge>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-semibold">Cricket Equipment</h4>
                      <p className="text-sm text-muted-foreground">Bats, balls, stumps</p>
                    </div>
                    <Badge variant="destructive">Booked</Badge>
                  </div>
                </div>
                <Button className="w-full bg-transparent" variant="outline">
                  Request Equipment
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
