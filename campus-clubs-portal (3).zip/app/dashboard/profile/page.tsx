"use client"

import { useState, useEffect } from "react"
import { useAuth } from "@/components/auth/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { useToast } from "@/hooks/use-toast"
import { Camera, Download, Edit, Trophy, Heart, Shield, Calendar, Award } from "lucide-react"

export default function ProfilePage() {
  const { user } = useAuth()
  const { toast } = useToast()
  const [isEditing, setIsEditing] = useState(false)
  const [isLoading, setIsLoading] = useState(false)
  const [profileData, setProfileData] = useState({
    name: user?.name || "",
    email: user?.email || "",
    rollNo: user?.rollNo || "",
    phone: "",
    department: "",
    year: "",
    bio: "",
  })

  useEffect(() => {
    if (user) {
      fetchProfile()
    }
  }, [user])

  const fetchProfile = async () => {
    try {
      const response = await fetch(`/api/profile/${user?.id}`)
      if (response.ok) {
        const data = await response.json()
        setProfileData(data)
      }
    } catch (error) {
      console.error("Error fetching profile:", error)
    }
  }

  const handleSave = async () => {
    if (!user) return

    setIsLoading(true)
    try {
      const response = await fetch(`/api/profile/${user.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(profileData),
      })

      if (response.ok) {
        toast({
          title: "Success",
          description: "Profile updated successfully",
        })
        setIsEditing(false)
      } else {
        toast({
          title: "Error",
          description: "Failed to update profile",
          variant: "destructive",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  const downloadTranscript = async () => {
    if (!user) return

    try {
      const response = await fetch(`/api/profile/${user.id}/transcript`)
      if (response.ok) {
        const blob = await response.blob()
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `activity-transcript-${user.rollNo}.pdf`
        a.click()
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to download transcript",
        variant: "destructive",
      })
    }
  }

  const activityStats = {
    sports: { events: 12, hours: 48, achievements: 3 },
    nss: { events: 8, hours: 45, achievements: 2 },
    ncc: { events: 18, hours: 72, achievements: 4 },
  }

  const recentActivities = [
    { date: "2024-01-10", activity: "Football Match vs Tech College", type: "sports", result: "Won 3-1" },
    { date: "2024-01-08", activity: "Blood Donation Camp", type: "nss", result: "Volunteered 4 hours" },
    { date: "2024-01-05", activity: "Morning Drill Practice", type: "ncc", result: "Perfect attendance" },
    { date: "2024-01-03", activity: "Tree Plantation Drive", type: "nss", result: "Planted 10 trees" },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-heading">Profile</h1>
          <p className="text-muted-foreground">Manage your personal information and view your achievements</p>
        </div>
        <Button onClick={downloadTranscript} className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Download Transcript
        </Button>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Profile Information */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Personal Information</CardTitle>
                  <CardDescription>Your basic profile details</CardDescription>
                </div>
                <Button variant="outline" size="sm" onClick={() => setIsEditing(!isEditing)} disabled={isLoading}>
                  <Edit className="h-4 w-4 mr-2" />
                  {isEditing ? "Cancel" : "Edit"}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Profile Photo */}
              <div className="flex items-center gap-4">
                <Avatar className="h-20 w-20">
                  <AvatarImage src={user?.profilePhoto || "/placeholder.svg"} />
                  <AvatarFallback className="bg-primary text-primary-foreground text-lg">
                    {user?.name
                      .split(" ")
                      .map((n) => n[0])
                      .join("")}
                  </AvatarFallback>
                </Avatar>
                <div>
                  {isEditing && (
                    <Button variant="outline" size="sm" className="flex items-center gap-2 bg-transparent">
                      <Camera className="h-4 w-4" />
                      Change Photo
                    </Button>
                  )}
                  <p className="text-sm text-muted-foreground mt-1">JPG, PNG up to 2MB</p>
                </div>
              </div>

              {/* Profile Form */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Full Name</Label>
                  <Input
                    id="name"
                    value={profileData.name}
                    onChange={(e) => setProfileData({ ...profileData, name: e.target.value })}
                    disabled={!isEditing}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="rollno">Roll Number</Label>
                  <Input
                    id="rollno"
                    value={profileData.rollNo}
                    onChange={(e) => setProfileData({ ...profileData, rollNo: e.target.value })}
                    disabled={!isEditing}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={profileData.email}
                    onChange={(e) => setProfileData({ ...profileData, email: e.target.value })}
                    disabled={!isEditing}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    value={profileData.phone}
                    onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                    disabled={!isEditing}
                    placeholder="Enter phone number"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="department">Department</Label>
                  <Input
                    id="department"
                    value={profileData.department}
                    onChange={(e) => setProfileData({ ...profileData, department: e.target.value })}
                    disabled={!isEditing}
                    placeholder="e.g., Computer Science"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="year">Year</Label>
                  <Input
                    id="year"
                    value={profileData.year}
                    onChange={(e) => setProfileData({ ...profileData, year: e.target.value })}
                    disabled={!isEditing}
                    placeholder="e.g., 3rd Year"
                  />
                </div>
              </div>

              {isEditing && (
                <div className="flex gap-2">
                  <Button onClick={handleSave} disabled={isLoading}>
                    {isLoading ? "Saving..." : "Save Changes"}
                  </Button>
                  <Button variant="outline" onClick={() => setIsEditing(false)} disabled={isLoading}>
                    Cancel
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Badges and Quick Stats */}
        <div className="space-y-6">
          {/* Badges */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Badges Earned
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {user?.badges?.map((badge, index) => (
                  <Badge key={index} variant="secondary">
                    {badge}
                  </Badge>
                ))}
                <Badge variant="outline" className="text-yellow-600 border-yellow-600">
                  Sports Champion
                </Badge>
                <Badge variant="outline" className="text-red-600 border-red-600">
                  Community Hero
                </Badge>
                <Badge variant="outline" className="text-blue-600 border-blue-600">
                  Disciplined Cadet
                </Badge>
              </div>
            </CardContent>
          </Card>

          {/* Activity Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Activity Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Trophy className="h-4 w-4 text-yellow-600" />
                  <span className="text-sm">Sports</span>
                </div>
                <div className="text-right">
                  <p className="font-semibold">{activityStats.sports.events} events</p>
                  <p className="text-xs text-muted-foreground">{activityStats.sports.hours} hours</p>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Heart className="h-4 w-4 text-red-600" />
                  <span className="text-sm">NSS</span>
                </div>
                <div className="text-right">
                  <p className="font-semibold">{activityStats.nss.events} events</p>
                  <p className="text-xs text-muted-foreground">{activityStats.nss.hours} hours</p>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Shield className="h-4 w-4 text-blue-600" />
                  <span className="text-sm">NCC</span>
                </div>
                <div className="text-right">
                  <p className="font-semibold">{activityStats.ncc.events} events</p>
                  <p className="text-xs text-muted-foreground">{activityStats.ncc.hours} hours</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Activity History */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Recent Activity
          </CardTitle>
          <CardDescription>Your latest participation across all clubs</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivities.map((activity, index) => (
              <div key={index} className="flex items-center gap-4 p-3 rounded-lg border">
                <div
                  className={`p-2 rounded-lg ${
                    activity.type === "sports"
                      ? "bg-yellow-100 text-yellow-700"
                      : activity.type === "nss"
                        ? "bg-red-100 text-red-700"
                        : "bg-blue-100 text-blue-700"
                  }`}
                >
                  {activity.type === "sports" ? (
                    <Trophy className="h-4 w-4" />
                  ) : activity.type === "nss" ? (
                    <Heart className="h-4 w-4" />
                  ) : (
                    <Shield className="h-4 w-4" />
                  )}
                </div>
                <div className="flex-1">
                  <h4 className="font-semibold">{activity.activity}</h4>
                  <p className="text-sm text-muted-foreground">{activity.result}</p>
                </div>
                <div className="text-sm text-muted-foreground">{activity.date}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
