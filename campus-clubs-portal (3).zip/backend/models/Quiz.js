const mongoose = require("mongoose")

const quizSchema = new mongoose.Schema({
  // Quiz Details
  title: {
    type: String,
    required: [true, "Quiz title is required"],
    trim: true,
  },
  description: {
    type: String,
    required: [true, "Quiz description is required"],
  },
  category: {
    type: String,
    enum: ["ncc-knowledge", "drill-commands", "military-history", "general-knowledge", "leadership"],
    required: [true, "Quiz category is required"],
  },

  // Quiz Configuration
  questions: [
    {
      question: {
        type: String,
        required: [true, "Question text is required"],
      },
      type: {
        type: String,
        enum: ["multiple-choice", "true-false", "short-answer"],
        default: "multiple-choice",
      },
      options: [String], // For multiple choice questions
      correctAnswer: {
        type: String,
        required: [true, "Correct answer is required"],
      },
      explanation: String,
      points: {
        type: Number,
        default: 1,
      },
    },
  ],

  // Quiz Settings
  timeLimit: {
    type: Number, // in minutes
    required: [true, "Time limit is required"],
    min: [5, "Minimum time limit is 5 minutes"],
  },
  maxAttempts: {
    type: Number,
    default: 1,
    min: [1, "Minimum 1 attempt allowed"],
  },
  passingScore: {
    type: Number,
    required: [true, "Passing score is required"],
    min: [0, "Passing score cannot be negative"],
    max: [100, "Passing score cannot exceed 100"],
  },

  // Availability
  startDate: {
    type: Date,
    required: [true, "Start date is required"],
  },
  endDate: {
    type: Date,
    required: [true, "End date is required"],
  },
  isActive: {
    type: Boolean,
    default: true,
  },

  // Creator
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: [true, "Creator is required"],
  },

  // Attempts
  attempts: [
    {
      user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
      startedAt: {
        type: Date,
        default: Date.now,
      },
      completedAt: Date,
      answers: [
        {
          questionIndex: Number,
          selectedAnswer: String,
          isCorrect: Boolean,
          pointsEarned: Number,
        },
      ],
      score: {
        type: Number,
        min: 0,
        max: 100,
      },
      totalPoints: Number,
      maxPoints: Number,
      passed: Boolean,
      timeSpent: Number, // in seconds
      status: {
        type: String,
        enum: ["in-progress", "completed", "abandoned"],
        default: "in-progress",
      },
    },
  ],

  // Statistics
  statistics: {
    totalAttempts: {
      type: Number,
      default: 0,
    },
    averageScore: {
      type: Number,
      default: 0,
    },
    passRate: {
      type: Number,
      default: 0,
    },
  },

  // Timestamps
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

// Indexes
quizSchema.index({ category: 1, isActive: 1 })
quizSchema.index({ createdBy: 1 })
quizSchema.index({ startDate: 1, endDate: 1 })
quizSchema.index({ "attempts.user": 1 })

// Pre-save middleware
quizSchema.pre("save", function (next) {
  this.updatedAt = Date.now()
  next()
})

// Virtual for total questions
quizSchema.virtual("totalQuestions").get(function () {
  return this.questions.length
})

// Virtual for max possible points
quizSchema.virtual("maxPossiblePoints").get(function () {
  return this.questions.reduce((total, question) => total + question.points, 0)
})

module.exports = mongoose.model("Quiz", quizSchema)
