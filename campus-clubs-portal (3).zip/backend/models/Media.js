const mongoose = require("mongoose")

const mediaSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Media title is required"],
  },
  description: String,
  url: {
    type: String,
    required: [true, "Media URL is required"],
  },
  type: {
    type: String,
    enum: ["photo", "video"],
    required: true,
  },
  eventId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "Event",
  },
  eventName: String,
  category: {
    type: String,
    enum: ["sports", "nss", "ncc"],
  },
  uploadedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: true,
  },
  uploadedDate: {
    type: Date,
    default: Date.now,
  },
  tags: [String],
  isPublic: {
    type: Boolean,
    default: false,
  },
  createdAt: {
    type: Date,
    default: Date.now,
  },
})

module.exports = mongoose.model("Media", mediaSchema)
