const mongoose = require("mongoose")
const bcrypt = require("bcryptjs")

const userSchema = new mongoose.Schema({
  // Basic Information
  name: {
    type: String,
    required: [true, "Name is required"],
    trim: true,
    maxlength: [100, "Name cannot exceed 100 characters"],
  },
  email: {
    type: String,
    required: [true, "Email is required"],
    unique: true,
    lowercase: true,
    match: [/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/, "Please enter a valid email"],
  },
  password: {
    type: String,
    required: [true, "Password is required"],
    minlength: [6, "Password must be at least 6 characters"],
    select: false,
  },
  rollNo: {
    type: String,
    required: [true, "Roll number is required"],
    unique: true,
    uppercase: true,
    match: [/^[A-Z0-9]{6,12}$/, "Invalid roll number format"],
  },

  // Profile Information
  profilePhoto: {
    type: String,
    default: null,
  },
  phone: {
    type: String,
    match: [/^[0-9]{10}$/, "Please enter a valid 10-digit phone number"],
  },
  department: {
    type: String,
    required: [true, "Department is required"],
    enum: ["CSE", "ECE", "EEE", "MECH", "CIVIL", "IT", "OTHER"],
  },
  year: {
    type: Number,
    required: [true, "Year is required"],
    min: [1, "Year must be between 1-4"],
    max: [4, "Year must be between 1-4"],
  },

  // Role and Permissions
  role: {
    type: String,
    enum: ["student", "admin"],
    default: "student",
  },
  adminSections: [
    {
      type: String,
      enum: ["sports", "nss", "ncc"],
    },
  ],

  // Activity Tracking
  badges: [
    {
      name: String,
      description: String,
      earnedAt: {
        type: Date,
        default: Date.now,
      },
      category: {
        type: String,
        enum: ["sports", "nss", "ncc", "general"],
      },
    },
  ],

  // Sports Statistics
  sportsStats: {
    matchesPlayed: {
      type: Number,
      default: 0,
    },
    matchesWon: {
      type: Number,
      default: 0,
    },
    totalScore: {
      type: Number,
      default: 0,
    },
    favoritesSports: [String],
  },

  // NSS Statistics
  nssStats: {
    totalHours: {
      type: Number,
      default: 0,
    },
    eventsAttended: {
      type: Number,
      default: 0,
    },
    impactMetrics: {
      treesPlanted: {
        type: Number,
        default: 0,
      },
      bloodDonated: {
        type: Number,
        default: 0,
      },
      peopleHelped: {
        type: Number,
        default: 0,
      },
    },
  },

  // NCC Statistics
  nccStats: {
    currentRank: {
      type: String,
      enum: ["Cadet", "Lance Corporal", "Corporal", "Sergeant", "Under Officer", "Cadet Captain"],
      default: "Cadet",
    },
    drillsAttended: {
      type: Number,
      default: 0,
    },
    trainingHours: {
      type: Number,
      default: 0,
    },
    disciplineScore: {
      type: Number,
      default: 100,
      min: 0,
      max: 100,
    },
  },

  // Account Status
  isActive: {
    type: Boolean,
    default: true,
  },
  isEmailVerified: {
    type: Boolean,
    default: false,
  },
  lastLogin: {
    type: Date,
    default: Date.now,
  },

  // Timestamps
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

// Indexes for better performance
userSchema.index({ email: 1 })
userSchema.index({ rollNo: 1 })
userSchema.index({ role: 1 })
userSchema.index({ department: 1, year: 1 })

// Pre-save middleware to hash password
userSchema.pre("save", async function (next) {
  if (!this.isModified("password")) return next()

  this.password = await bcrypt.hash(this.password, 12)
  next()
})

// Update timestamp on save
userSchema.pre("save", function (next) {
  this.updatedAt = Date.now()
  next()
})

// Instance method to check password
userSchema.methods.comparePassword = async function (candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password)
}

// Instance method to get public profile
userSchema.methods.getPublicProfile = function () {
  const user = this.toObject()
  delete user.password
  return user
}

module.exports = mongoose.model("User", userSchema)
