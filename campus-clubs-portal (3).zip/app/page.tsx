"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/auth/auth-context"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"

export default function HomePage() {
  const { user, login, register } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [loginData, setLoginData] = useState({ email: "", password: "" })
  const [registerData, setRegisterData] = useState({
    name: "",
    email: "",
    password: "",
    rollNo: "",
    role: "student" as "student" | "admin",
  })

  useEffect(() => {
    if (user) {
      router.push("/dashboard")
    }
  }, [user, router])

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    const success = await login(loginData.email, loginData.password)
    if (success) {
      toast({
        title: "Welcome back!",
        description: "You have been successfully logged in.",
      })
      router.push("/dashboard")
    } else {
      toast({
        title: "Login failed",
        description: "Please check your credentials and try again.",
        variant: "destructive",
      })
    }
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    const success = await register(registerData)
    if (success) {
      toast({
        title: "Account created!",
        description: "Welcome to Campus Clubs Portal.",
      })
      router.push("/dashboard")
    } else {
      toast({
        title: "Registration failed",
        description: "Please try again with different details.",
        variant: "destructive",
      })
    }
  }

  if (user) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto mb-4"></div>
          <p>Redirecting to dashboard...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <header className="border-b border-purple-500/20 bg-slate-900/80 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-to-br from-purple-500 via-pink-500 to-red-500 text-white shadow-lg shadow-purple-500/50">
                <span className="font-bold text-lg">🎓</span>
              </div>
              <div>
                <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-red-400 bg-clip-text text-transparent">
                  Campus Clubs Portal
                </h1>
                <p className="text-sm text-purple-300/80">Sports • NSS • NCC</p>
              </div>
            </div>
            <Badge className="hidden sm:flex bg-gradient-to-r from-purple-500 to-pink-500 border-0 shadow-lg shadow-purple-500/50">
              All-in-One Platform
            </Badge>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-12">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <span className="text-2xl">✨</span>
                <span className="text-sm font-semibold text-pink-400">Welcome to Excellence</span>
              </div>
              <h2 className="text-5xl font-bold bg-gradient-to-r from-purple-300 via-pink-300 to-red-300 bg-clip-text text-transparent leading-tight">
                Manage Your Campus Journey
              </h2>
              <p className="text-lg text-slate-300 leading-relaxed">
                Unified platform for Sports Club participation, NSS volunteering, and NCC training. Track achievements,
                manage bookings, and connect with your community.
              </p>
            </div>

            <div className="grid sm:grid-cols-3 gap-4">
              <div className="group cursor-pointer transform transition-all duration-300 hover:scale-105">
                <Card className="border-0 bg-gradient-to-br from-purple-500/20 to-purple-600/20 backdrop-blur hover:shadow-2xl hover:shadow-purple-500/50 transition-all duration-300">
                  <CardContent className="pt-6">
                    <div className="text-4xl text-center mb-3">🏆</div>
                    <h3 className="font-semibold text-purple-100 text-center">Sports Club</h3>
                    <p className="text-sm text-purple-300/70 text-center">Matches & tournaments</p>
                  </CardContent>
                </Card>
              </div>
              <div className="group cursor-pointer transform transition-all duration-300 hover:scale-105">
                <Card className="border-0 bg-gradient-to-br from-pink-500/20 to-pink-600/20 backdrop-blur hover:shadow-2xl hover:shadow-pink-500/50 transition-all duration-300">
                  <CardContent className="pt-6">
                    <div className="text-4xl text-center mb-3">❤️</div>
                    <h3 className="font-semibold text-pink-100 text-center">NSS</h3>
                    <p className="text-sm text-pink-300/70 text-center">Volunteer hours & service</p>
                  </CardContent>
                </Card>
              </div>
              <div className="group cursor-pointer transform transition-all duration-300 hover:scale-105">
                <Card className="border-0 bg-gradient-to-br from-red-500/20 to-red-600/20 backdrop-blur hover:shadow-2xl hover:shadow-red-500/50 transition-all duration-300">
                  <CardContent className="pt-6">
                    <div className="text-4xl text-center mb-3">⚔️</div>
                    <h3 className="font-semibold text-red-100 text-center">NCC</h3>
                    <p className="text-sm text-red-300/70 text-center">Training & ranks</p>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>

          <div className="w-full max-w-md mx-auto">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500/30 to-pink-500/30 rounded-2xl blur-3xl opacity-50" />
            <Card className="border border-purple-500/30 shadow-2xl shadow-purple-500/20 bg-slate-800/80 backdrop-blur-xl">
              <CardHeader className="text-center space-y-2 pb-6">
                <CardTitle className="text-2xl bg-gradient-to-r from-purple-300 via-pink-300 to-red-300 bg-clip-text text-transparent">
                  Get Started
                </CardTitle>
                <CardDescription className="text-slate-400">Sign in or create your account</CardDescription>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="login" className="w-full">
                  <TabsList className="grid w-full grid-cols-2 bg-slate-700/50 mb-6 border border-slate-600">
                    <TabsTrigger
                      value="login"
                      className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white text-slate-300"
                    >
                      Sign In
                    </TabsTrigger>
                    <TabsTrigger
                      value="register"
                      className="data-[state=active]:bg-gradient-to-r data-[state=active]:from-purple-600 data-[state=active]:to-pink-600 data-[state=active]:text-white text-slate-300"
                    >
                      Register
                    </TabsTrigger>
                  </TabsList>

                  <TabsContent value="login" className="space-y-4">
                    <form onSubmit={handleLogin} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="login-email" className="text-slate-300">
                          Email
                        </Label>
                        <Input
                          id="login-email"
                          type="email"
                          placeholder="your.email@college.edu"
                          className="border-slate-600/50 bg-slate-700/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500"
                          value={loginData.email}
                          onChange={(e) => setLoginData({ ...loginData, email: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="login-password" className="text-slate-300">
                          Password
                        </Label>
                        <Input
                          id="login-password"
                          type="password"
                          className="border-slate-600/50 bg-slate-700/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500"
                          value={loginData.password}
                          onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                          required
                        />
                      </div>
                      <Button
                        type="submit"
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:shadow-lg hover:shadow-purple-500/50 transition-all text-white border-0"
                      >
                        Sign In →
                      </Button>
                    </form>
                  </TabsContent>

                  <TabsContent value="register" className="space-y-4">
                    <form onSubmit={handleRegister} className="space-y-4">
                      <div className="space-y-2">
                        <Label htmlFor="register-name" className="text-slate-300">
                          Full Name
                        </Label>
                        <Input
                          id="register-name"
                          placeholder="John Doe"
                          className="border-slate-600/50 bg-slate-700/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500"
                          value={registerData.name}
                          onChange={(e) => setRegisterData({ ...registerData, name: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="register-email" className="text-slate-300">
                          Email
                        </Label>
                        <Input
                          id="register-email"
                          type="email"
                          placeholder="your.email@college.edu"
                          className="border-slate-600/50 bg-slate-700/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500"
                          value={registerData.email}
                          onChange={(e) => setRegisterData({ ...registerData, email: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="register-rollno" className="text-slate-300">
                          Roll Number
                        </Label>
                        <Input
                          id="register-rollno"
                          placeholder="CS21B001"
                          className="border-slate-600/50 bg-slate-700/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500"
                          value={registerData.rollNo}
                          onChange={(e) => setRegisterData({ ...registerData, rollNo: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="register-password" className="text-slate-300">
                          Password
                        </Label>
                        <Input
                          id="register-password"
                          type="password"
                          className="border-slate-600/50 bg-slate-700/50 text-slate-100 placeholder:text-slate-500 focus:border-purple-500"
                          value={registerData.password}
                          onChange={(e) => setRegisterData({ ...registerData, password: e.target.value })}
                          required
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="register-role" className="text-slate-300">
                          Role
                        </Label>
                        <select
                          id="register-role"
                          className="flex h-10 w-full rounded-md border border-slate-600/50 bg-slate-700/50 px-3 py-2 text-sm text-slate-100 ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-purple-500 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                          value={registerData.role}
                          onChange={(e) =>
                            setRegisterData({ ...registerData, role: e.target.value as "student" | "admin" })
                          }
                        >
                          <option value="student">Student</option>
                          <option value="admin">Admin/Coordinator</option>
                        </select>
                      </div>
                      <Button
                        type="submit"
                        className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:shadow-lg hover:shadow-purple-500/50 transition-all text-white border-0"
                      >
                        Create Account →
                      </Button>
                    </form>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
