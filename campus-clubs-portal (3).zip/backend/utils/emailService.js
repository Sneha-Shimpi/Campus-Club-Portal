const nodemailer = require("nodemailer")

// Create email transporter
const createTransporter = () => {
  return nodemailer.createTransporter({
    host: process.env.EMAIL_HOST,
    port: process.env.EMAIL_PORT,
    secure: false, // true for 465, false for other ports
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  })
}

// Send welcome email
const sendWelcomeEmail = async (user) => {
  try {
    const transporter = createTransporter()

    const mailOptions = {
      from: process.env.EMAIL_FROM,
      to: user.email,
      subject: "Welcome to Campus Clubs Portal!",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #059669;">Welcome to Campus Clubs Portal!</h2>
          <p>Dear ${user.name},</p>
          <p>Your account has been successfully created. Here are your details:</p>
          <ul>
            <li><strong>Name:</strong> ${user.name}</li>
            <li><strong>Email:</strong> ${user.email}</li>
            <li><strong>Roll Number:</strong> ${user.rollNo}</li>
            <li><strong>Department:</strong> ${user.department}</li>
            <li><strong>Year:</strong> ${user.year}</li>
          </ul>
          <p>You can now access Sports Club, NSS, and NCC features through your dashboard.</p>
          <p>Best regards,<br>Campus Clubs Portal Team</p>
        </div>
      `,
    }

    await transporter.sendMail(mailOptions)
    console.log(`Welcome email sent to ${user.email}`)
  } catch (error) {
    console.error("Failed to send welcome email:", error)
  }
}

// Send password reset email
const sendPasswordResetEmail = async (user, resetToken) => {
  try {
    const transporter = createTransporter()
    const resetUrl = `${process.env.FRONTEND_URL}/reset-password?token=${resetToken}`

    const mailOptions = {
      from: process.env.EMAIL_FROM,
      to: user.email,
      subject: "Password Reset Request - Campus Clubs Portal",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
          <h2 style="color: #059669;">Password Reset Request</h2>
          <p>Dear ${user.name},</p>
          <p>You have requested to reset your password. Click the link below to reset your password:</p>
          <p>
            <a href="${resetUrl}" style="background-color: #059669; color: white; padding: 12px 24px; text-decoration: none; border-radius: 4px; display: inline-block;">
              Reset Password
            </a>
          </p>
          <p>This link will expire in 1 hour.</p>
          <p>If you didn't request this password reset, please ignore this email.</p>
          <p>Best regards,<br>Campus Clubs Portal Team</p>
        </div>
      `,
    }

    await transporter.sendMail(mailOptions)
    console.log(`Password reset email sent to ${user.email}`)
  } catch (error) {
    console.error("Failed to send password reset email:", error)
  }
}

module.exports = {
  sendWelcomeEmail,
  sendPasswordResetEmail,
}
