const { body, param, query } = require("express-validator")

// Common validation rules
const commonValidations = {
  // User validations
  name: body("name").trim().isLength({ min: 2, max: 100 }).withMessage("Name must be between 2 and 100 characters"),

  email: body("email").isEmail().normalizeEmail().withMessage("Please provide a valid email"),

  password: body("password")
    .isLength({ min: 6 })
    .withMessage("Password must be at least 6 characters long")
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage("Password must contain at least one uppercase letter, one lowercase letter, and one number"),

  rollNo: body("rollNo")
    .trim()
    .toUpperCase()
    .matches(/^[A-Z0-9]{6,12}$/)
    .withMessage("Roll number must be 6-12 characters long and contain only letters and numbers"),

  department: body("department")
    .isIn(["CSE", "ECE", "EEE", "MECH", "CIVIL", "IT", "OTHER"])
    .withMessage("Please select a valid department"),

  year: body("year").isInt({ min: 1, max: 4 }).withMessage("Year must be between 1 and 4"),

  phone: body("phone")
    .optional()
    .matches(/^[0-9]{10}$/)
    .withMessage("Phone number must be 10 digits"),

  // MongoDB ObjectId validation
  mongoId: param("id").isMongoId().withMessage("Invalid ID format"),

  // Date validations
  date: body("date").isISO8601().withMessage("Please provide a valid date"),

  startDate: body("startDate").isISO8601().withMessage("Please provide a valid start date"),

  endDate: body("endDate").isISO8601().withMessage("Please provide a valid end date"),

  // Pagination
  page: query("page").optional().isInt({ min: 1 }).withMessage("Page must be a positive integer"),

  limit: query("limit").optional().isInt({ min: 1, max: 100 }).withMessage("Limit must be between 1 and 100"),

  // Search
  search: query("search")
    .optional()
    .trim()
    .isLength({ min: 1, max: 100 })
    .withMessage("Search term must be between 1 and 100 characters"),
}

// Validation rule sets for different endpoints
const validationRules = {
  // Authentication
  register: [
    commonValidations.name,
    commonValidations.email,
    commonValidations.password,
    commonValidations.rollNo,
    commonValidations.department,
    commonValidations.year,
    commonValidations.phone,
  ],

  login: [commonValidations.email, body("password").notEmpty().withMessage("Password is required")],

  updateProfile: [
    commonValidations.name.optional(),
    commonValidations.phone,
    commonValidations.department.optional(),
    commonValidations.year.optional(),
  ],

  changePassword: [
    body("currentPassword").notEmpty().withMessage("Current password is required"),
    commonValidations.password.custom((value, { req }) => {
      if (value === req.body.currentPassword) {
        throw new Error("New password must be different from current password")
      }
      return true
    }),
  ],

  // Events
  createEvent: [
    body("title").trim().isLength({ min: 3, max: 200 }).withMessage("Event title must be between 3 and 200 characters"),
    body("description")
      .trim()
      .isLength({ min: 10, max: 1000 })
      .withMessage("Event description must be between 10 and 1000 characters"),
    body("category").isIn(["sports", "nss", "ncc", "general"]).withMessage("Invalid event category"),
    body("type")
      .isIn(["match", "tournament", "volunteer", "training", "workshop", "meeting", "other"])
      .withMessage("Invalid event type"),
    commonValidations.startDate,
    commonValidations.endDate,
    body("venue").trim().isLength({ min: 3, max: 200 }).withMessage("Venue must be between 3 and 200 characters"),
    body("maxParticipants").optional().isInt({ min: 1 }).withMessage("Maximum participants must be at least 1"),
  ],

  // Pagination and search
  pagination: [commonValidations.page, commonValidations.limit, commonValidations.search],

  // MongoDB ID
  mongoId: [commonValidations.mongoId],
}

module.exports = {
  commonValidations,
  validationRules,
}
