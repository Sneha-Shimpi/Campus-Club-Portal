"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { useToast } from "@/hooks/use-toast"
import { CalendarIcon, Clock, MapPin, Users, Trophy, Target, Award } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"

const facilities = [
  {
    id: "football-ground",
    name: "Football Ground",
    description: "Main outdoor football field with floodlights",
    capacity: "22 players",
    icon: Trophy,
    available: true,
  },
  {
    id: "basketball-court",
    name: "Basketball Court",
    description: "Indoor court with professional flooring",
    capacity: "10 players",
    icon: Target,
    available: true,
  },
  {
    id: "cricket-ground",
    name: "Cricket Ground",
    description: "Full-size cricket field with pavilion",
    capacity: "22 players",
    icon: Award,
    available: false,
  },
  {
    id: "tennis-court",
    name: "Tennis Court",
    description: "Outdoor tennis court with net",
    capacity: "4 players",
    icon: Users,
    available: true,
  },
]

const timeSlots = [
  "06:00 AM - 08:00 AM",
  "08:00 AM - 10:00 AM",
  "10:00 AM - 12:00 PM",
  "12:00 PM - 02:00 PM",
  "02:00 PM - 04:00 PM",
  "04:00 PM - 06:00 PM",
  "06:00 PM - 08:00 PM",
  "08:00 PM - 10:00 PM",
]

export default function BookingPage() {
  const { toast } = useToast()
  const [selectedFacility, setSelectedFacility] = useState("")
  const [selectedDate, setSelectedDate] = useState<Date>()
  const [selectedTime, setSelectedTime] = useState("")
  const [isPopoverOpen, setIsPopoverOpen] = useState(false)
  const [bookingData, setBookingData] = useState({
    purpose: "",
    participants: "",
    contactPerson: "",
    phone: "",
    additionalNotes: "",
  })

  const handleBooking = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!selectedFacility || !selectedDate || !selectedTime) {
      toast({
        title: "Missing Information",
        description: "Please select facility, date, and time slot.",
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          facility: selectedFacility,
          date: selectedDate.toISOString(),
          time: selectedTime,
          ...bookingData,
        }),
      })

      if (response.ok) {
        toast({
          title: "Booking Submitted!",
          description: "Your booking request has been submitted for approval.",
        })

        setSelectedFacility("")
        setSelectedDate(undefined)
        setSelectedTime("")
        setBookingData({
          purpose: "",
          participants: "",
          contactPerson: "",
          phone: "",
          additionalNotes: "",
        })
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to submit booking",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold font-heading">Ground & Equipment Booking</h1>
        <p className="text-muted-foreground">Reserve sports facilities and equipment for your activities</p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Booking Form */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>New Booking Request</CardTitle>
              <CardDescription>Fill out the form to request a facility booking</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleBooking} className="space-y-6">
                {/* Facility Selection */}
                <div className="space-y-3">
                  <Label>Select Facility</Label>
                  <div className="grid sm:grid-cols-2 gap-3">
                    {facilities.map((facility) => (
                      <div
                        key={facility.id}
                        className={cn(
                          "p-4 border rounded-lg cursor-pointer transition-colors",
                          selectedFacility === facility.id ? "border-primary bg-primary/5" : "hover:bg-muted",
                          !facility.available && "opacity-50 cursor-not-allowed",
                        )}
                        onClick={() => facility.available && setSelectedFacility(facility.id)}
                      >
                        <div className="flex items-start gap-3">
                          <facility.icon className="h-5 w-5 text-primary mt-1" />
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h3 className="font-semibold">{facility.name}</h3>
                              <Badge variant={facility.available ? "secondary" : "destructive"}>
                                {facility.available ? "Available" : "Unavailable"}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground">{facility.description}</p>
                            <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1">
                              <Users className="h-3 w-3" />
                              {facility.capacity}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Date Selection */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Select Date</Label>
                    <Popover open={isPopoverOpen} onOpenChange={setIsPopoverOpen}>
                      <PopoverTrigger asChild>
                        <Button
                          variant="outline"
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !selectedDate && "text-muted-foreground",
                          )}
                        >
                          <CalendarIcon className="mr-2 h-4 w-4" />
                          {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0 z-50" align="start">
                        <Calendar
                          mode="single"
                          selected={selectedDate}
                          onSelect={(date) => {
                            setSelectedDate(date)
                            setIsPopoverOpen(false)
                          }}
                          disabled={(date) => date < new Date()}
                          initialFocus
                        />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <Label>Select Time Slot</Label>
                    <Select value={selectedTime} onValueChange={setSelectedTime}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose time slot" />
                      </SelectTrigger>
                      <SelectContent>
                        {timeSlots.map((slot) => (
                          <SelectItem key={slot} value={slot}>
                            <div className="flex items-center gap-2">
                              <Clock className="h-4 w-4" />
                              {slot}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Booking Details */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="purpose">Purpose of Booking</Label>
                    <Input
                      id="purpose"
                      placeholder="e.g., Football practice, Tournament"
                      value={bookingData.purpose}
                      onChange={(e) => setBookingData({ ...bookingData, purpose: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="participants">Number of Participants</Label>
                    <Input
                      id="participants"
                      type="number"
                      placeholder="e.g., 20"
                      value={bookingData.participants}
                      onChange={(e) => setBookingData({ ...bookingData, participants: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="contact">Contact Person</Label>
                    <Input
                      id="contact"
                      placeholder="Your name"
                      value={bookingData.contactPerson}
                      onChange={(e) => setBookingData({ ...bookingData, contactPerson: e.target.value })}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <Input
                      id="phone"
                      placeholder="Your contact number"
                      value={bookingData.phone}
                      onChange={(e) => setBookingData({ ...bookingData, phone: e.target.value })}
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Additional Notes (Optional)</Label>
                  <Textarea
                    id="notes"
                    placeholder="Any special requirements or additional information"
                    value={bookingData.additionalNotes}
                    onChange={(e) => setBookingData({ ...bookingData, additionalNotes: e.target.value })}
                  />
                </div>

                <Button type="submit" className="w-full">
                  Submit Booking Request
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        {/* Booking Summary & Guidelines */}
        <div className="space-y-6">
          {/* Booking Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Booking Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-2 text-sm">
                <MapPin className="h-4 w-4 text-muted-foreground" />
                <span>
                  {selectedFacility ? facilities.find((f) => f.id === selectedFacility)?.name : "No facility selected"}
                </span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <CalendarIcon className="h-4 w-4 text-muted-foreground" />
                <span>{selectedDate ? format(selectedDate, "PPP") : "No date selected"}</span>
              </div>
              <div className="flex items-center gap-2 text-sm">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span>{selectedTime || "No time selected"}</span>
              </div>
            </CardContent>
          </Card>

          {/* Booking Guidelines */}
          <Card>
            <CardHeader>
              <CardTitle>Booking Guidelines</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="space-y-2">
                <h4 className="font-semibold">Important Notes:</h4>
                <ul className="space-y-1 text-muted-foreground">
                  <li>• Bookings must be made at least 24 hours in advance</li>
                  <li>• Maximum booking duration is 2 hours per session</li>
                  <li>• Cancellations must be made 12 hours before</li>
                  <li>• Equipment must be returned in good condition</li>
                  <li>• Late arrivals may result in reduced booking time</li>
                </ul>
              </div>
              <div className="pt-2 border-t">
                <p className="text-xs text-muted-foreground">
                  For urgent bookings or special events, contact the Sports Coordinator directly.
                </p>
              </div>
            </CardContent>
          </Card>

          {/* My Bookings */}
          <Card>
            <CardHeader>
              <CardTitle>My Recent Bookings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-sm">Football Ground</p>
                      <p className="text-xs text-muted-foreground">Jan 12, 4:00 PM - 6:00 PM</p>
                    </div>
                    <Badge variant="secondary">Approved</Badge>
                  </div>
                </div>
                <div className="p-3 border rounded-lg">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-semibold text-sm">Basketball Court</p>
                      <p className="text-xs text-muted-foreground">Jan 15, 2:00 PM - 4:00 PM</p>
                    </div>
                    <Badge variant="outline">Pending</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
