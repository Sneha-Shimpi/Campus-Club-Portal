const mongoose = require("mongoose")

const nccTrainingSchema = new mongoose.Schema({
  // Training Details
  title: {
    type: String,
    required: [true, "Training title is required"],
    trim: true,
  },
  type: {
    type: String,
    enum: ["drill", "theory", "practical", "camp", "parade", "shooting", "adventure", "social-service"],
    required: [true, "Training type is required"],
  },
  description: {
    type: String,
    required: [true, "Training description is required"],
  },

  // Schedule
  date: {
    type: Date,
    required: [true, "Training date is required"],
  },
  startTime: {
    type: String,
    required: [true, "Start time is required"],
  },
  endTime: {
    type: String,
    required: [true, "End time is required"],
  },
  duration: {
    type: Number, // in hours
    required: [true, "Duration is required"],
  },

  // Location
  venue: {
    type: String,
    required: [true, "Venue is required"],
  },

  // Instructor
  instructor: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: [true, "Instructor is required"],
  },

  // Attendance
  attendees: [
    {
      cadet: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
      status: {
        type: String,
        enum: ["present", "absent", "late", "excused"],
        default: "present",
      },
      arrivalTime: String,
      performance: {
        type: String,
        enum: ["excellent", "good", "satisfactory", "needs-improvement"],
        default: "satisfactory",
      },
      disciplineScore: {
        type: Number,
        min: 0,
        max: 10,
        default: 8,
      },
      notes: String,
    },
  ],

  // Training Content
  topics: [String],
  objectives: [String],
  resources: [String],

  // Assessment
  hasAssessment: {
    type: Boolean,
    default: false,
  },
  assessmentType: {
    type: String,
    enum: ["practical", "written", "oral", "drill-test"],
  },
  maxMarks: Number,

  // Results
  results: [
    {
      cadet: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
      marksObtained: Number,
      grade: {
        type: String,
        enum: ["A+", "A", "B+", "B", "C+", "C", "D", "F"],
      },
      feedback: String,
    },
  ],

  // Status
  status: {
    type: String,
    enum: ["scheduled", "ongoing", "completed", "cancelled"],
    default: "scheduled",
  },

  // Media
  photos: [String],
  documents: [String],

  // Timestamps
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

// Indexes
nccTrainingSchema.index({ date: -1 })
nccTrainingSchema.index({ instructor: 1 })
nccTrainingSchema.index({ type: 1, status: 1 })
nccTrainingSchema.index({ "attendees.cadet": 1 })

// Pre-save middleware
nccTrainingSchema.pre("save", function (next) {
  this.updatedAt = Date.now()
  next()
})

module.exports = mongoose.model("NCCTraining", nccTrainingSchema)
