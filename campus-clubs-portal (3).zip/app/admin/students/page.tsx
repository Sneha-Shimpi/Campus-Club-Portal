"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Search, Download, UserCheck, UserX, QrCode } from "lucide-react"

const students = [
  {
    id: 1,
    name: "Rahul Sharma",
    rollNo: "CS2021001",
    email: "rahul.sharma@college.edu",
    sections: ["Sports", "NCC"],
    status: "active",
    joinDate: "2021-08-15",
    avatar: "/diverse-students-studying.png",
  },
  {
    id: 2,
    name: "Priya Patel",
    rollNo: "CS2021002",
    email: "priya.patel@college.edu",
    sections: ["NSS"],
    status: "active",
    joinDate: "2021-08-16",
    avatar: "/diverse-students-studying.png",
  },
  {
    id: 3,
    name: "Amit Kumar",
    rollNo: "CS2021003",
    email: "amit.kumar@college.edu",
    sections: ["Sports", "NSS", "NCC"],
    status: "pending",
    joinDate: "2021-08-17",
    avatar: "/diverse-students-studying.png",
  },
  {
    id: 4,
    name: "Sneha Reddy",
    rollNo: "CS2021004",
    email: "sneha.reddy@college.edu",
    sections: ["NSS"],
    status: "active",
    joinDate: "2021-08-18",
    avatar: "/diverse-students-studying.png",
  },
]

export default function StudentsManagement() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filterSection, setFilterSection] = useState("all")
  const [filterStatus, setFilterStatus] = useState("all")

  const filteredStudents = students.filter((student) => {
    const matchesSearch =
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      student.rollNo.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesSection =
      filterSection === "all" ||
      student.sections.some((section) => section.toLowerCase() === filterSection.toLowerCase())
    const matchesStatus = filterStatus === "all" || student.status === filterStatus
    return matchesSearch && matchesSection && matchesStatus
  })

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-100 text-green-800"
      case "pending":
        return "bg-yellow-100 text-yellow-800"
      case "inactive":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getSectionColor = (section: string) => {
    switch (section) {
      case "Sports":
        return "bg-orange-100 text-orange-800"
      case "NSS":
        return "bg-red-100 text-red-800"
      case "NCC":
        return "bg-purple-100 text-purple-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Student Management</h1>
          <p className="text-gray-600 mt-1">Manage student registrations and activities</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2 bg-transparent">
            <QrCode className="h-4 w-4" />
            QR Scanner
          </Button>
          <Button variant="outline" className="gap-2 bg-transparent">
            <Download className="h-4 w-4" />
            Export Data
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-gray-900">1,247</p>
              <p className="text-sm text-gray-600">Total Students</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-green-600">1,180</p>
              <p className="text-sm text-gray-600">Active</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-yellow-600">45</p>
              <p className="text-sm text-gray-600">Pending</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="text-center">
              <p className="text-2xl font-bold text-red-600">22</p>
              <p className="text-sm text-gray-600">Inactive</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex gap-4 items-center">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by name or roll number..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterSection} onValueChange={setFilterSection}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by section" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Sections</SelectItem>
                <SelectItem value="sports">Sports</SelectItem>
                <SelectItem value="nss">NSS</SelectItem>
                <SelectItem value="ncc">NCC</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="inactive">Inactive</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Students List */}
      <Card>
        <CardHeader>
          <CardTitle>Students ({filteredStudents.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredStudents.map((student) => (
              <div
                key={student.id}
                className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
              >
                <div className="flex items-center gap-4">
                  <Avatar>
                    <AvatarImage src={student.avatar || "/placeholder.svg"} alt={student.name} />
                    <AvatarFallback>
                      {student.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <h3 className="font-semibold text-gray-900">{student.name}</h3>
                    <p className="text-sm text-gray-600">
                      {student.rollNo} • {student.email}
                    </p>
                    <div className="flex gap-2 mt-2">
                      {student.sections.map((section) => (
                        <Badge key={section} className={getSectionColor(section)} variant="secondary">
                          {section}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className={getStatusColor(student.status)}>{student.status}</Badge>
                  <div className="flex gap-2">
                    {student.status === "pending" && (
                      <>
                        <Button size="sm" variant="outline" className="gap-2 text-green-600 bg-transparent">
                          <UserCheck className="h-4 w-4" />
                          Approve
                        </Button>
                        <Button size="sm" variant="outline" className="gap-2 text-red-600 bg-transparent">
                          <UserX className="h-4 w-4" />
                          Reject
                        </Button>
                      </>
                    )}
                    <Button size="sm" variant="outline">
                      View Details
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
