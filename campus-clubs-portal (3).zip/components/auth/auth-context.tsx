"use client"

import React from "react"

interface User {
  id: string
  name: string
  email: string
  rollNo?: string
  role: "student" | "admin"
  profilePhoto?: string
  badges?: string[]
}

interface AuthContextType {
  user: User | null
  login: (email: string, password: string) => Promise<boolean>
  register: (userData: RegisterData) => Promise<boolean>
  logout: () => void
  isLoading: boolean
}

interface RegisterData {
  name: string
  email: string
  password: string
  rollNo: string
  role: "student" | "admin"
}

const AuthContext = React.createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = React.useState<User | null>(null)
  const [isLoading, setIsLoading] = React.useState(true)

  React.useEffect(() => {
    const token = localStorage.getItem("campus_portal_token")
    if (token) {
      setUser({
        id: "1",
        name: "John Doe",
        email: "john.doe@college.edu",
        rollNo: "CS21B001",
        role: "student",
        badges: ["Active Member", "Volunteer"],
      })
    }
    setIsLoading(false)
  }, [])

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const mockUser: User = {
        id: "1",
        name: "John Doe",
        email,
        rollNo: "CS21B001",
        role: email.includes("admin") ? "admin" : "student",
        badges: ["Active Member"],
      }

      setUser(mockUser)
      localStorage.setItem("campus_portal_token", "mock_jwt_token")
      return true
    } catch (error) {
      console.error("Login error:", error)
      return false
    }
  }

  const register = async (userData: RegisterData): Promise<boolean> => {
    try {
      const newUser: User = {
        id: Date.now().toString(),
        name: userData.name,
        email: userData.email,
        rollNo: userData.rollNo,
        role: userData.role,
        badges: [],
      }

      setUser(newUser)
      localStorage.setItem("campus_portal_token", "mock_jwt_token")
      return true
    } catch (error) {
      console.error("Registration error:", error)
      return false
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("campus_portal_token")
  }

  return <AuthContext.Provider value={{ user, login, register, logout, isLoading }}>{children}</AuthContext.Provider>
}

export function useAuth() {
  const context = React.useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
