"use client"

import { useAuth } from "@/components/auth/auth-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Trophy, Heart, Shield, Calendar, Award, Clock, TrendingUp, MapPin } from "lucide-react"
import Link from "next/link"

// Mock data - in real app, this would come from API
const mockStats = {
  sports: {
    matchesPlayed: 12,
    matchesWon: 8,
    totalGoals: 15,
    upcomingMatches: 3,
  },
  nss: {
    volunteerHours: 45,
    eventsAttended: 8,
    treesPlanted: 25,
    bloodDonated: 2,
  },
  ncc: {
    drillsAttended: 18,
    currentRank: "Cadet",
    trainingHours: 72,
    upcomingTraining: 2,
  },
}

const upcomingEvents = [
  {
    id: 1,
    title: "Football Match vs Engineering College",
    type: "sports",
    date: "2024-01-15",
    time: "4:00 PM",
    location: "Main Ground",
  },
  {
    id: 2,
    title: "Tree Plantation Drive",
    type: "nss",
    date: "2024-01-18",
    time: "8:00 AM",
    location: "Campus Garden",
  },
  {
    id: 3,
    title: "Drill Practice Session",
    type: "ncc",
    date: "2024-01-20",
    time: "6:00 AM",
    location: "Parade Ground",
  },
]

const achievements = [
  { title: "Sports Champion", description: "Won 5+ matches this semester", icon: Trophy, color: "text-yellow-600" },
  { title: "Community Hero", description: "Completed 40+ volunteer hours", icon: Heart, color: "text-red-600" },
  { title: "Disciplined Cadet", description: "Perfect attendance in NCC", icon: Shield, color: "text-blue-600" },
]

export default function DashboardPage() {
  const { user } = useAuth()

  return (
    <div className="space-y-6">
      {/* Welcome Header */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold font-heading">Welcome back, {user?.name?.split(" ")[0]}!</h1>
        <p className="text-muted-foreground">Here's your activity overview across Sports, NSS, and NCC programs.</p>
      </div>

      {/* Quick Stats Cards */}
      <div className="grid md:grid-cols-3 gap-6">
        {/* Sports Stats */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sports Club</CardTitle>
            <Trophy className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-2xl font-bold">{mockStats.sports.matchesPlayed}</span>
                <Badge variant="secondary">Matches Played</Badge>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Win Rate</span>
                  <span>{Math.round((mockStats.sports.matchesWon / mockStats.sports.matchesPlayed) * 100)}%</span>
                </div>
                <Progress
                  value={(mockStats.sports.matchesWon / mockStats.sports.matchesPlayed) * 100}
                  className="h-2"
                />
              </div>
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Goals: {mockStats.sports.totalGoals}</span>
                <span>Upcoming: {mockStats.sports.upcomingMatches}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* NSS Stats */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">NSS Volunteer</CardTitle>
            <Heart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-2xl font-bold">{mockStats.nss.volunteerHours}</span>
                <Badge variant="secondary">Hours</Badge>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Progress to 60hrs</span>
                  <span>{Math.round((mockStats.nss.volunteerHours / 60) * 100)}%</span>
                </div>
                <Progress value={(mockStats.nss.volunteerHours / 60) * 100} className="h-2" />
              </div>
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Trees: {mockStats.nss.treesPlanted}</span>
                <span>Events: {mockStats.nss.eventsAttended}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* NCC Stats */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">NCC Training</CardTitle>
            <Shield className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-2xl font-bold">{mockStats.ncc.drillsAttended}</span>
                <Badge variant="secondary">Drills</Badge>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Current Rank</span>
                  <Badge variant="outline">{mockStats.ncc.currentRank}</Badge>
                </div>
              </div>
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Training: {mockStats.ncc.trainingHours}hrs</span>
                <span>Upcoming: {mockStats.ncc.upcomingTraining}</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Upcoming Events */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Upcoming Events
              </CardTitle>
              <CardDescription>Your scheduled activities across all clubs</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingEvents.map((event) => (
                  <div key={event.id} className="flex items-center gap-4 p-3 rounded-lg border">
                    <div
                      className={`p-2 rounded-lg ${
                        event.type === "sports"
                          ? "bg-yellow-100 text-yellow-700"
                          : event.type === "nss"
                            ? "bg-red-100 text-red-700"
                            : "bg-blue-100 text-blue-700"
                      }`}
                    >
                      {event.type === "sports" ? (
                        <Trophy className="h-4 w-4" />
                      ) : event.type === "nss" ? (
                        <Heart className="h-4 w-4" />
                      ) : (
                        <Shield className="h-4 w-4" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold">{event.title}</h4>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {event.date} at {event.time}
                        </span>
                        <span className="flex items-center gap-1">
                          <MapPin className="h-3 w-3" />
                          {event.location}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <Link href="/dashboard/calendar">
                  <Button variant="outline" className="w-full bg-transparent">
                    View Full Calendar
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Achievements */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="h-5 w-5" />
                Recent Achievements
              </CardTitle>
              <CardDescription>Your latest accomplishments</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {achievements.map((achievement, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className={`p-2 rounded-lg bg-muted ${achievement.color}`}>
                      <achievement.icon className="h-4 w-4" />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-semibold text-sm">{achievement.title}</h4>
                      <p className="text-xs text-muted-foreground">{achievement.description}</p>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4">
                <Link href="/dashboard/profile">
                  <Button variant="outline" className="w-full bg-transparent">
                    View All Achievements
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Common tasks and shortcuts</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link href="/dashboard/sports">
              <Button variant="outline" className="w-full h-auto p-4 flex flex-col gap-2 bg-transparent">
                <Trophy className="h-6 w-6" />
                <span>Book Ground</span>
              </Button>
            </Link>
            <Link href="/dashboard/nss">
              <Button variant="outline" className="w-full h-auto p-4 flex flex-col gap-2 bg-transparent">
                <Heart className="h-6 w-6" />
                <span>Join Event</span>
              </Button>
            </Link>
            <Link href="/dashboard/ncc">
              <Button variant="outline" className="w-full h-auto p-4 flex flex-col gap-2 bg-transparent">
                <Shield className="h-6 w-6" />
                <span>View Training</span>
              </Button>
            </Link>
            <Link href="/dashboard/profile">
              <Button variant="outline" className="w-full h-auto p-4 flex flex-col gap-2 bg-transparent">
                <TrendingUp className="h-6 w-6" />
                <span>Download Report</span>
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
