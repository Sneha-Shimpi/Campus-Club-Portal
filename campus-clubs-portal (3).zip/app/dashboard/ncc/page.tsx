"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { Shield, Calendar, Users, Award, Clock, Target, Star, BookOpen, CheckCircle, AlertCircle } from "lucide-react"
import Link from "next/link"

// Mock data - in real app, this would come from API
const nccStats = {
  currentRank: "Cadet",
  nextRank: "Lance Corporal",
  drillsAttended: 18,
  totalDrills: 20,
  trainingHours: 72,
  attendanceRate: 90,
  disciplineScore: 85,
  quizzesPassed: 5,
  totalQuizzes: 6,
  promotionProgress: 75,
}

const upcomingTraining = [
  {
    id: 1,
    title: "Morning Drill Practice",
    date: "2024-01-15",
    time: "6:00 AM",
    duration: "2 hours",
    location: "Parade Ground",
    type: "Drill",
    instructor: "Capt. Sharma",
    mandatory: true,
  },
  {
    id: 2,
    title: "Map Reading & Navigation",
    date: "2024-01-18",
    time: "3:00 PM",
    duration: "3 hours",
    location: "Classroom A",
    type: "Theory",
    instructor: "Lt. Patel",
    mandatory: false,
  },
  {
    id: 3,
    title: "Physical Training",
    date: "2024-01-20",
    time: "5:30 AM",
    duration: "1.5 hours",
    location: "Sports Ground",
    type: "Physical",
    instructor: "Sgt. Kumar",
    mandatory: true,
  },
]

const recentActivities = [
  {
    id: 1,
    title: "Republic Day Parade Practice",
    date: "2024-01-10",
    type: "Drill",
    attendance: "Present",
    score: 95,
    feedback: "Excellent marching discipline",
  },
  {
    id: 2,
    title: "First Aid Training",
    date: "2024-01-08",
    type: "Theory",
    attendance: "Present",
    score: 88,
    feedback: "Good understanding of basics",
  },
  {
    id: 3,
    title: "Obstacle Course",
    date: "2024-01-05",
    type: "Physical",
    attendance: "Present",
    score: 82,
    feedback: "Needs improvement in timing",
  },
]

const achievements = [
  { title: "Perfect Attendance", description: "100% attendance for 2 months", earned: true, date: "Dec 2023" },
  { title: "Drill Master", description: "Scored 95+ in drill assessment", earned: true, date: "Jan 2024" },
  { title: "Knowledge Expert", description: "Passed all theory quizzes", earned: false, progress: 83 },
  { title: "Physical Fitness", description: "Complete fitness challenge", earned: false, progress: 60 },
]

const rankProgression = [
  { rank: "Recruit", completed: true },
  { rank: "Cadet", completed: true, current: true },
  { rank: "Lance Corporal", completed: false, next: true },
  { rank: "Corporal", completed: false },
  { rank: "Sergeant", completed: false },
]

export default function NCCPage() {
  const [selectedType, setSelectedType] = useState("all")

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold font-heading flex items-center gap-2">
            <Shield className="h-8 w-8 text-primary" />
            NCC Training
          </h1>
          <p className="text-muted-foreground">Track your training progress and military discipline</p>
        </div>
        <div className="flex gap-2">
          <Link href="/dashboard/ncc/quiz">
            <Button variant="outline" className="flex items-center gap-2 bg-transparent">
              <BookOpen className="h-4 w-4" />
              Take Quiz
            </Button>
          </Link>
          <Link href="/dashboard/ncc/attendance">
            <Button className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4" />
              Mark Attendance
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Current Rank</p>
                <p className="text-2xl font-bold">{nccStats.currentRank}</p>
                <p className="text-xs text-muted-foreground">Next: {nccStats.nextRank}</p>
              </div>
              <Shield className="h-8 w-8 text-muted-foreground" />
            </div>
            <Progress value={nccStats.promotionProgress} className="mt-3 h-2" />
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Attendance Rate</p>
                <p className="text-2xl font-bold">{nccStats.attendanceRate}%</p>
                <p className="text-xs text-muted-foreground">
                  {nccStats.drillsAttended}/{nccStats.totalDrills} drills
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Training Hours</p>
                <p className="text-2xl font-bold">{nccStats.trainingHours}</p>
                <p className="text-xs text-muted-foreground">This semester</p>
              </div>
              <Clock className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Discipline Score</p>
                <p className="text-2xl font-bold">{nccStats.disciplineScore}</p>
                <p className="text-xs text-muted-foreground">Out of 100</p>
              </div>
              <Target className="h-8 w-8 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="training" className="space-y-4">
        <TabsList>
          <TabsTrigger value="training">Training Schedule</TabsTrigger>
          <TabsTrigger value="progress">Progress & Ranks</TabsTrigger>
          <TabsTrigger value="assessments">Assessments</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
        </TabsList>

        {/* Training Schedule Tab */}
        <TabsContent value="training" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Upcoming Training Sessions
              </CardTitle>
              <CardDescription>Your scheduled drills, theory classes, and physical training</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingTraining.map((training) => (
                  <div key={training.id} className="border rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h3 className="font-semibold text-lg">{training.title}</h3>
                          <Badge
                            variant={
                              training.type === "Drill"
                                ? "default"
                                : training.type === "Theory"
                                  ? "secondary"
                                  : "outline"
                            }
                          >
                            {training.type}
                          </Badge>
                          {training.mandatory && (
                            <Badge variant="destructive" className="text-xs">
                              Mandatory
                            </Badge>
                          )}
                        </div>
                        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3 text-muted-foreground" />
                            <span>{training.date}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Clock className="h-3 w-3 text-muted-foreground" />
                            <span>
                              {training.time} ({training.duration})
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Shield className="h-3 w-3 text-muted-foreground" />
                            <span>{training.location}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="h-3 w-3 text-muted-foreground" />
                            <span>{training.instructor}</span>
                          </div>
                        </div>
                      </div>
                      <Button size="sm" variant="outline">
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Training History */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Recent Training Activities
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div key={activity.id} className="flex items-center gap-4 p-4 border rounded-lg">
                    <div
                      className={`p-2 rounded-lg ${
                        activity.type === "Drill"
                          ? "bg-blue-100 text-blue-700"
                          : activity.type === "Theory"
                            ? "bg-green-100 text-green-700"
                            : "bg-orange-100 text-orange-700"
                      }`}
                    >
                      {activity.type === "Drill" ? (
                        <Shield className="h-4 w-4" />
                      ) : activity.type === "Theory" ? (
                        <BookOpen className="h-4 w-4" />
                      ) : (
                        <Target className="h-4 w-4" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className="font-semibold">{activity.title}</h4>
                        <Badge variant="outline">{activity.type}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{activity.feedback}</p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-2">
                        <Badge variant={activity.attendance === "Present" ? "secondary" : "destructive"}>
                          {activity.attendance}
                        </Badge>
                        <span className="font-bold">{activity.score}/100</span>
                      </div>
                      <p className="text-sm text-muted-foreground">{activity.date}</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Progress & Ranks Tab */}
        <TabsContent value="progress" className="space-y-4">
          <div className="grid lg:grid-cols-2 gap-6">
            {/* Rank Progression */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Rank Progression
                </CardTitle>
                <CardDescription>Your journey through NCC ranks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {rankProgression.map((rank, index) => (
                    <div key={index} className="flex items-center gap-4">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center ${
                          rank.completed
                            ? "bg-green-100 text-green-600"
                            : rank.current
                              ? "bg-blue-100 text-blue-600"
                              : rank.next
                                ? "bg-yellow-100 text-yellow-600"
                                : "bg-gray-100 text-gray-400"
                        }`}
                      >
                        {rank.completed ? (
                          <CheckCircle className="h-4 w-4" />
                        ) : rank.current ? (
                          <Star className="h-4 w-4" />
                        ) : (
                          <Shield className="h-4 w-4" />
                        )}
                      </div>
                      <div className="flex-1">
                        <h4 className={`font-semibold ${rank.current ? "text-blue-600" : ""}`}>{rank.rank}</h4>
                        {rank.current && <p className="text-sm text-muted-foreground">Current Rank</p>}
                        {rank.next && <p className="text-sm text-muted-foreground">Next Target</p>}
                      </div>
                      {rank.current && (
                        <div className="text-right">
                          <p className="text-sm font-medium">{nccStats.promotionProgress}%</p>
                          <Progress value={nccStats.promotionProgress} className="w-20 h-2" />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Performance Metrics */}
            <Card>
              <CardHeader>
                <CardTitle>Performance Overview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Drill Performance</span>
                      <span className="text-sm font-bold">92/100</span>
                    </div>
                    <Progress value={92} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Theory Knowledge</span>
                      <span className="text-sm font-bold">88/100</span>
                    </div>
                    <Progress value={88} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Physical Fitness</span>
                      <span className="text-sm font-bold">85/100</span>
                    </div>
                    <Progress value={85} className="h-2" />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm font-medium">Discipline Score</span>
                      <span className="text-sm font-bold">{nccStats.disciplineScore}/100</span>
                    </div>
                    <Progress value={nccStats.disciplineScore} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Promotion Requirements */}
          <Card>
            <CardHeader>
              <CardTitle>Requirements for {nccStats.nextRank}</CardTitle>
              <CardDescription>Complete these requirements to earn your next rank</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="font-semibold text-sm">Attendance</span>
                  </div>
                  <p className="text-xs text-muted-foreground">90% attendance achieved</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <CheckCircle className="h-4 w-4 text-green-600" />
                    <span className="font-semibold text-sm">Drill Test</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Passed with 95/100</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="h-4 w-4 text-yellow-600" />
                    <span className="font-semibold text-sm">Theory Exam</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Pending - Next week</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="h-4 w-4 text-yellow-600" />
                    <span className="font-semibold text-sm">Leadership Task</span>
                  </div>
                  <p className="text-xs text-muted-foreground">Lead 2 drill sessions</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Assessments Tab */}
        <TabsContent value="assessments" className="space-y-4">
          <div className="grid lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BookOpen className="h-5 w-5" />
                  Available Quizzes
                </CardTitle>
                <CardDescription>Test your NCC knowledge</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold">Drill Commands & Procedures</h4>
                        <p className="text-sm text-muted-foreground">20 questions • 30 minutes</p>
                      </div>
                      <Button size="sm">Start Quiz</Button>
                    </div>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold">Map Reading & Navigation</h4>
                        <p className="text-sm text-muted-foreground">15 questions • 25 minutes</p>
                      </div>
                      <Button size="sm">Start Quiz</Button>
                    </div>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold">First Aid & Medical</h4>
                        <p className="text-sm text-muted-foreground">25 questions • 40 minutes</p>
                      </div>
                      <Button size="sm" variant="outline">
                        Retake
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quiz Results</CardTitle>
                <CardDescription>Your recent assessment scores</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-semibold text-sm">Weapon Training</h4>
                      <p className="text-xs text-muted-foreground">Completed Jan 10, 2024</p>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-green-600">92/100</span>
                      <p className="text-xs text-muted-foreground">Passed</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-semibold text-sm">Military History</h4>
                      <p className="text-xs text-muted-foreground">Completed Jan 8, 2024</p>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-green-600">88/100</span>
                      <p className="text-xs text-muted-foreground">Passed</p>
                    </div>
                  </div>
                  <div className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-semibold text-sm">Leadership Principles</h4>
                      <p className="text-xs text-muted-foreground">Completed Jan 5, 2024</p>
                    </div>
                    <div className="text-right">
                      <span className="font-bold text-red-600">65/100</span>
                      <p className="text-xs text-muted-foreground">Failed</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Achievements Tab */}
        <TabsContent value="achievements" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  NCC Achievements
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {achievements.map((achievement, index) => (
                    <div
                      key={index}
                      className={`p-4 border rounded-lg ${achievement.earned ? "bg-green-50" : "bg-gray-50"}`}
                    >
                      <div className="flex items-start gap-3">
                        <div
                          className={`p-2 rounded-lg ${
                            achievement.earned ? "bg-green-100 text-green-600" : "bg-gray-100 text-gray-400"
                          }`}
                        >
                          {achievement.earned ? <Award className="h-4 w-4" /> : <Target className="h-4 w-4" />}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-semibold">{achievement.title}</h4>
                          <p className="text-sm text-muted-foreground">{achievement.description}</p>
                          {achievement.earned ? (
                            <p className="text-xs text-green-600 mt-1">Earned: {achievement.date}</p>
                          ) : (
                            <div className="mt-2">
                              <div className="flex justify-between text-xs mb-1">
                                <span>Progress</span>
                                <span>{achievement.progress}%</span>
                              </div>
                              <Progress value={achievement.progress} className="h-1" />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Training Certificate</CardTitle>
                <CardDescription>Download your NCC training certificates</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center p-6 border-2 border-dashed rounded-lg">
                  <Shield className="h-12 w-12 text-primary mx-auto mb-3" />
                  <h3 className="font-semibold mb-2">NCC Training Certificate</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    {nccStats.trainingHours} hours of military training completed
                  </p>
                  <Button>Download Certificate</Button>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Current Rank</span>
                    <Badge variant="secondary">{nccStats.currentRank}</Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Training Hours</span>
                    <span className="font-semibold">{nccStats.trainingHours}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Discipline Score</span>
                    <span className="font-semibold">{nccStats.disciplineScore}/100</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
