const mongoose = require("mongoose")

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, "Event title is required"],
    trim: true,
    maxlength: [200, "Title cannot exceed 200 characters"],
  },
  description: {
    type: String,
    required: [true, "Event description is required"],
    maxlength: [1000, "Description cannot exceed 1000 characters"],
  },
  category: {
    type: String,
    required: [true, "Event category is required"],
    enum: ["sports", "nss", "ncc", "general"],
  },
  type: {
    type: String,
    required: [true, "Event type is required"],
    enum: ["match", "tournament", "volunteer", "training", "workshop", "meeting", "other"],
  },

  // Date and Time
  startDate: {
    type: Date,
    required: [true, "Start date is required"],
  },
  endDate: {
    type: Date,
    required: [true, "End date is required"],
  },
  registrationDeadline: {
    type: Date,
    required: [true, "Registration deadline is required"],
  },

  // Location
  venue: {
    type: String,
    required: [true, "Venue is required"],
    maxlength: [200, "Venue cannot exceed 200 characters"],
  },
  location: {
    address: String,
    coordinates: {
      latitude: Number,
      longitude: Number,
    },
  },

  // Organizer Information
  organizer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: "User",
    required: [true, "Organizer is required"],
  },
  coordinators: [
    {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
    },
  ],

  // Participation
  maxParticipants: {
    type: Number,
    min: [1, "Maximum participants must be at least 1"],
  },
  participants: [
    {
      user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
      registeredAt: {
        type: Date,
        default: Date.now,
      },
      status: {
        type: String,
        enum: ["registered", "confirmed", "attended", "cancelled"],
        default: "registered",
      },
      role: {
        type: String,
        enum: ["participant", "volunteer", "coordinator"],
        default: "participant",
      },
    },
  ],

  // Event Status
  status: {
    type: String,
    enum: ["draft", "published", "ongoing", "completed", "cancelled"],
    default: "draft",
  },

  // Requirements and Resources
  requirements: [String],
  resources: [
    {
      name: String,
      quantity: Number,
      allocated: {
        type: Boolean,
        default: false,
      },
    },
  ],

  // Media and Documents
  images: [String],
  documents: [
    {
      name: String,
      url: String,
      uploadedAt: {
        type: Date,
        default: Date.now,
      },
    },
  ],

  // Event Results (for completed events)
  results: {
    winners: [
      {
        position: Number,
        participant: {
          type: mongoose.Schema.Types.ObjectId,
          ref: "User",
        },
        score: Number,
        prize: String,
      },
    ],
    statistics: {
      totalParticipants: Number,
      attendanceRate: Number,
      feedback: [
        {
          user: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
          },
          rating: {
            type: Number,
            min: 1,
            max: 5,
          },
          comment: String,
          submittedAt: {
            type: Date,
            default: Date.now,
          },
        },
      ],
    },
  },

  // Timestamps
  createdAt: {
    type: Date,
    default: Date.now,
  },
  updatedAt: {
    type: Date,
    default: Date.now,
  },
})

// Indexes
eventSchema.index({ category: 1, status: 1 })
eventSchema.index({ startDate: 1 })
eventSchema.index({ organizer: 1 })
eventSchema.index({ "participants.user": 1 })

// Pre-save middleware
eventSchema.pre("save", function (next) {
  this.updatedAt = Date.now()
  next()
})

// Virtual for participant count
eventSchema.virtual("participantCount").get(function () {
  return this.participants.length
})

// Virtual for available spots
eventSchema.virtual("availableSpots").get(function () {
  if (!this.maxParticipants) return null
  return this.maxParticipants - this.participants.length
})

module.exports = mongoose.model("Event", eventSchema)
