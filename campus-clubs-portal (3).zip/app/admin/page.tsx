"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Users, Calendar, Trophy, Heart, Shield, TrendingUp, Camera, FileText } from "lucide-react"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts"

const overviewStats = [
  { title: "Total Students", value: "1,247", change: "+12%", icon: Users, color: "text-blue-600" },
  { title: "Active Events", value: "23", change: "+5%", icon: Calendar, color: "text-green-600" },
  { title: "Sports Matches", value: "45", change: "+8%", icon: Trophy, color: "text-orange-600" },
  { title: "NSS Volunteers", value: "342", change: "+15%", icon: Heart, color: "text-red-600" },
  { title: "NCC Cadets", value: "189", change: "+3%", icon: Shield, color: "text-purple-600" },
  { title: "Total Hours", value: "2,847", change: "+22%", icon: TrendingUp, color: "text-emerald-600" },
]

const monthlyData = [
  { month: "Jan", sports: 12, nss: 45, ncc: 23 },
  { month: "Feb", sports: 19, nss: 52, ncc: 28 },
  { month: "Mar", sports: 15, nss: 38, ncc: 31 },
  { month: "Apr", sports: 22, nss: 67, ncc: 25 },
  { month: "May", sports: 18, nss: 43, ncc: 29 },
]

const sectionData = [
  { name: "Sports Club", value: 35, color: "#f97316" },
  { name: "NSS", value: 45, color: "#ef4444" },
  { name: "NCC", value: 20, color: "#8b5cf6" },
]

const recentActivities = [
  { type: "Sports", activity: "Basketball match scheduled", time: "2 hours ago", status: "pending" },
  { type: "NSS", activity: "Tree plantation event completed", time: "4 hours ago", status: "completed" },
  { type: "NCC", activity: "Drill practice attendance updated", time: "6 hours ago", status: "completed" },
  { type: "Sports", activity: "New equipment request", time: "1 day ago", status: "pending" },
]

export default function AdminDashboard() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-1">Manage campus clubs and student activities</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="gap-2 bg-transparent">
            <Camera className="h-4 w-4" />
            Upload Media
          </Button>
          <Button className="gap-2 bg-emerald-600 hover:bg-emerald-700">
            <FileText className="h-4 w-4" />
            Generate Report
          </Button>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {overviewStats.map((stat, index) => (
          <Card key={index} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.title}</p>
                  <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-xs text-green-600 font-medium">{stat.change}</p>
                </div>
                <stat.icon className={`h-8 w-8 ${stat.color}`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Monthly Activity Chart */}
        <Card>
          <CardHeader>
            <CardTitle>Monthly Activity Overview</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="sports" fill="#f97316" name="Sports" />
                <Bar dataKey="nss" fill="#ef4444" name="NSS" />
                <Bar dataKey="ncc" fill="#8b5cf6" name="NCC" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Section Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Student Distribution by Section</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={sectionData}
                  cx="50%"
                  cy="50%"
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}%`}
                >
                  {sectionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Activities */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activities</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline" className="text-xs">
                        {activity.type}
                      </Badge>
                      <Badge variant={activity.status === "completed" ? "default" : "secondary"} className="text-xs">
                        {activity.status}
                      </Badge>
                    </div>
                    <p className="font-medium text-gray-900 mt-1">{activity.activity}</p>
                    <p className="text-sm text-gray-600">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-3">
              <Button variant="outline" className="h-20 flex-col gap-2 bg-transparent">
                <Calendar className="h-6 w-6" />
                Create Event
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2 bg-transparent">
                <Users className="h-6 w-6" />
                Manage Students
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2 bg-transparent">
                <Trophy className="h-6 w-6" />
                Sports Reports
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2 bg-transparent">
                <Heart className="h-6 w-6" />
                NSS Reports
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2 bg-transparent">
                <Shield className="h-6 w-6" />
                NCC Reports
              </Button>
              <Button variant="outline" className="h-20 flex-col gap-2 bg-transparent">
                <Camera className="h-6 w-6" />
                Media Gallery
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
